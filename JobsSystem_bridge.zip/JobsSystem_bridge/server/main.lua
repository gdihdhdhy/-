local Bridge = {}

---Send a notification to a specific client
---@param source number Player ID
---@param message string Message to display
---@param notifyType string Type of notification (e.g., 'success', 'error')
function Bridge.notify(source, message, notifyType)
    TriggerClientEvent('JobsSystem_bridge:showNotification', source, message, notifyType)
end

-- Load Utils from the local GetUtils getter
Bridge.Utils = GetUtils()

-- Basic integrity check: Ensure utils loaded correctly
if not Bridge.Utils then
    print("^1[ERROR] JobsSystem Bridge: Failed to initialize Utils. Stopping resource.^0")
    StopResource(GetCurrentResourceName())
    return
end

-- Assign Dispatch if available (if Dispatch is global)
Bridge.Dispatch = _G.Dispatch or Dispatch

---Check if a player can carry a given item/amount
---@param source number Player ID
---@param item string Item name
---@param amount? number Amount (defaults to 1)
---@return boolean
function Bridge.CanCarryItem(source, item, amount)
    if not source or not item then return false end
    
    local player = Framework.getPlayerFromId(source)
    if not player then return false end
    
    return player:canCarryItem(item, amount or 1)
end

-- Export: return bridge object to callers
-- This allows other resources to access the Bridge API
exports('getObject', function()
    return Bridge
end)

-- Export: config getter
exports('getConfig', function()
    return Config
end)

-- Export: CanCarryItem wrapper
exports('CanCarryItem', function(source, item, amount)
    return Bridge.CanCarryItem(source, item, amount)
end)

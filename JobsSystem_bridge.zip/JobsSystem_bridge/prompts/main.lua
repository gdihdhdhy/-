local Prompt         = GetPrompt()
local activePoint    = nil   -- currently focused point/entity

-- Config shortcuts
local renderDist     = Config.Prompts.RenderDistance
local spriteDict     = Config.Prompts.Dict or 'prompt'
local spriteSizeH    = Config.Prompts.SpriteSize
local spriteSizeW    = Config.Prompts.SpriteSize * GetAspectRatio(false)
local spriteR        = Config.Prompts.SpriteColor.r
local spriteG        = Config.Prompts.SpriteColor.g
local spriteB        = Config.Prompts.SpriteColor.b
local spriteA        = Config.Prompts.SpriteColor.a or 255

-- Entity registry (non-lib-points entities added via AddEntity)
local entities       = {}
local entityCounter  = 0

function AddEntity(data)
    entityCounter = entityCounter + 1
    entities[entityCounter] = data
    return entityCounter
end

function RemoveEntity(id)
    entities[id] = nil
end

-- Sprite alpha table per point (for fade in/out)
local spriteAlphas   = {}
-- Cache of canInteract results
local canInteractCache = {}

-- Nearby points within render range (sorted by distance)
local nearbyPoints   = {}

-- Texture dict handle (streamed)
local textureDictHandle = nil

-- ──────────────────────────────────────────────────────────────────────────────
-- Helper: check if any option in a point is interactable
-- ──────────────────────────────────────────────────────────────────────────────
local function hasInteractableOption(point)
    if not point.valid then return false end
    for _, opt in ipairs(point.options) do
        if not opt.canInteract or opt.canInteract() then
            return true
        end
    end
    return false
end

-- ──────────────────────────────────────────────────────────────────────────────
-- Helper: transition prompt when closest point changes
-- ──────────────────────────────────────────────────────────────────────────────
local function switchToPoint(point)
    Prompt.hide()
    Wait(200)
    if not point then return end

    Prompt.setOptions(point.options)

    SetTimeout(200, function()
        if activePoint == point then
            Prompt.setIndex(1)
        end
    end)

    SetTimeout(300, function()
        if activePoint == point then
            Prompt.show()
        end
    end)
end

-- ──────────────────────────────────────────────────────────────────────────────
-- Thread 1: find closest valid point and switch prompt when it changes
-- ──────────────────────────────────────────────────────────────────────────────
CreateThread(function()
    while true do
        -- Stream texture dict
        if not textureDictHandle then
            textureDictHandle = lib.requestStreamedTextureDict(spriteDict)
        end

        -- Find closest interactable point
        local closest = { dist = math.huge }

        -- Check lib.points
        for _, point in pairs(lib.points.getAllPoints()) do
            if point.options and point.dist then
                if point.dist < point.distance and point.dist < closest.dist then
                    if hasInteractableOption(point) then
                        closest.point = point
                        closest.dist  = point.dist
                    end
                end
            end
        end

        -- Check local entity points
        for _, entity in pairs(entities) do
            local radius = entity.radius or entity.distance
            if entity.dist and entity.dist < radius and entity.dist < closest.dist then
                if hasInteractableOption(entity) then
                    closest.point = entity
                    closest.dist  = entity.dist
                end
            end
        end

        -- Switch prompt if closest changed
        if activePoint ~= closest.point then
            switchToPoint(closest.point)
        end

        activePoint = closest.point

        if activePoint then
            Prompt.updateOptions()
        end

        Wait(#nearbyPoints == 0 and 1000 or 100)
    end
end)

-- ──────────────────────────────────────────────────────────────────────────────
-- Thread 2: update distances and build nearbyPoints list (300 ms)
-- ──────────────────────────────────────────────────────────────────────────────
CreateThread(function()
    while true do
        table.wipe(nearbyPoints)
        local pedCoords = GetEntityCoords(cache.ped)

        -- lib.points
        for _, point in pairs(lib.points.getAllPoints()) do
            point.dist = #(pedCoords - point.coords.xyz)
            if point.options then
                if point.dist < renderDist * 2 then
                    table.insert(nearbyPoints, point)
                    if not spriteAlphas[point] then
                        spriteAlphas[point] = 0
                    end
                    canInteractCache[point] = hasInteractableOption(point)
                else
                    spriteAlphas[point] = nil
                end
            end
        end

        -- local entity points
        for _, entity in pairs(entities) do
            if not DoesEntityExist(entity.entity) then
                RemoveEntity(entity.entity)
            else
                entity.dist = #(pedCoords - entity.getCoords())
                if entity.dist < renderDist * 2 then
                    table.insert(nearbyPoints, entity)
                    if not spriteAlphas[entity] then
                        spriteAlphas[entity] = 0
                    end
                    canInteractCache[entity] = hasInteractableOption(entity)
                else
                    spriteAlphas[entity] = nil
                end
            end
        end

        -- Sort by distance
        table.sort(nearbyPoints, function(a, b) return a.dist < b.dist end)

        Wait(300)
    end
end)

-- ──────────────────────────────────────────────────────────────────────────────
-- Thread 3: fade sprite alphas in/out (20 ms)
-- ──────────────────────────────────────────────────────────────────────────────
CreateThread(function()
    while true do
        for i = 1, #nearbyPoints do
            local point    = nearbyPoints[i]
            local interact = canInteractCache[point]
            local alpha    = spriteAlphas[point] or 0

            if interact and point.dist <= renderDist then
                if alpha < spriteA then
                    spriteAlphas[point] = math.min(alpha + 30, spriteA)
                end
            else
                if point.dist > renderDist or not interact then
                    if alpha > 0 then
                        spriteAlphas[point] = math.max(alpha - 30, 0)
                    end
                end
            end

            -- Clamp
            spriteAlphas[point] = math.max(0, math.min(spriteAlphas[point] or 0, spriteA))
        end

        Wait(20)
    end
end)

-- ──────────────────────────────────────────────────────────────────────────────
-- Thread 4: draw sprites for nearby points (every frame)
-- ──────────────────────────────────────────────────────────────────────────────
CreateThread(function()
    while true do
        if #nearbyPoints == 0 then
            Wait(200)
        end

        for i = 1, math.min(#nearbyPoints, 32) do
            local point  = nearbyPoints[i]
            local coords = point.coords or point.getCoords()

            SetDrawOrigin(coords.x, coords.y, coords.z)

            if point == activePoint then
                Prompt.draw()
            else
                local alpha = spriteAlphas[point] or 0
                if alpha > 0 then
                    DrawSprite(spriteDict, 'point', 0.0, 0.0, spriteSizeH, spriteSizeW, 0.0,
                        spriteR, spriteG, spriteB, alpha)
                end
            end
        end

        ClearDrawOrigin()
        Wait(0)
    end
end)

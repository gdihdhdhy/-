local Prompt      = {}
local duiWidth    = 700

-- Create DUI for the prompt overlay
local duiUrl      = ('https://cfx-nui-%s/web/index.html'):format(cache.resource)
local dui         = CreateDui(duiUrl, duiWidth, 700)
local duiHandle   = GetDuiHandle(dui)
local txd         = CreateRuntimeTxd('JobsSystem_prompt')
CreateRuntimeTextureFromDuiHandle(txd, 'main', duiHandle)

-- Reload DUI on player spawn (fixes post-reconnect issues)
CreateThread(function()
    while not Framework do Wait(100) end
    Framework.onPlayerLoaded(function()
        SetDuiUrl(dui, ('https://cfx-nui-%s/web/index.html'):format(cache.resource))
    end)
end)

-- Internal state
local currentOptions = {}   -- full option objects
local currentIndex   = 1    -- 1-based selected index
local activeCount    = 1    -- number of interactable options

-- Send a message to the DUI
local function sendDui(data)
    SendDuiMessage(dui, json.encode(data))
end

-- Build a lightweight options list (label + icon only) and send to DUI
function Prompt.setOptions(options)
    local simplified = {}
    for _, opt in ipairs(options) do
        table.insert(simplified, {
            label = opt.label,
            icon  = (opt.icon ~= '' and opt.icon) or nil,
        })
    end
    sendDui({ action = 'set_options', options = simplified })
    currentOptions = options
    currentIndex   = 1
end

-- Recompute which options are currently interactable and notify DUI
function Prompt.updateOptions()
    local canInteract = {}
    local count = 0

    for _, opt in ipairs(currentOptions) do
        local ok = not opt.canInteract or opt.canInteract()
        table.insert(canInteract, ok)
        if ok then count = count + 1 end
    end

    sendDui({ action = 'update_options', canInteract = canInteract })

    -- Clamp index to valid range
    if count < currentIndex then
        Prompt.setIndex(count)
    else
        Prompt.setIndex(currentIndex)
    end

    activeCount = count
end

-- Set selected index (1-based, clamped)
function Prompt.setIndex(index)
    if index <= 0 or index > activeCount then return end
    currentIndex = index
    sendDui({ action = 'set_index', index = currentIndex - 1 }) -- DUI is 0-based
end

-- Show / hide the prompt overlay
function Prompt.show()
    sendDui({ action = 'show' })
end

function Prompt.hide()
    sendDui({ action = 'hide' })
    currentOptions = {}
    currentIndex   = 1
end

-- Draw the DUI sprite at its position (called every frame when active)
function Prompt.draw()
    local height = 0.28
    local width  = height * GetAspectRatio(false)
    DrawSprite('JobsSystem_prompt', 'main', 0.0, 0.0, height, width, 0.0, 255, 255, 255, 255)
end

-- Keybind: interact (E by default)
lib.addKeybind({
    name           = 'interact_prompt',
    description    = 'Main interaction keybind',
    defaultMapper  = 'keyboard',
    defaultKey     = 'E',
    onReleased     = function()
        if not currentOptions then return end

        local interactableIndex = 0
        for i, opt in ipairs(currentOptions) do
            local visible = not canInteractCache or canInteractCache[i]
            if visible then
                interactableIndex = interactableIndex + 1
                if interactableIndex == currentIndex then
                    local args = opt.args
                    opt.onSelect(type(args) == 'table' and table.unpack(args) or args)
                    return
                end
            end
        end
    end,
})

-- Commands for scroll wheel navigation
RegisterCommand('interact_scroll_up', function()
    if not currentOptions then return end
    Prompt.setIndex(currentIndex - 1)
end)

RegisterCommand('interact_scroll_down', function()
    if not currentOptions then return end
    Prompt.setIndex(currentIndex + 1)
end)

RegisterKeyMapping('interact_scroll_up',   'Interaction scroll up',   'MOUSE_WHEEL', 'IOM_WHEEL_UP')
RegisterKeyMapping('interact_scroll_down', 'Interaction scroll down', 'MOUSE_WHEEL', 'IOM_WHEEL_DOWN')

-- Getter used by main.lua and api.lua
function GetPrompt()
    return Prompt
end

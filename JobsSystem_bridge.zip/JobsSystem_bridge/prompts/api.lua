-- API table: any assignment also calls exports() automatically
API = setmetatable({}, {
    __newindex = function(t, key, value)
        rawset(t, key, value)
        exports(key, value)
    end
})

-- Helper: format icon strings in an options table
local function formatIcons(options)
    for _, option in ipairs(options) do
        if option.icon and option.icon ~= '' then
            option.icon = string.format('fa-solid fa-%s fw', option.icon)
        end
    end
end

-- Helper: create a lib.points entry with a .valid flag and overridden remove()
local function createPoint(data)
    local point = lib.points.new(data)
    point.valid = true

    local originalRemove = point.remove
    function point.remove()
        point.valid = false
        originalRemove(point)
    end

    return point
end

-- API: add a coordinate-based interaction point
function API.addPoint(data)
    formatIcons(data.options)
    return createPoint(data)
end

-- API: add a local entity-based interaction point
function API.addLocalEntity(data)
    formatIcons(data.options)
    data.valid = true

    -- Resolve coordinate getter based on bone / offset / plain entity coords
    if data.bone then
        local boneIndex = GetPedBoneIndex(data.entity, data.bone)
        function data.getCoords()
            return GetWorldPositionOfEntityBone(data.entity, boneIndex)
        end
    elseif data.offset then
        local offset = data.offset
        function data.getCoords()
            return GetOffsetFromEntityInWorldCoords(data.entity, offset.x, offset.y, offset.z)
        end
    else
        function data.getCoords()
            return GetEntityCoords(data.entity)
        end
    end

    local id = AddEntity(data)

    local handle = {}
    function handle.remove()
        data.valid = false
        RemoveEntity(id)
    end

    return handle
end

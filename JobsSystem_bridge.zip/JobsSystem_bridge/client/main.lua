local Bridge = {}

-- Register notification event
RegisterNetEvent('JobsSystem_bridge:showNotification')
AddEventHandler('JobsSystem_bridge:showNotification', ShowNotification)

-- Expose UI/progress functions
Bridge.notify         = ShowNotification
Bridge.showUI         = ShowUI
Bridge.hideUI         = HideUI
Bridge.progressBar    = ShowProgressBar
Bridge.progressActive = IsProgressActive
Bridge.cancelProgress = CancelProgress
Bridge.showObjective  = ShowObjective
Bridge.hideObjective  = HideObjective
Bridge.showBars       = ShowBars
Bridge.hideBars       = HideBars



-- Export main bridge object
exports('getObject', function()
    return Bridge
end)

-- Expose shorthand utils
Utils = {}
Utils.isPolice   = Bridge.Utils.isPolice
Utils.createBlip = Bridge.Utils.createBlip

-- Export config
exports('getConfig', function()
    return Config
end)

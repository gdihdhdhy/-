---@diagnostic disable: duplicate-set-field
---@diagnostic disable: duplicate-doc-field

if GetResourceState('qb-core') ~= 'started' then return end

local config

CreateThread(function()
    while GetResourceState('JobsSystem_bridge') ~= 'started' do Wait(100) end

    config = exports.JobsSystem_bridge:getConfig()
end)

Framework = { name = 'qb-core' }
local sharedObject = exports['qb-core']:GetCoreObject()
Framework.object = sharedObject
QBCore = sharedObject
Framework.PlayerBase = {}

local codemInventory = GetResourceState('codem-inventory') == 'started'

function Framework.getPlayerFromId(id)
    local playerInstance = setmetatable({}, { __index = Framework.PlayerBase })
    playerInstance.QBPlayer = sharedObject.Functions.GetPlayer(id)

    if not playerInstance.QBPlayer then return end

    playerInstance.source = id

    return playerInstance
end

function Framework.getPlayerFromIdentifier(identifier)
    local playerInstance = setmetatable({}, { __index = Framework.PlayerBase })
    playerInstance.QBPlayer = sharedObject.Functions.GetPlayerByCitizenId(identifier)

    if not playerInstance.QBPlayer then return end

    playerInstance.source = playerInstance.QBPlayer.PlayerData.source

    return playerInstance
end

Framework.registerUsableItem = sharedObject.Functions.CreateUseableItem

Framework.getPlayers = sharedObject.Functions.GetQBPlayers

local qb-inventory = GetResourceState('qb-inventory') == 'started'
local qs_inventory = GetResourceState('qs-inventory') == 'started'

function Framework.getItemLabel(item)
    if qb-inventory then
        return exports.qb-inventory:Items()[item]?.label
    elseif qs_inventory then
        return exports['qs-inventory']:GetItemList()[item]?.label
    elseif codemInventory then
        return exports['codem-inventory']:GetItemList()[item]?.label
    end

    return sharedObject.Shared.Items[item]?.label
end

function Framework.getItems()
    if qb-inventory then
        return exports.qb-inventory:Items()
    elseif qs_inventory then
        return exports['qs-inventory']:GetItemList()
    elseif codemInventory then
        return exports['codem-inventory']:GetItemList()
    end

    return sharedObject.Shared.Items
end

function Framework.PlayerBase:hasGroup(name)
    return sharedObject.Functions.HasPermission(self.source, name) == name
end

function Framework.PlayerBase:hasOneOfGroups(groups)
    for k,v in pairs(groups) do
        if sharedObject.Functions.HasPermission(self.source, k) then
            return true
        end
    end

    return false
end

function Framework.PlayerBase:addItem(name, count, metadata)
    count = count or 1

    if qb-inventory then
        if not exports.qb-inventory:CanCarryItem(self.source, name, count) then
            return false
        end
        
        exports.qb-inventory:AddItem(self.source, name, count, metadata)
        return true
    elseif codemInventory then
        return exports['codem-inventory']:AddItem(self.source, name, count, nil, metadata)
    else
        return self.QBPlayer.Functions.AddItem(name, count, nil, metadata) --[[@as boolean]]
    end
end

function Framework.PlayerBase:removeItem(name, count)
    count = count or 1

    if qb-inventory then
        exports.qb-inventory:RemoveItem(self.source, name, count)
    elseif codemInventory then
        exports['codem-inventory']:RemoveItem(self.source, name, count)
    else
        self.QBPlayer.Functions.RemoveItem(name, count)
    end
end

function Framework.PlayerBase:canCarryItem(name, count)
    count = count or 1

    if qb-inventory then
        return exports.qb-inventory:CanCarryItem(self.source, name, count)
    end

    if codemInventory then
        return exports['codem-inventory']:CanCarryItem(self.source, name, count)
    end

    -- No equivalent for QBCore
    return true
end

function Framework.PlayerBase:getItemCount(name)
    if qb-inventory then
        return exports.qb-inventory:GetItemCount(self.source, name)
    elseif codemInventory then
        return exports['codem-inventory']:GetItemsTotalAmount(self.source, name)
    else
        return self.QBPlayer.Functions.GetItemByName(name)?.amount or 0
    end
end

function Framework.PlayerBase:hasItem(name)
    return self:getItemCount(name) > 0
end

function Framework.PlayerBase:getAccountMoney(account)
    if account == 'money' then
        account = 'cash'
    end

    if config.BlackMoney and account == config.BlackMoney.ItemName then
        if not config.BlackMoney.UsesMetadata then
            return self:getItemCount(account)
        else
            error(('Disable Config.BlackMoney.UsesMetadata in JobsSystem_bridge if you want to use %s as a fully functional account.'):format(account))
        end
    else
        return self.QBPlayer.Functions.GetMoney(account)
    end
end

function Framework.PlayerBase:addAccountMoney(account, amount)
    if account == 'money' then
        account = 'cash'
    end

    if config.BlackMoney and account == config.BlackMoney.ItemName then
        if config.BlackMoney.UsesMetadata then
            local oldWorth = 0

            for _, item in pairs(self.QBPlayer.PlayerData.items) do
                if item.name == account then
                    local worth = item.info.worth

                    if worth and worth > 0 then
                        oldWorth += worth
                        self:removeItem(account, 1)
                    end
                end
            end

            self:addItem(account, 1, { worth = amount + oldWorth })
        else
            self:addItem(account, amount)
        end
    else
        self.QBPlayer.Functions.AddMoney(account, amount)
    end   
end

function Framework.PlayerBase:removeAccountMoney(account, amount)
    if account == 'money' then
        account = 'cash'
    end

    if config.BlackMoney and account == config.BlackMoney.ItemName then
        if not config.BlackMoney.UsesMetadata then
            return self:removeItem(account, amount)
        else
            error(('Disable Config.BlackMoney.UsesMetadata in JobsSystem_bridge if you want to use %s as a fully functional account.'):format(account))
        end
    else
        self.QBPlayer.Functions.RemoveMoney(account, amount)
    end
end

function Framework.PlayerBase:getJob()
    return self.QBPlayer.PlayerData.job.name
end

function Framework.PlayerBase:getJobGrade()
    return self.QBPlayer.PlayerData.job.grade.level
end

function Framework.PlayerBase:setJob(name, grade)
    return self.QBPlayer.Functions.SetJob(name, grade)
end

function Framework.PlayerBase:setDuty(value)
    return self.QBPlayer.Functions.SetJobDuty(value)
end

function Framework.PlayerBase:getIdentifier()   
    return self.QBPlayer.PlayerData.citizenid
end

function Framework.PlayerBase:getFirstName()
    return self.QBPlayer.PlayerData.charinfo.firstname
end

function Framework.PlayerBase:getLastName()
    return self.QBPlayer.PlayerData.charinfo.lastname
end
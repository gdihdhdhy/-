local currentPed       = nil
local currentCam       = nil
local npcCallback      = nil

local greetingLines = {
    'GENERIC_HI',
    'GENERIC_HOWS_IT_GOING',
    'CHAT_RESP',
}

-- Open NPC interaction menu: set up camera, play speech, show NUI dialog
exports('openPedInteractionMenu', function(ped, header, dialog, callback)
    -- Position camera slightly in front of and above the ped
    local camOffset  = GetOffsetFromEntityInWorldCoords(ped, 0.0, 0.9, 0.55)
    local pedCoords  = GetEntityCoords(ped)

    currentCam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    SetCamCoord(currentCam, camOffset.x, camOffset.y, camOffset.z)
    PointCamAtCoord(currentCam, pedCoords.x, pedCoords.y, pedCoords.z + 0.4)
    RenderScriptCams(true, true, 1000, true, true)

    Wait(500)

    -- Play random greeting
    local greeting = greetingLines[math.random(#greetingLines)]
    PlayPedAmbientSpeechNative(ped, greeting, 'SPEECH_PARAMS_FORCE_NORMAL_CLEAR')

    -- Show NUI dialog
    SetNuiFocus(true, true)
    SendNUIMessage({
        action           = 'show_npc',
        header           = header,
        question         = dialog.question,
        answers          = dialog.answers,
        answerItems      = dialog.answerItems,
        answerNumberInput = dialog.answerNumberInput,
    })

    currentPed     = ped
    npcCallback    = callback
end)

-- Handle NUI response from NPC dialog
RegisterNUICallback('npc_response', function(data, cb)
    -- Guard: bail if required state is missing
    if not npcCallback or not currentPed or not currentCam then
        return cb({})
    end

    local response = (data.type == 'escape' or not data) and nil or data
    local next     = npcCallback(response)

    if next then
        -- Show next question if not escaping
        if data.type ~= 'escape' then
            SendNUIMessage({
                action           = 'next_question',
                question         = next.question,
                answers          = next.answers,
                answerItems      = next.answerItems,
                answerNumberInput = next.answerNumberInput,
            })
        end
    else
        -- Close dialog and restore camera
        if data.type ~= 'escape' then
            SendNUIMessage({ action = 'hide_npc' })
        end

        SetNuiFocus(false, false)
        SetCamActive(currentCam, false)
        RenderScriptCams(false, true, 1000, true, true)
        npcCallback = nil
    end

    cb({})
end)



-- ──────────────────────────────────────────────────────────────────────────────
-- distanceCheck(a, b, maxDist?)
-- Returns true if two coords (or player IDs) are within maxDist of each other.
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.distanceCheck(a, b, maxDist)
    maxDist = maxDist or Config.MaxDistance

    if type(a) == 'number' or type(a) == 'string' then
        local ped = GetPlayerPed(a)
        if ped == 0 then return false end
        a = GetEntityCoords(ped)
    end

    if type(b) == 'number' or type(b) == 'string' then
        local ped = GetPlayerPed(b)
        if ped == 0 then return false end
        b = GetEntityCoords(ped)
    end

    return maxDist >= #(a.xyz - b.xyz)
end

-- getTableSize(t) — count all keys including non-sequential
function Utils.getTableSize(t)
    local count = 0
    for _ in pairs(t) do count = count + 1 end
    return count
end

-- randomFromTable(t) — return a random element from an array
function Utils.randomFromTable(t)
    return t[math.random(1, #t)]
end

-- ──────────────────────────────────────────────────────────────────────────────
-- logToDiscord(source, webhookUrl, message)
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.logToDiscord(source, webhookUrl, message)
    local resourceName = GetInvokingResource() or 'JobsSystem_bridge'
    local player       = Framework.getPlayerFromId(source)
    if not player then return end

    if Config.Logging == 'custom' then
        CustomLogging(player, resourceName, message)
    end

    local embed = {
        color       = '16768885',
        title       = ('%s (%s)'):format(GetPlayerName(source), player:getIdentifier()),
        description = message,
        footer      = {
            text     = os.date('%H:%M - %d. %m. %Y', os.time()),
            icon_url = 'https://cdn.discordapp.com/attachments/793081015433560075/1048643072952647700/JobsSystem.png',
        },
    }

    PerformHttpRequest(webhookUrl, function() end, 'POST',
        json.encode({ username = resourceName, embeds = { embed } }),
        { ['Content-Type'] = 'application/json' }
    )
end

-- ──────────────────────────────────────────────────────────────────────────────
-- setTimeout(delay, callback) — cancellable server-side timeout
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.setTimeout(delay, callback)
    local active = true
    local handle = {}

    function handle.cancel() active = false end

    SetTimeout(delay, function()
        if active then callback() end
    end)

    return handle
end

-- ──────────────────────────────────────────────────────────────────────────────
-- getJobCount(jobs) — count online on-duty players with one of the given jobs
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.getJobCount(jobs)
    local jobLookup
    if type(jobs) == 'table' then
        jobLookup = {}
        for _, j in ipairs(jobs) do jobLookup[j] = true end
    elseif type(jobs) == 'string' then
        jobLookup = { [jobs] = true }
    end

    local count = 0

    for _, player in pairs(Framework.getPlayers()) do
        local jobName = (player.job and player.job.name)
                     or (player.PlayerData and player.PlayerData.job and player.PlayerData.job.name)
        local onDuty  = player.job ~= nil  -- ESX: always on duty
                     or (player.PlayerData and player.PlayerData.job and player.PlayerData.job.onduty)

        if jobName and onDuty and jobLookup[jobName] == true then
            count = count + 1
        end
    end

    return count
end

-- getPoliceCount() — shortcut using dispatch jobs from config
function Utils.getPoliceCount()
    return Utils.getJobCount(Config.Dispatch.Jobs)
end

-- ──────────────────────────────────────────────────────────────────────────────
-- hasJobs(source, jobs) — check if a player has one of the given jobs
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.hasJobs(source, jobs)
    local player = Framework.getPlayerFromId(source)
    if not player then return end

    if type(jobs) == 'string' then jobs = { jobs } end

    for _, job in ipairs(jobs) do
        if player:getJob() == job then
            return true
        end
    end

    return false
end

-- isPolice(source) — check if player has a police/dispatch job
function Utils.isPolice(source)
    return Utils.hasJobs(source, Config.Dispatch.Jobs)
end

-- ──────────────────────────────────────────────────────────────────────────────
-- Version checking
-- ──────────────────────────────────────────────────────────────────────────────
local function getResourceVersion(resourceName)
    local raw     = GetResourceMetadata(resourceName, 'version', 0)
    local version = raw and raw:match('%d+%.%d+%.%d+')
    if not version then
        error(('Unable to determine %s version.'):format(resourceName))
    end
    return version
end

function Utils.checkVersion(resourceName)
    CreateThread(function()
        local url = ('https://raw.githubusercontent.com/JobsSystem-Scripts/versions/main/%s'):format(resourceName)
        Wait(5000)

        PerformHttpRequest(url, function(_, body)
            local localVer = getResourceVersion(resourceName)

            if not body then
                warn(('Couldn\'t check version for resource: %s'):format(resourceName))
                return
            end

            local remoteVer = body:sub(1, 5)

            if localVer ~= remoteVer then
                print(('^0[^3WARNING^0] %s is outdated and should be updated!'):format(resourceName))
                print(('^0[^3WARNING^0] Download the latest version ^5%s^0 through keymaster.'):format(remoteVer))
            else
                print(('^0[^2INFO^0] %s is up-to-date.'):format(resourceName))
            end
        end, 'GET')
    end)
end

CreateThread(function()
    Utils.checkVersion('JobsSystem_bridge')
end)

-- ──────────────────────────────────────────────────────────────────────────────
-- Item label cache
-- ──────────────────────────────────────────────────────────────────────────────
local itemLabels  = nil
local labelsReady = false

CreateThread(function()
    while true do
        if itemLabels and Utils.getTableSize(itemLabels) ~= 0 then break end

        local raw    = Framework.getItems()
        local labels = {}

        for key, item in pairs(raw) do
            labels[item.name or key] = item.label or 'NULL'
        end

        itemLabels = labels
        Wait(100)
    end
    labelsReady = true
end)

lib.callback.register('JobsSystem_bridge:getItemLabels', function()
    while not labelsReady do Wait(100) end
    return itemLabels
end)

function Utils.getItemLabel(item)
    return itemLabels[item] or itemLabels[item:upper()] or 'ITEM_NOT_FOUND'
end

-- getImageUrl(path) — build JobsSystem Scripts CDN URL
function Utils.getImageUrl(path)
    return ('https://JobsSystem-scripts.com/%s'):format(path)
end

-- ──────────────────────────────────────────────────────────────────────────────
-- offsetCoords(origin, forward, right, up, headingOffset?)
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.offsetCoords(origin, forward, right, up, headingOffset)
    local rad = math.rad(origin.w)
    local cos = math.cos(rad)
    local sin = math.sin(rad)
    return vector4(
        origin.x + (forward * cos - right * sin),
        origin.y + (forward * sin + right * cos),
        origin.z + up,
        origin.w  + (headingOffset or 0.0)
    )
end

-- ──────────────────────────────────────────────────────────────────────────────
-- createVehicle(model, coords, networkType) — server-side vehicle spawn
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.createVehicle(model, coords, networkType)
    local vehicle = CreateVehicleServerSetter(model, networkType,
        coords.x, coords.y, coords.z - 0.7, coords.w)

    for seat = -1, 6 do
        local ped     = GetPedInVehicleSeat(vehicle, seat)
        local popType = GetEntityPopulationType(ped)
        if popType > 0 and popType < 6 then
            DeleteEntity(ped)
        end
    end

    return vehicle
end

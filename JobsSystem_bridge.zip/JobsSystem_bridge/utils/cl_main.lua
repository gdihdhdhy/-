

-- Ped/prop resource tracker (keyed by invoking resource name)
local pedRegistry  = {}
local blipRegistry = {}
local stateBagHandlers = {}

-- ──────────────────────────────────────────────────────────────────────────────
-- Utility helpers
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.getTableSize(t)
    local count = 0
    for _ in pairs(t) do count = count + 1 end
    return count
end

function Utils.randomFromTable(t)
    return t[math.random(1, #t)]
end

-- ──────────────────────────────────────────────────────────────────────────────
-- NPC scenarios played randomly when a ped spawns
-- ──────────────────────────────────────────────────────────────────────────────
local defaultScenarios = {
    'WORLD_HUMAN_AA_COFFEE',
    'WORLD_HUMAN_AA_SMOKE',
    'WORLD_HUMAN_SMOKING',
}

-- ──────────────────────────────────────────────────────────────────────────────
-- createPed(coords, pedData, options?, targetCallback?)
-- Spawns a scenario ped near coords, registers an interaction zone.
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.createPed(coords, pedData, options, targetCallback)
    -- Normalise pedData
    if type(pedData) ~= 'table' then
        pedData = { model = pedData }
    end

    if not IsModelValid(pedData.model) then
        error(('Invalid ped model: %s'):format(pedData.model))
    end

    local ped = {}
    local spawnDist = (Config.SpawnDistance or 100.0)

    local point = lib.points.new({
        coords   = coords.xyz,
        distance = spawnDist,

        onEnter = function()
            lib.requestModel(pedData.model)

            local x = coords.x
            local y = coords.y
            local z = coords.z - 1.0
            local w = (coords.w or 0.0) + 0.0

            ped.value = CreatePed(4, pedData.model, x, y, z, w, false, false)

            SetEntityInvincible(ped.value, true)
            SetBlockingOfNonTemporaryEvents(ped.value, true)

            local scenario = pedData.scenario or Utils.randomFromTable(defaultScenarios)
            TaskStartScenarioInPlace(ped.value, scenario)
            FreezeEntityPosition(ped.value, true)

            -- Apply offset if defined
            if pedData.offset then
                local off = GetOffsetFromEntityInWorldCoords(ped.value,
                    pedData.offset.x, pedData.offset.y, pedData.offset.z)
                SetEntityCoords(ped.value, off.x, off.y, off.z - 1.0)
            end

            -- Apply heading
            if pedData.heading then
                local heading = coords.w or (pedData.heading + 0.0)
                SetEntityHeading(ped.value, heading)
            end

            -- Register interaction zone
            local zoneOptions = options or ped.options
            if zoneOptions then
                ped.zone = Utils.createEntityPoint({
                    entity  = ped.value,
                    bone    = 24816,
                    radius  = 2.0,
                    options = zoneOptions,
                }, targetCallback or ped.target)
            end
        end,

        onExit = function()
            if ped.value then
                DeleteEntity(ped.value)
                ped.value = nil

                if ped.zone then
                    ped.zone:remove()
                    ped.zone = nil
                end
            end
            SetModelAsNoLongerNeeded(pedData.model)
        end,
    })

    -- Remove ped and its lib.points entry
    function ped.remove()
        point:onExit()
        point:remove()
    end

    -- Update or assign interaction options at runtime
    function ped.addOptions(newOptions, newTarget)
        ped.options = newOptions
        ped.target  = newTarget
        if ped.value then
            ped.zone = Utils.createEntityPoint({
                entity  = ped.value,
                radius  = 2.0,
                options = ped.options,
            }, ped.target)
        end
        return ped
    end

    function ped.disableOptions()
        if ped.zone then
            ped.zone:remove()
            ped.zone = nil
        end
    end

    -- Release ped to ambient population control
    function ped.free()
        ped.disableOptions()

        local originalExit = point.onExit
        point.onExit = function()
            originalExit()
            point:remove()
        end

        SetEntityInvincible(ped.value, false)
        SetBlockingOfNonTemporaryEvents(ped.value, false)
        FreezeEntityPosition(ped.value, false)
        SetEntityAsNoLongerNeeded(ped.value)
    end

    function ped.markAsNotNeeded()
        ped.disableOptions()
        local orig = point.onExit
        point.onExit = function() orig() point:remove() end
    end

    function ped.get()
        return ped.value
    end

    -- Track by invoking resource for cleanup
    local caller = GetInvokingResource()
    if caller then
        pedRegistry[caller] = pedRegistry[caller] or {}
        table.insert(pedRegistry[caller], ped)
    end

    return ped
end

-- ──────────────────────────────────────────────────────────────────────────────
-- createProp(coords, propData, options?, targetCallback?)
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.createProp(coords, propData, options, targetCallback)
    if not IsModelValid(propData.model) then
        error(('Invalid prop model: %s'):format(propData.model))
    end

    -- Ensure w component
    coords = vector4(coords.x, coords.y, coords.z, coords.w or 0.0)

    local prop       = {}
    local spawnDist  = Config.SpawnDistance or 100.0

    local point = lib.points.new({
        coords   = coords.xyz,
        distance = spawnDist,

        onEnter = function()
            lib.requestModel(propData.model)
            prop.value = CreateObjectNoOffset(propData.model, coords.x, coords.y, coords.z, false, false)
            FreezeEntityPosition(prop.value, true)

            if coords.w then
                SetEntityHeading(prop.value, coords.w + 0.0)
            end

            if propData.offset then
                local off = Utils.offsetCoords(coords, propData.offset.x, propData.offset.y, propData.offset.z)
                SetEntityCoordsNoOffset(prop.value, off.x, off.y, off.z)
            end

            if propData.rotation then
                SetEntityRotation(prop.value,
                    propData.rotation.x,
                    propData.rotation.y,
                    coords.w + 0.0 + propData.rotation.z)
            end

            local zoneOptions = options or prop.options
            if zoneOptions then
                prop.zone = Utils.createInteractionPoint({
                    coords  = coords,
                    radius  = 2.0,
                    options = zoneOptions,
                }, targetCallback or prop.target)
            end
        end,

        onExit = function()
            if prop.value then
                DeleteEntity(prop.value)
                prop.value = nil

                if prop.zone then
                    prop.zone:remove()
                    prop.zone = nil
                end
            end
            SetModelAsNoLongerNeeded(propData.model)
        end,
    })

    function prop.remove()
        point:onExit()
        point:remove()
    end

    function prop.addOptions(newOptions, newTarget)
        prop.options = newOptions
        prop.target  = newTarget
        if prop.value then
            prop.zone = Utils.createInteractionPoint({
                coords  = coords,
                radius  = 2.0,
                options = prop.options,
            }, prop.target)
        end
        return prop
    end

    function prop.disableOptions()
        if prop.zone then
            prop.zone:remove()
            prop.zone = nil
        end
    end

    function prop.get()
        return prop.value
    end

    local caller = GetInvokingResource()
    if caller then
        pedRegistry[caller] = pedRegistry[caller] or {}
        table.insert(pedRegistry[caller], prop)
    end

    return prop
end

-- ──────────────────────────────────────────────────────────────────────────────
-- distanceCheck(a, b, maxDist?)
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.distanceCheck(a, b, maxDist)
    maxDist = maxDist or Config.MaxDistance

    if type(a) == 'number' then a = GetEntityCoords(a) end
    if type(b) == 'number' then b = GetEntityCoords(b) end

    if not a or not b then return false end

    return maxDist >= #(a.xyz - b.xyz)
end

-- ──────────────────────────────────────────────────────────────────────────────
-- distanceWait(coords, maxDist) — yield until player is within range
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.distanceWait(coords, maxDist)
    while true do
        local pedCoords = GetEntityCoords(cache.ped)
        if not (maxDist < #(pedCoords - coords.xyz)) then break end
        Wait(200)
    end
end

-- ──────────────────────────────────────────────────────────────────────────────
-- createBlip(coords, blipData?)
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.createBlip(coords, blipData)
    local blip = { value = 0 }

    function blip.remove()
        RemoveBlip(blip.value)
    end

    if not blipData then return blip end

    blip.value = AddBlipForCoord(coords.x, coords.y)

    SetBlipSprite(blip.value,  blipData.Sprite  or blipData.sprite)
    SetBlipDisplay(blip.value, 4)
    SetBlipScale(blip.value,   (blipData.Size   or blipData.size)  + 0.0)
    SetBlipColour(blip.value,  blipData.Color   or blipData.color)
    SetBlipAsShortRange(blip.value, true)

    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(blipData.Name or blipData.name)
    EndTextCommandSetBlipName(blip.value)

    local caller = GetInvokingResource()
    if caller then
        blipRegistry[caller] = blipRegistry[caller] or {}
        table.insert(blipRegistry[caller], blip)
    end

    return blip
end

-- ──────────────────────────────────────────────────────────────────────────────
-- createRadiusBlip(coords, sprite, radius, color)
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.createRadiusBlip(coords, sprite, radius, color)
    local blip = {}

    function blip.remove()
        RemoveBlip(blip.value)
    end

    blip.value = AddBlipForRadius(coords.x, coords.y, coords.z, radius)
    SetBlipDisplay(blip.value, 4)
    SetBlipScale(blip.value,   radius)
    SetBlipColour(blip.value,  color)
    SetBlipAsShortRange(blip.value, true)
    SetBlipAlpha(blip.value, 150)

    local caller = GetInvokingResource()
    if caller then
        blipRegistry[caller] = blipRegistry[caller] or {}
        table.insert(blipRegistry[caller], blip)
    end

    return blip
end

-- ──────────────────────────────────────────────────────────────────────────────
-- createEntityBlip(entity, blipData)
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.createEntityBlip(entity, blipData)
    local blip = {}

    function blip.remove()
        RemoveBlip(blip.value)
    end

    blip.value = AddBlipForEntity(entity)
    SetBlipSprite(blip.value,  blipData.Sprite  or blipData.sprite)
    SetBlipDisplay(blip.value, 4)
    SetBlipScale(blip.value,   blipData.Size    or blipData.size)
    SetBlipColour(blip.value,  blipData.Color   or blipData.color)
    SetBlipAsShortRange(blip.value, true)

    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(blipData.Name or blipData.name)
    EndTextCommandSetBlipName(blip.value)

    local caller = GetInvokingResource()
    if caller then
        blipRegistry[caller] = blipRegistry[caller] or {}
        table.insert(blipRegistry[caller], blip)
    end

    return blip
end

-- ──────────────────────────────────────────────────────────────────────────────
-- makeEntityFaceEntity / makeEntityFaceCoords / getHeadingToCoords
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.makeEntityFaceEntity(a, b)
    local ac = GetEntityCoords(a, true)
    local bc = GetEntityCoords(b, true)
    SetEntityHeading(a, GetHeadingFromVector_2d(bc.x - ac.x, bc.y - ac.y))
end

function Utils.makeEntityFaceCoords(entity, coords)
    local ec = GetEntityCoords(entity, true)
    SetEntityHeading(entity, GetHeadingFromVector_2d(coords.x - ec.x, coords.y - ec.y))
end

function Utils.getHeadingToCoords(entity, coords)
    local ec = GetEntityCoords(entity, true)
    return GetHeadingFromVector_2d(coords.x - ec.x, coords.y - ec.y)
end

-- ──────────────────────────────────────────────────────────────────────────────
-- hasJobs(jobs) — check if the local player has one of the given jobs
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.hasJobs(jobs)
    if type(jobs) == 'string' then jobs = { jobs } end
    local current = Framework.getJob()
    for _, job in ipairs(jobs) do
        if current == job then return true end
    end
    return false
end

function Utils.isPolice()
    return Utils.hasJobs(Config.Dispatch.Jobs)
end

-- ──────────────────────────────────────────────────────────────────────────────
-- addKeybind(data) — wrap lib.addKeybind with listener support
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.addKeybind(data)
    local keybind   = lib.addKeybind(data)
    local listeners = {}

    function keybind.addListener(id, callback)
        listeners[id] = function(args)
            CreateThread(function() callback(args) end)
        end
    end

    function keybind.removeListener(id)
        listeners[id] = nil
    end

    function keybind.onReleased(args)
        for _, fn in pairs(listeners) do fn() end
    end

    -- Vytvoř wrapper pro getCurrentKey, který zachová správný kontext
    local originalGetCurrentKey = keybind.getCurrentKey
    if originalGetCurrentKey then
        keybind.getCurrentKey = function()
            return originalGetCurrentKey(keybind)
        end
    else
        -- Fallback funkce, pokud getCurrentKey neexistuje
        keybind.getCurrentKey = function()
            return data.defaultKey or "E"
        end
    end
    
    return keybind
end

-- ──────────────────────────────────────────────────────────────────────────────
-- setTimeout(delay, callback) — cancellable client-side timeout
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.setTimeout(delay, callback)
    local active = true
    local handle = {}
    function handle.cancel() active = false end
    SetTimeout(delay, function() if active then callback() end end)
    return handle
end

-- ──────────────────────────────────────────────────────────────────────────────
-- offsetCoords(origin, forward, right, up, headingOffset?)
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.offsetCoords(origin, forward, right, up, headingOffset)
    local rad = math.rad(origin.w)
    local cos = math.cos(rad)
    local sin = math.sin(rad)
    return vector4(
        origin.x + (forward * cos - right * sin),
        origin.y + (forward * sin + right * cos),
        origin.z + up,
        origin.w  + (headingOffset or 0.0)
    )
end

-- ──────────────────────────────────────────────────────────────────────────────
-- Interaction keybind pool (grows as more option-slots are needed)
-- ──────────────────────────────────────────────────────────────────────────────
local resourcePrefix   = GetCurrentResourceName():gsub(' ', '') .. 'interact'
local interactKeybinds = {}
local activeZone       = nil   -- { zone, labels, callbacks, args }

local function ensureKeybinds(count)
    local existing = #interactKeybinds
    if count <= existing then return end

    for i = existing + 1, count do
        local idx      = i
        local pressed  = false

        local kb = lib.addKeybind({
            name        = resourcePrefix .. idx,
            defaultKey  = Config.Keybinds[idx],
            description = 'Interaction key',

            onReleased = function()
                if pressed or not activeZone then return end
                local cb   = activeZone.callbacks[idx]
                local args = activeZone.args[idx]
                if not cb then return end

                pressed = true
                pcall(cb, type(args) == 'table' and table.unpack(args) or args)
                pressed = false
            end,
        })

        interactKeybinds[idx] = kb
    end
end

-- ──────────────────────────────────────────────────────────────────────────────
-- Internal: check if label list changed (avoids flickering re-renders)
-- ──────────────────────────────────────────────────────────────────────────────
local function labelsChanged(a, b)
    if #a ~= #b then return true end
    for i = 1, #a do
        if a[i] ~= b[i] then return true end
    end
    return false
end

-- ──────────────────────────────────────────────────────────────────────────────
-- Internal: build and show the textUI for a zone's visible options
-- ──────────────────────────────────────────────────────────────────────────────
local function showZoneUI(zone)
    ensureKeybinds(#zone.options)

    local labels    = {}
    local callbacks = {}
    local args      = {}
    local kbIndex   = 1

    for _, opt in ipairs(zone.options) do
        if not opt.canInteract or opt.canInteract() then
            local key = interactKeybinds[kbIndex] and interactKeybinds[kbIndex].currentKey or '?'
            table.insert(labels, ('[%s] - %s'):format(key, opt.label))
            table.insert(callbacks, opt.onSelect)
            if opt.args then args[kbIndex] = opt.args end
            kbIndex = kbIndex + 1
        end
    end

    -- Skip re-render if labels are identical and zone is the same
    if activeZone and activeZone.zone == zone then
        if not labelsChanged(activeZone.labels, labels) then return end
    end

    local text = table.concat(labels, '\n  \n  ')

    if activeZone and activeZone.zone ~= zone then
        HideUI()
        SetTimeout(60, function()
            ShowUI(text, zone.options[1].icon)
        end)
    else
        ShowUI(text, zone.options[1].icon)
    end

    activeZone = { zone = zone, labels = labels, callbacks = callbacks, args = args }
end

-- ──────────────────────────────────────────────────────────────────────────────
-- Internal: hide UI when leaving a zone
-- ──────────────────────────────────────────────────────────────────────────────
local function hideZoneUI(zone)
    if activeZone and activeZone.zone == zone then
        HideUI()
        activeZone = nil
        Wait(60)
    end
end

-- ──────────────────────────────────────────────────────────────────────────────
-- generateUID() — random xxxx-xxxx-xxxx style ID
-- ──────────────────────────────────────────────────────────────────────────────
local function generateUID()
    return ('xxxx-xxxx-xxxx'):gsub('[xy]', function(c)
        local n = c == 'x' and math.random(0, 15) or math.random(8, 11)
        return string.format('%x', n)
    end)
end

-- ──────────────────────────────────────────────────────────────────────────────
-- Zone cleanup registry
-- ──────────────────────────────────────────────────────────────────────────────
local zoneRegistry = {}

AddEventHandler('onResourceStop', function(resourceName)
    if zoneRegistry[resourceName] then
        for _, zone in ipairs(zoneRegistry[resourceName]) do
            zone.remove()
        end
        table.wipe(zoneRegistry[resourceName])
        zoneRegistry[resourceName] = nil
    end
end)

-- ──────────────────────────────────────────────────────────────────────────────
-- createInteractionPoint({ coords, radius, options }, useTarget?)
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.createInteractionPoint(data, useTarget)
    if type(data) ~= 'table' then return end
    if useTarget == nil then useTarget = Config.Target end

    data.coords = data.coords.xyz

    if useTarget then
        -- qb-target / qtarget handling
        local zone = {}

        -- Prepare options: convert onSelect -> event, format icons
        for _, opt in pairs(data.options) do
            if opt.onSelect then
                local eventName = ('options_%p'):format(opt.onSelect)
                local cb        = opt.onSelect
                AddEventHandler(eventName, function()
                    cb(opt.args)
                end)
                opt.event    = eventName
                opt.onSelect = nil
            end
            if opt.icon then
                opt.icon = ('fa-solid fa-%s'):format(opt.icon)
            end
        end

        if GetResourceState('qb-target') == 'started' then
            local id = exports.qb-target:addSphereZone({
                coords  = data.coords,
                radius  = data.radius,
                options = data.options,
            })
            function zone.remove()
                exports.qb-target:removeZone(id)
            end
        else
            -- qtarget fallback
            local zoneName = ('zone_%s'):format(generateUID())
            exports.qtarget:AddBoxZone(zoneName, data.coords.xyz, data.radius, data.radius, {
                name      = zoneName,
                heading   = 0.0,
                debugPoly = false,
                minZ      = data.coords.z - data.radius / 2,
                maxZ      = data.coords.z + data.radius / 2,
            }, {
                options  = data.options,
                distance = data.radius,
            })
            function zone.remove()
                exports.qtarget:RemoveZone(zoneName)
            end
        end

        local caller = GetInvokingResource()
        if caller then
            zoneRegistry[caller] = zoneRegistry[caller] or {}
            table.insert(zoneRegistry[caller], zone)
        end

        return zone

    else
        -- Text UI / prompt mode
        local point
        local handle = {}
        local removed = false

        if Config.Prompts.Enabled then
            point = API.addPoint({
                coords   = data.coords,
                distance = data.radius,
                options  = data.options,
            })
        else
            point = lib.points.new({
                coords   = data.coords,
                distance = data.radius,
                onEnter  = showZoneUI,
                onExit   = hideZoneUI,
                nearby   = function(pt)
                    if activeZone and activeZone.zone == pt then
                        showZoneUI(pt)
                        Wait(200)
                    end
                end,
            })
            point.options = data.options
        end

        function handle.remove()
            if removed then return end
            removed = true
            if point.onExit then point:onExit() end
            point:remove()
        end

        local caller = GetInvokingResource()
        if caller then
            zoneRegistry[caller] = zoneRegistry[caller] or {}
            table.insert(zoneRegistry[caller], handle)
        end

        return handle
    end
end

-- ──────────────────────────────────────────────────────────────────────────────
-- createEntityPoint({ entity, bone?, offset?, radius, options }, useTarget?)
-- ──────────────────────────────────────────────────────────────────────────────
function Utils.createEntityPoint(data, useTarget)
    if type(data) ~= 'table' then return {} end
    if useTarget == nil then useTarget = Config.Target end

    if useTarget then
        local zone = {}

        for _, opt in pairs(data.options) do
            if opt.onSelect then
                local eventName = ('options_%p'):format(opt.onSelect)
                local cb        = opt.onSelect
                AddEventHandler(eventName, function()
                    cb(opt.args)
                end)
                opt.event    = eventName
                opt.onSelect = nil
            end
            if opt.icon then
                opt.icon = ('fa-solid fa-%s'):format(opt.icon)
            end
        end

        exports.qtarget:AddTargetEntity(data.entity, {
            options  = data.options,
            distance = data.radius,
        })

        function zone.remove()
            exports.qtarget:RemoveTargetEntity(data.entity)
        end

        local caller = GetInvokingResource()
        if caller then
            zoneRegistry[caller] = zoneRegistry[caller] or {}
            table.insert(zoneRegistry[caller], zone)
        end

        return zone

    else
        local point  = API.addLocalEntity(data)
        local handle = {}

        function handle.remove()
            point:remove()
        end

        local caller = GetInvokingResource()
        if caller then
            zoneRegistry[caller] = zoneRegistry[caller] or {}
            table.insert(zoneRegistry[caller], handle)
        end

        return handle
    end
end

-- ──────────────────────────────────────────────────────────────────────────────
-- Item label cache (populated via callback from server)
-- ──────────────────────────────────────────────────────────────────────────────
local itemLabels = nil

lib.callback('JobsSystem_bridge:getItemLabels', false, function(labels)
    itemLabels = labels
end)

function Utils.getItemLabel(item)
    if not itemLabels then return 'ITEM_NOT_FOUND' end
    return itemLabels[item] or itemLabels[item:upper()] or 'ITEM_NOT_FOUND'
end

-- getImageUrl(path)
function Utils.getImageUrl(path)
    return ('https://JobsSystem-scripts.com/%s'):format(path)
end

-- ──────────────────────────────────────────────────────────────────────────────
-- entityStateHandler(stateName, onSet, clearOnSet?)
-- Listens for entity statebag changes and fires a callback with the entity.
-- ──────────────────────────────────────────────────────────────────────────────
local function resolveEntityFromBag(bagName)
    local netId = tonumber(bagName:gsub('entity:', ''), 10)

    local entity = lib.waitFor(function()
        if NetworkDoesEntityExistWithNetworkId(netId) then
            return NetworkGetEntityFromNetworkId(netId)
        end
    end, ('Statebag timed out while awaiting entity creation: %s'):format(bagName), 10000)

    if not entity then
        error(('Statebag received invalid entity: %s'):format(bagName))
    end

    return entity, netId
end

function Utils.entityStateHandler(stateName, onSet, clearOnSet)
    local caller = GetInvokingResource()

    stateBagHandlers[caller] = stateBagHandlers[caller] or {}

    local handler = AddStateBagChangeHandler(stateName, '', function(bagName, _, value)
        local entity, netId = resolveEntityFromBag(bagName)
        if entity and value then
            onSet(entity, value, netId, bagName)

            if clearOnSet then
                Wait(0)
                Entity(entity).state:set(stateName, nil, true)
            end
        end
    end)

    local idx = #stateBagHandlers[caller] + 1
    stateBagHandlers[caller][idx] = handler
end

-- ──────────────────────────────────────────────────────────────────────────────
-- Cleanup on resource stop
-- ──────────────────────────────────────────────────────────────────────────────
AddEventHandler('onResourceStop', function(resourceName)
    -- Clean up peds/props
    if pedRegistry[resourceName] then
        for _, obj in ipairs(pedRegistry[resourceName]) do obj.remove() end
        table.wipe(pedRegistry[resourceName])
        pedRegistry[resourceName] = nil
    end

    -- Clean up blips
    if blipRegistry[resourceName] then
        for _, blip in ipairs(blipRegistry[resourceName]) do blip.remove() end
        table.wipe(blipRegistry[resourceName])
        blipRegistry[resourceName] = nil
    end

    -- Clean up statebag handlers
    if stateBagHandlers[resourceName] then
        for _, handler in ipairs(stateBagHandlers[resourceName]) do
            RemoveStateBagChangeHandler(handler)
        end
        table.wipe(stateBagHandlers[resourceName])
        stateBagHandlers[resourceName] = nil
    end
end)

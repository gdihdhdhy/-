
-- Job File Parser
-- Parses job configuration files with conditional resource annotations

Parser = {}

-- Validate field type
local function validateType(value, expectedType, allowNil)
    if not value then
        return allowNil
    end
    
    local valueType = type(value)
    return valueType == expectedType
end

-- Validate job data structure
local function validateJobData(jobData)
    -- Validate required string fields
    if not validateType(jobData.name, "string", false) then
        return false, "the name field needs to be a valid string."
    end
    
    if not validateType(jobData.label, "string", false) then
        return false, "the label field needs to be a valid string."
    end
    
    -- Validate required arrays
    if not validateType(jobData.grades, "array", false) then
        return false, "provide valid grades in an array."
    end
    
    -- Validate optional arrays/tables
    if not validateType(jobData.blips, "array", true) then
        return false, "provide valid blips data in an array."
    end
    
    if not validateType(jobData.cloakrooms, "table", true) then
        return false, "provide valid cloakrooms table."
    end
    
    if not validateType(jobData.collecting, "array", true) then
        return false, "provide valid collecting data in an array."
    end
    
    if not validateType(jobData.crafting, "array", true) then
        return false, "provide valid crafting data in an array."
    end
    
    if not validateType(jobData.garages, "array", true) then
        return false, "provide valid garage data in an array."
    end
    
    if not validateType(jobData.selling, "array", true) then
        return false, "provide valid selling data in an array."
    end
    
    if not validateType(jobData.shops, "array", true) then
        return false, "provide valid shops in an array."
    end
    
    if not validateType(jobData.stashes, "array", true) then
        return false, "provide valid stashes in an array."
    end
    
    return true
end

-- Validate annotation syntax
local function validateAnnotations(fileContent)
    local currentBlock = nil
    
    for line in fileContent:gmatch("[^\n]+") do
        -- Check for @if_resource or @if_not_resource
        local isIfBlock = line:find("---@if_resource") or line:find("---@if_not_resource")
        
        if isIfBlock then
            if currentBlock then
                print("Invalid: " .. line)
                return false
            end
            
            local resourceName = line:match("%((.-)%)")
            if not resourceName then
                print("Invalid: " .. line)
                return false
            end
            
            currentBlock = "if_resource"
            
        -- Check for @elseif_resource or @elseif_not_resource
        elseif line:find("---@elseif_resource") or line:find("---@elseif_not_resource") then
            if currentBlock ~= "if_resource" and currentBlock ~= "elseif_resource" then
                return false
            end
            
            local resourceName = line:match("%((.-)%)")
            if not resourceName then
                return false
            end
            
            currentBlock = "elseif_resource"
            
        -- Check for @else
        elseif line:find("---@else") then
            if currentBlock ~= "if_resource" and currentBlock ~= "elseif_resource" then
                return false
            end
            
            if line:match("%((.-)%)") then
                return false
            end
            
            currentBlock = "else"
            
        -- Check for @end
        elseif line:find("---@end") then
            if not currentBlock then
                return false
            end
            
            if line:match("%((.-)%)") then
                return false
            end
            
            currentBlock = false
        end
    end
    
    -- Ensure all blocks are closed
    if currentBlock then
        return false
    end
    
    return true
end

-- Check if resource is started
local function isResourceStarted(resourceName)
    return GetResourceState(resourceName) == "started"
end

-- Process conditional annotations
local function processAnnotations(fileContent)
    if not validateAnnotations(fileContent) then
        return
    end
    
    local result = ""
    local mode = "reading"
    
    for line in fileContent:gmatch("[^\n]+") do
        -- Handle @if_resource
        if line:find("---@if_resource") and mode == "reading" then
            local resourceName = line:match("%((.-)%)")
            if isResourceStarted(resourceName) then
                mode = "reading_to_end"
            else
                mode = "skipping"
            end
            
        -- Handle @if_not_resource
        elseif line:find("---@if_not_resource") and mode == "reading" then
            local resourceName = line:match("%((.-)%)")
            if not isResourceStarted(resourceName) then
                mode = "reading_to_end"
            else
                mode = "skipping"
            end
            
        -- Handle @elseif_resource
        elseif line:find("---@elseif_resource") then
            if mode == "skipping" then
                local resourceName = line:match("%((.-)%)")
                if isResourceStarted(resourceName) then
                    mode = "reading_to_end"
                end
            elseif mode == "reading_to_end" then
                mode = "skipping_to_end"
            end
            
        -- Handle @elseif_not_resource
        elseif line:find("---@elseif_not_resource") then
            if mode == "skipping" then
                local resourceName = line:match("%((.-)%)")
                if not isResourceStarted(resourceName) then
                    mode = "reading_to_end"
                end
            elseif mode == "reading_to_end" then
                mode = "skipping_to_end"
            end
            
        -- Handle @else
        elseif line:find("---@else") then
            if mode == "skipping" then
                mode = "reading_to_end"
            else
                mode = "skipping"
            end
            
        -- Handle @end
        elseif line:find("---@end") then
            if mode == "skipping" or mode == "reading_to_end" or mode == "skipping_to_end" then
                mode = "reading"
            end
            
        -- Include line if in reading mode
        elseif mode == "reading" or mode == "reading_to_end" then
            result = result .. "\n" .. line
        end
    end
    
    return result
end

-- Parse job file
function Parser.parse(fileContent)
    -- Process annotations
    local processedContent = processAnnotations(fileContent)
    
    -- Load the Lua code
    local loadedFunc, loadError = load(processedContent or fileContent)
    
    if not loadedFunc then
        return false, "Couldn't load %s due to a syntax error: " .. loadError
    end
    
    -- Execute and get job data
    local jobData = loadedFunc()
    
    if not jobData then
        return false, "Couldn't load %s due to no return statement."
    end
    
    -- Validate job data
    local isValid, validationError = validateJobData(jobData)
    
    if isValid then
        -- Warn if annotations were ignored
        if not processedContent then
            warn(string.format("Ignoring annotations in job %s.", jobData.name))
        end
        
        return true, jobData
    else
        return false, "Couldn't load %s due to invalid data: " .. validationError
    end
end
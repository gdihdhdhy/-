
local cachedJobs = nil
local depletedResources = {}
local activeCollectors = {}

-- Function to stop collecting for a specific player
local function stopCollecting(playerId, reason)
    TriggerClientEvent("JobsSystem_unijob:stopCollecting", playerId, reason)
    
    local collector = activeCollectors[playerId]
    if collector then
        collector.clear()
        -- Use a timeout to ensure any pending loop task finishes before clearing the table entry
        SetTimeout(1000, function()
            if activeCollectors[playerId] == collector then
                activeCollectors[playerId] = nil
            end
        end)
    end
end

-- Event listener to stop collecting
RegisterNetEvent("JobsSystem_unijob:stopCollecting", function()
    stopCollecting(source)
end)

-- Helper to start a repeating thread that can be cleared
local function startIntervalThread(callback, interval)
    local running = true
    local adjustedInterval = interval or 0
    
    CreateThread(function()
        while running do
            Wait(adjustedInterval)
            if running then
                callback()
            else
                break
            end
        end
    end)

    return {
        clear = function() running = false end
    }
end

-- Callback to handle a player starting the collection process
lib.callback.register("JobsSystem_unijob:startCollecting", function(playerId, index, locIndex)
    local player = Framework.getPlayerFromId(playerId)
    if not player then return end

    local jobName = player:getJob()
    local jobData = cachedJobs and cachedJobs[jobName]
    if not jobData then return end

    local config = jobData.collecting[index]
    local location = config and config.locations[locIndex]

    if not config or not location then return end

    -- Distance check
    local checkRadius = (config.radius or Config.defaultRadius) * 1.25
    if not Utils.distanceCheck(playerId, location, checkRadius) then
        return
    end

    -- Already collecting?
    if activeCollectors[playerId] then return end

    -- Check required item
    if config.requiredItem then
        if not player:hasItem(config.requiredItem) then
            return false, locale("missing_item", Utils.getItemLabel(config.requiredItem))
        end
    end

    -- Resource depletion logic
    if config.max then
        if not depletedResources[jobName] then depletedResources[jobName] = {} end
        if not depletedResources[jobName][index] then depletedResources[jobName][index] = {} end
        
        if not depletedResources[jobName][index][locIndex] then
            depletedResources[jobName][index][locIndex] = config.max
        end

        if depletedResources[jobName][index][locIndex] <= 0 then
            return false, locale("collecting_depleted")
        end
    end

    -- Start the collection loop
    activeCollectors[playerId] = startIntervalThread(function()
        -- Re-fetch player each tick to avoid stale reference (e.g. player disconnected)
        local player = Framework.getPlayerFromId(playerId)
        if not player then
            stopCollecting(playerId)
            return
        end

        -- Re-verify distance
        local checkRadius = (config.radius or Config.defaultRadius) * 1.25
        if not Utils.distanceCheck(playerId, location, checkRadius) then
            stopCollecting(playerId, locale("too_far"))
            return
        end

        -- Handle depletion
        if config.max then
            if depletedResources[jobName][index][locIndex] <= 0 then
                stopCollecting(playerId, locale("collecting_depleted"))
                
                -- Resource recovery timeout
                if config.recover then
                    SetTimeout(config.recover, function()
                        depletedResources[jobName][index][locIndex] = config.max
                    end)
                end
                return
            end
            depletedResources[jobName][index][locIndex] = depletedResources[jobName][index][locIndex] - 1
        end

        -- Calculate items to add
        local itemsToAdd = {}
        for _, itemData in ipairs(config.items) do
            local count = itemData.count
            if type(count) == "table" then
                count = math.random(count.min, count.max)
            end

            if not player:canCarryItem(itemData.name, count) then
                stopCollecting(playerId)
                return
            end

            table.insert(itemsToAdd, { name = itemData.name, count = count })
        end

        -- Add items
        local logItems = {}
        for _, item in ipairs(itemsToAdd) do
            player:addItem(item.name, item.count)
            table.insert(logItems, string.format("%sx %s", item.count, item.name))
        end

        -- Discord Logging
        if Webhooks.settings.collecting then
            Logs.send(playerId, jobName, string.format("Collected %s.", table.concat(logItems, ", ")))
        end

    end, config.duration + 100)

    return true
end)

local Collecting = {}

-- Initialize the module
function Collecting.init(jobs)
    cachedJobs = jobs
end

_G.Collecting = Collecting

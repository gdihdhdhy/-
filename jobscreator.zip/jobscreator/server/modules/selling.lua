
local cachedJobs = nil
local activeSellers = {}

-- Function to handle stopping the selling process for a player
local function stopSelling(playerId, reason)
    TriggerClientEvent("JobsSystem_unijob:stopSelling", playerId, reason)
    activeSellers[playerId] = nil
end

-- Event: Handled manual stop or disconnection
RegisterNetEvent("JobsSystem_unijob:stopSelling", function()
    activeSellers[source] = nil
end)

-- Callback: Start selling items
lib.callback.register("JobsSystem_unijob:startSelling", function(playerId, index, locIndex, itemIndex, amount)
    local player = Framework.getPlayerFromId(playerId)
    if not player then return end

    local jobName = player:getJob()
    local jobData = cachedJobs and cachedJobs[jobName]
    if not jobData then return end

    local sellConfig = jobData.selling[index]
    local location = sellConfig and sellConfig.locations[locIndex]
    local item = sellConfig and sellConfig.items[itemIndex]

    if not sellConfig or not location or not item then return end

    -- Distance check
    local checkRadius = (sellConfig.radius or Config.defaultRadius) * 5.0
    if not Utils.distanceCheck(playerId, location, checkRadius) then
        return
    end

    -- Already selling?
    if activeSellers[playerId] then return end

    -- Verify player has items
    if player:getItemCount(item.name) < amount then
        return false, locale("not_enough_items")
    end

    -- Helper to process a sale
    local function processSale(count)
        local pricePerItem = type(item.price) == "number" and item.price or math.random(item.price.min, item.price.max)
        local totalReward = pricePerItem * count
        local currency = item.currency or "money"

        if totalReward <= 0 then return end

        if currency == "society" then
            if sellConfig.employeePercentage then
                local employeeCut = math.floor(totalReward * sellConfig.employeePercentage / 100)
                local societyCut = totalReward - employeeCut

                player:addAccountMoney("money", employeeCut)
                Editable.addSocietyMoney(jobName, societyCut)
            else
                Editable.addSocietyMoney(jobName, totalReward)
            end
        else
            player:addAccountMoney(currency, totalReward)
        end

        -- Notify player
        local message = count == 1 and locale("sold_item", totalReward) or locale("sold_items", totalReward)
        LR.notify(playerId, message, "success")

        -- Discord Logging
        if Webhooks.settings.selling then
            Logs.send(playerId, jobName, string.format("Sold %sx %s for %s$.", count, Utils.getItemLabel(item.name), totalReward))
        end
    end

    -- Logic: Sell all at once
    if sellConfig.sellAtOnce then
        player:removeItem(item.name, amount)
        SetTimeout(sellConfig.duration, function()
            processSale(amount)
        end)
        return true
    end

    -- Logic: Incremental selling loop
    activeSellers[playerId] = true
    CreateThread(function()
        local remaining = amount
        while activeSellers[playerId] do
            Wait(sellConfig.duration + 100)
            
            -- Re-verify state each tick
            if not activeSellers[playerId] then break end

            if not Utils.distanceCheck(playerId, location, checkRadius) then
                stopSelling(playerId, locale("too_far"))
                break
            end

            if player:getItemCount(item.name) <= 0 then
                stopSelling(playerId)
                break
            end

            player:removeItem(item.name, 1)
            processSale(1)
            
            remaining = remaining - 1
            if remaining <= 0 then
                stopSelling(playerId)
                break
            end
        end
    end)

    return true
end)

local Selling = {}

-- Initialize the module
function Selling.init(jobs)
    cachedJobs = jobs
end

_G.Selling = Selling

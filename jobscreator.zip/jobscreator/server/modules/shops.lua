
local cachedJobs = nil
local isOxInventoryStarted = GetResourceState("qb-inventory") == "started"
local registeredShops = {}

-- Register hook for qb-inventory logging if applicable
if isOxInventoryStarted and Webhooks.settings.shops then
    exports.qb-inventory:registerHook("buyItem", function(payload)
        local jobName = registeredShops[payload.shopType]
        if jobName then
            local currency = payload.currency or "money"
            local logMsg = string.format("Bought %sx %s for %sx %s.", payload.count, payload.itemName, payload.totalPrice, currency)
            Logs.send(payload.source, jobName, logMsg)
        end
    end)
end

-- Callback: Handle item purchase for custom shops (non-OX)
lib.callback.register("JobsSystem_unijob:buyItem", function(playerId, shopIndex, locIndex, itemIndex, amount)
    local player = Framework.getPlayerFromId(playerId)
    if not player then return false end

    local jobName = player:getJob()
    local jobData = cachedJobs and cachedJobs[jobName]
    local shopConfig = jobData and jobData.shops[shopIndex]
    
    if not shopConfig then return false end

    local location = shopConfig.locations[locIndex]
    local item = shopConfig.items[itemIndex]

    if location and item then
        -- Security & Grade Checks
        if not Utils.distanceCheck(playerId, location, 5.0) then
            return false
        end

        if item.grade and player:getJobGrade() < item.grade then
            return false
        end
    else
        return false
    end

    local totalPrice = item.price * amount
    if totalPrice <= 0 then return false end

    local currency = item.currency or "money"
    if player:getAccountMoney(currency) < totalPrice then
        return false, locale("not_enough_money")
    end

    -- Process purchase with a delay (simulating transaction)
    SetTimeout(3000, function()
        -- Re-verify funds after delay
        if player:getAccountMoney(currency) < totalPrice then return end

        player:removeAccountMoney(currency, totalPrice)
        player:addItem(item.name, amount)

        -- Note: Logs for custom shops could be added here if needed
    end)

    return true
end)

-- Helper to register a shop with the framework and track it locally
local function registerShop(jobData, shopId, config)
    Editable.registerShop(jobData, shopId, config)
    registeredShops[shopId] = jobData.name
end

-- Helper to set up all shops for a specific job
local function setupJobShops(jobData)
    if not jobData.shops then return end

    for i, config in ipairs(jobData.shops) do
        local shopId = string.format("%s_shop_%s", jobData.name, i)
        registerShop(jobData, shopId, config)
    end
end

local Shops = {}

-- Full initialization for all jobs
function Shops.init(jobs)
    cachedJobs = jobs
    for _, jobData in pairs(jobs) do
        setupJobShops(jobData)
    end
end

-- Refresh shops for a specific job
function Shops.update(jobData)
    setupJobShops(jobData)
end

_G.Shops = Shops

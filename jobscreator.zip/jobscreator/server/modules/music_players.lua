
local cachedJobs = nil
local activeMusicPlayers = {}

-- Helper to check if a player can control a specific music player
local function canControlMusic(playerId, soundId)
    local player = Framework.getPlayerFromId(playerId)
    if not player then return false end

    local musicData = activeMusicPlayers[soundId]
    if not musicData then return false end

    -- Check job and distance
    local playerJob = player:getJob()
    if playerJob == musicData.job.name then
        if Utils.distanceCheck(playerId, musicData.coords, 10.0) then
            return true
        end
    end

    return false
end

-- Event: Play music from a URL
RegisterNetEvent("JobsSystem_unijob:playMusic", function(soundId, url)
    local playerId = source
    if not canControlMusic(playerId, soundId) then return end

    local musicData = activeMusicPlayers[soundId]
    
    -- Check if URL is from YouTube (security/best practice for xsound)
    if not string.find(url, "youtube.com") and not string.find(url, "youtu.be") then
        LR.notify(playerId, locale("non_youtube_url"), "error")
        return
    end

    musicData.playing = true
    exports.xsound:PlayUrlPos(-1, soundId, url, musicData.volume, musicData.coords.xyz, musicData.loop)
    
    if musicData.desk.soundDistance then
        exports.xsound:Distance(-1, soundId, musicData.desk.soundDistance)
    end
end)

-- Event: Change volume
RegisterNetEvent("JobsSystem_unijob:setDeskVolume", function(soundId, volume)
    local playerId = source
    if not canControlMusic(playerId, soundId) then return end

    local musicData = activeMusicPlayers[soundId]
    musicData.volume = volume
    exports.xsound:setVolume(-1, soundId, volume)
end)

-- Event: Pause
RegisterNetEvent("JobsSystem_unijob:pauseMusic", function(soundId)
    local playerId = source
    if not canControlMusic(playerId, soundId) then return end

    activeMusicPlayers[soundId].playing = false
    exports.xsound:Pause(-1, soundId)
end)

-- Event: Resume
RegisterNetEvent("JobsSystem_unijob:resumeMusic", function(soundId)
    local playerId = source
    if not canControlMusic(playerId, soundId) then return end

    activeMusicPlayers[soundId].playing = true
    exports.xsound:Resume(-1, soundId)
end)

-- Event: Stop/Destroy
RegisterNetEvent("JobsSystem_unijob:stopMusic", function(soundId)
    local playerId = source
    if not canControlMusic(playerId, soundId) then return end

    activeMusicPlayers[soundId].playing = false
    exports.xsound:Destroy(-1, soundId)
end)

-- Event: Toggle Loop
RegisterNetEvent("JobsSystem_unijob:setLoop", function(soundId, status)
    local playerId = source
    if not canControlMusic(playerId, soundId) then return end

    activeMusicPlayers[soundId].loop = status
    TriggerClientEvent("JobsSystem_unijob:setLoop", -1, soundId, status)
end)

local MusicPlayers = {}

-- Helper to set up players for a specific job
local function setupJobPlayers(jobData)
    if not jobData.musicPlayers then return end

    for index, config in ipairs(jobData.musicPlayers) do
        for locIndex, coords in pairs(config.locations) do
            local soundId = string.format("%s_%s_%s", jobData.name, index, locIndex)
            
            activeMusicPlayers[soundId] = {
                job = jobData,
                desk = config,
                coords = coords,
                volume = 1.0,
                playing = false,
                loop = false
            }
        end
    end
end

-- Full initialization
function MusicPlayers.init(jobs)
    cachedJobs = jobs
    for _, jobData in pairs(jobs) do
        setupJobPlayers(jobData)
    end
end

-- Refresh specific job players
function MusicPlayers.update(jobData)
    -- Remove existing players for this job
    for soundId, data in pairs(activeMusicPlayers) do
        if data.job.name == jobData.name then
            activeMusicPlayers[soundId] = nil
        end
    end
    
    setupJobPlayers(jobData)
end

_G.MusicPlayers = MusicPlayers


local cachedJobs = nil

-- Proxy callbacks to Editable functions
lib.callback.register("JobsSystem_unijob:getVehicles", Editable.getVehicles)
lib.callback.register("JobsSystem_unijob:saveVehicle", Editable.saveVehicle)
lib.callback.register("JobsSystem_unijob:buyVehicle", Editable.buyVehicle)

-- Event to handle saving/deleting temporary (job-provided) vehicles
RegisterNetEvent("JobsSystem_unijob:saveTemporaryVehicle", function(netId, index, locIndex)
    local playerId = source
    local player = Framework.getPlayerFromId(playerId)
    if not player then return end

    local jobName = player:getJob()
    local jobData = cachedJobs and cachedJobs[jobName]
    local garageConfig = jobData and jobData.garages[index]
    local location = garageConfig and garageConfig.locations[locIndex]

    if not location then return end

    local vehicle = NetworkGetEntityFromNetworkId(netId)
    Wait(500) -- Small wait for network sync

    if not DoesEntityExist(vehicle) then return end

    -- Distance check on server
    local vehicleCoords = GetEntityCoords(vehicle)
    local spawnCoords = location.spawnCoords.xyz
    local dist = #(vehicleCoords - spawnCoords)

    if dist < 10.0 then
        DeleteEntity(vehicle)
    end
end)

local Garages = {}

-- Initialize the module
function Garages.init(jobs)
    cachedJobs = jobs
end

_G.Garages = Garages

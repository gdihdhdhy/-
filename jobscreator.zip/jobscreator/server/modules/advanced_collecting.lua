
local spawnedCollectables = {}
local playersReceivedInitial = {}

-- Callback to get all currently spawned collectables for a player
lib.callback.register("JobsSystem_unijob:getCollectables", function(playerId)
    if playersReceivedInitial[playerId] then
        return
    end
    playersReceivedInitial[playerId] = true

    local results = {}
    for _, data in pairs(spawnedCollectables) do
        table.insert(results, {
            spawned = data.spawned,
            jobName = data.job.name,
            index = data.index,
            locationIndex = data.locationIndex
        })
    end
    return results
end)

-- Helper to check if a player can carry all resulting items
local function canCarryItems(player, items)
    for i = 1, #items do
        local item = items[i]
        local count = type(item.count) == "table" and item.count.max or item.count
        if not player:canCarryItem(item.name, count) then
            return false
        end
    end
    return true
end

-- Callback to handle harvesting a collectable
lib.callback.register("JobsSystem_unijob:harvestCollectable", function(playerId, pointId, spawnIndex)
    local collectable = spawnedCollectables[pointId]
    local player = Framework.getPlayerFromId(playerId)
    local spawnPoint = collectable and collectable.spawned[spawnIndex]

    if not collectable or not spawnPoint or not player then
        return false
    end

    -- Security checks: job check, distance check, inventory check
    local playerJob, playerGrade = player:getJob()
    if collectable.job.name ~= playerJob then
        -- Optional: check if job is public/accessible by others
    end

    local playerPedCoords = GetEntityCoords(GetPlayerPed(playerId)).xy
    local dist = #(spawnPoint.xy - playerPedCoords)
    if dist > 10.0 then
        return false
    end

    if not canCarryItems(player, collectable.data.items) then
        return false
    end

    -- Success: Trigger timeout to simulate harvesting time on server
    SetTimeout(collectable.data.duration, function()
        -- Re-verify state after duration
        if not spawnedCollectables[pointId] or not spawnedCollectables[pointId].spawned[spawnIndex] then
            return
        end

        if not canCarryItems(player, collectable.data.items) then
            return
        end

        -- Remove from spawned list
        spawnedCollectables[pointId].spawned[spawnIndex] = nil

        -- Add items to player
        for _, itemConfig in ipairs(collectable.data.items) do
            local count = itemConfig.count
            if type(count) == "table" then
                count = math.random(count.min, count.max)
            end
            player:addItem(itemConfig.name, count)
        end

        -- Notify all clients to remove the prop
        TriggerClientEvent("JobsSystem_unijob:removeCollectable", -1, pointId, spawnIndex)
    end)

    return true
end)

local AdvancedCollecting = {}

-- Initialize/Update harvesting zones for all jobs
function AdvancedCollecting.update(jobData)
    -- Clean up existing intervals/data for this job's points if they exist
    for id, data in pairs(spawnedCollectables) do
        if data.job.name == jobData.name then
            if data.interval then
                ClearInterval(data.interval)
            end
            spawnedCollectables[id] = nil
        end
    end

    -- Notify clients to clear their points (since we are resetting)
    -- Typically this happens on resource restart, but here we handle live updates
    local idsToClear = {}
    for id, _ in pairs(spawnedCollectables) do
       if string.find(id, jobData.name) then
           table.insert(idsToClear, id)
       end
    end

    if #idsToClear > 0 then
        TriggerClientEvent("JobsSystem_unijob:clearAdvancedCollecting", -1, idsToClear)
    end

    if not jobData.advancedCollecting then return end

    for index, config in ipairs(jobData.advancedCollecting) do
        for locIndex, location in ipairs(config.locations) do
            local pointId = string.format("%s_%s_%s", jobData.name, index, locIndex)
            
            spawnedCollectables[pointId] = {
                spawned = {},
                data = config,
                index = index,
                locationIndex = locIndex,
                job = jobData
            }

            -- Set up periodic spawning
            spawnedCollectables[pointId].interval = SetInterval(function()
                local currentPoints = spawnedCollectables[pointId].spawned
                
                -- Check max spawned limit
                if config.maxSpawned and Utils.getTableSize(currentPoints) >= config.maxSpawned then
                    return
                end

                if not location.coords then return end

                -- Try to find a random valid spawn point within radius
                local found = false
                local randomCoords = nil
                local attempts = 0
                
                while not found and attempts < 20 do
                    attempts = attempts + 1
                    local radius = config.radius or 5.0
                    local offsetX = (math.random() * (radius * 2)) - radius
                    local offsetY = (math.random() * (radius * 2)) - radius
                    
                    randomCoords = vector3(location.coords.x + offsetX, location.coords.y + offsetY, location.coords.z)
                    
                    found = true
                    -- Prevent spawning too close to existing objects
                    for _, existingCoords in pairs(currentPoints) do
                        if #(randomCoords.xy - existingCoords.xy) < 1.0 then
                            found = false
                            break
                        end
                    end
                end

                if not found then return end

                -- Notify all clients about the new spawn
                local spawnIndex = #currentPoints + 1
                TriggerClientEvent("JobsSystem_unijob:spawnCollectable", -1, jobData.name, index, locIndex, randomCoords, spawnIndex)
                currentPoints[spawnIndex] = randomCoords
            end, location.interval)
        end
    end
end

-- Full initialization
function AdvancedCollecting.init(jobs)
    for _, jobData in pairs(jobs) do
        AdvancedCollecting.update(jobData)
    end
end

_G.AdvancedCollecting = AdvancedCollecting

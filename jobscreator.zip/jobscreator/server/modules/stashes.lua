
local cachedJobs = nil
local isOxInventoryStarted = GetResourceState("qb-inventory") == "started"
local registeredStashes = {}

-- Register hook for qb-inventory logging if applicable
if isOxInventoryStarted and Webhooks.settings.stashes then
    exports.qb-inventory:registerHook("swapItems", function(payload)
        -- Check if logging is still enabled
        if not Webhooks.settings.stashes then return end
        
        -- Ignore swaps within the same inventory
        if payload.fromInventory == payload.toInventory then return end

        -- Identify if one of the inventories is a registered job stash
        local stashId = nil
        if payload.fromType == "stash" and payload.fromInventory then
            stashId = payload.fromInventory
        else
            stashId = payload.toInventory
        end

        if type(stashId) ~= "string" then return end

        -- Strip potential player-specific suffix from stash ID (e.g., "stash:123")
        local baseStashId = stashId
        local colonIndex = string.find(stashId, ":")
        if colonIndex then
            baseStashId = string.sub(stashId, 1, colonIndex - 1)
        end

        local stashMetadata = registeredStashes[baseStashId]
        if stashMetadata then
            local jobName = stashMetadata.name
            local config = stashMetadata.stash
            
            local tookLabel = "nothing"
            local gaveLabel = "nothing"

            -- Determine what was moved from/to the stash
            if payload.fromType == "stash" then
                tookLabel = string.format("%sx %s", payload.fromSlot.count, Utils.getItemLabel(payload.fromSlot.name))
                if type(payload.toSlot) == "table" then
                    gaveLabel = string.format("%sx %s", payload.toSlot.count, Utils.getItemLabel(payload.toSlot.name))
                end
            else
                gaveLabel = string.format("%sx %s", payload.fromSlot.count, Utils.getItemLabel(payload.fromSlot.name))
                if type(payload.toSlot) == "table" then
                    tookLabel = string.format("%sx %s", payload.toSlot.count, Utils.getItemLabel(payload.toSlot.name))
                end
            end

            local logMsg = string.format("Stash: %s (%s)\nTook: %s\nGave: %s", config.label, baseStashId, tookLabel, gaveLabel)
            Logs.send(payload.source, jobName, logMsg)
        end
    end)
end

-- Helper to set up all stashes for a specific job
local function setupJobStashes(jobData)
    if not jobData.stashes then return end

    for index, config in ipairs(jobData.stashes) do
        for locIndex, coords in ipairs(config.locations) do
            local stashId = config.name or string.format("%s_stash_%s_%s", jobData.name, index, locIndex)
            
            Editable.registerStash(jobData, stashId, config, coords)
            
            registeredStashes[stashId] = {
                name = jobData.name,
                stash = config
            }
        end
    end
end

local Stashes = {}

-- Initial setup for all jobs
function Stashes.init(jobs)
    cachedJobs = jobs
    for _, jobData in pairs(jobs) do
        setupJobStashes(jobData)
    end
end

-- Update specific job stashes
function Stashes.update(jobData)
    setupJobStashes(jobData)
end

_G.Stashes = Stashes

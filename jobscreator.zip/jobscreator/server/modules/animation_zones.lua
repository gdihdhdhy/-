
local activeZones = {}

-- Callback to handle a player starting an animation in a zone
lib.callback.register("JobsSystem_unijob:startAnimation", function(playerId, zoneId)
    local player = Framework.getPlayerFromId(playerId)
    if not player then return false end

    local zoneData = activeZones[zoneId]
    if not zoneData then return false end

    -- Check if someone else is already using this animation point
    if zoneData.occupant then return false end

    -- Check job requirements (unless it's a global zone)
    local playerJob = player:getJob()
    if not zoneData.zone.global and playerJob ~= zoneData.job.name then
        return false
    end

    -- Set occupant
    zoneData.occupant = playerId
    return true
end)

-- Event to handle a player stopping an animation
RegisterNetEvent("JobsSystem_unijob:stopAnimation", function(zoneId)
    local playerId = source
    local zoneData = activeZones[zoneId]
    
    if zoneData and zoneData.occupant == playerId then
        zoneData.occupant = nil
    end
end)

local AnimationZones = {}

-- Initialize/Update animation zones for a specific job
function AnimationZones.update(jobData)
    if not jobData.animationZones then return end

    for zoneIndex, config in ipairs(jobData.animationZones) do
        for locIndex in ipairs(config.locations) do
            local zoneId = string.format("%s_%s_%s", jobData.name, zoneIndex, locIndex)
            
            activeZones[zoneId] = {
                job = jobData,
                zone = config,
                occupant = nil
            }
        end
    end
end

-- Full initialization for all jobs
function AnimationZones.init(jobs)
    for _, jobData in pairs(jobs) do
        AnimationZones.update(jobData)
    end
end

_G.AnimationZones = AnimationZones

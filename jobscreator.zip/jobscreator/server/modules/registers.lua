
local cachedJobs = nil
local registerStates = {}

-- Helper to get just the amounts for all registers for client syncing
local function getRegisterAmounts()
    local amounts = {}
    for id, data in pairs(registerStates) do
        amounts[id] = data.amount
    end
    return amounts
end

-- Callback to let clients fetch the current state of all registers
lib.callback.register("JobsSystem_unijob:getRegisters", function()
    return getRegisterAmounts()
end)

-- Event: Set an amount on a register
RegisterNetEvent("JobsSystem_unijob:setRegister", function(registerId, amount)
    local playerId = source
    local player = Framework.getPlayerFromId(playerId)
    local state = registerStates[registerId]

    if not player or not state then return end

    -- Check job and if register is already busy
    if state.job.name ~= player:getJob() or state.amount or amount <= 0 then
        return
    end

    state.author = playerId
    state.amount = amount
    
    TriggerClientEvent("JobsSystem_unijob:syncRegister", -1, registerId, amount)
end)

-- Event: Clear a register
RegisterNetEvent("JobsSystem_unijob:clearRegister", function(registerId)
    local playerId = source
    local player = Framework.getPlayerFromId(playerId)
    local state = registerStates[registerId]

    if not player or not state then return end

    -- Check job and if there's anything to clear
    if state.job.name ~= player:getJob() or not state.amount then
        return
    end

    state.author = nil
    state.amount = nil
    
    TriggerClientEvent("JobsSystem_unijob:syncRegister", -1, registerId, nil)
end)

-- Callback: Pay a register
lib.callback.register("JobsSystem_unijob:payRegister", function(playerId, registerId, account)
    local player = Framework.getPlayerFromId(playerId)
    if not player then return end

    local state = registerStates[registerId]
    if not state or not state.amount then return end

    -- Verify account is valid
    if not Config.accountsByKey[account] then return end

    local price = state.amount
    if player:getAccountMoney(account) < price then
        return false, locale("not_enough_" .. account)
    end

    -- Process payment
    player:removeAccountMoney(account, price)

    -- Handle money distribution
    local authorPlayer = Framework.getPlayerFromId(state.author)
    if authorPlayer then
        local employeePercentage = state.register.employeePercentage
        if employeePercentage then
            local employeeCut = math.floor(price * employeePercentage / 100)
            local societyCut = price - employeeCut

            authorPlayer.addAccountMoney("money", employeeCut)
            Editable.addSocietyMoney(state.job.name, societyCut)
        else
            Editable.addSocietyMoney(state.job.name, price)
        end
        
        -- Notify the employee
        LR.notify(state.author, locale("customer_paid"), "success")
    else
        -- Author offline, whole amount to society
        Editable.addSocietyMoney(state.job.name, price)
    end

    -- Discord Logs
    if Webhooks.settings.registers then
        Logs.send(playerId, state.job.name, string.format("Paid %s$ at a register in %s.", price, state.job.label))
    end

    -- Reset register
    state.author = nil
    state.amount = nil
    TriggerClientEvent("JobsSystem_unijob:syncRegister", -1, registerId, nil)

    return true
end)

local Registers = {}

-- Helper to set up registers for a job
local function setupJobRegisters(jobData)
    if not jobData.registers then return end

    for index, config in ipairs(jobData.registers) do
        for locIndex in ipairs(config.locations) do
            local registerId = string.format("%s_%s_%s", jobData.name, index, locIndex)
            
            registerStates[registerId] = {
                job = jobData,
                register = config
            }
        end
    end
end

-- Full initialization
function Registers.init(jobs)
    cachedJobs = jobs
    for _, jobData in pairs(jobs) do
        setupJobRegisters(jobData)
    end
end

-- Refresh specific job registers
function Registers.update(jobData)
    setupJobRegisters(jobData)
    
    -- Sync everyone with the new potential state
    TriggerClientEvent("JobsSystem_unijob:syncRegisters", -1, getRegisterAmounts())
end

_G.Registers = Registers

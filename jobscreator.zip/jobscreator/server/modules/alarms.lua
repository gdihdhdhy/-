
local cachedJobs = nil
local alarmCooldowns = {}

-- Callback to handle triggering an alarm
lib.callback.register("JobsSystem_unijob:triggerAlarm", function(playerId, data)
    local player = Framework.getPlayerFromId(playerId)
    local jobData = cachedJobs and cachedJobs[data.job]
    local alarmConfig = jobData and jobData.alarms[data.index]

    if not player or not alarmConfig then return false end

    -- Check cooldown for this specific alarm
    if alarmCooldowns[data.job] and alarmCooldowns[data.job][data.index] then
        return false
    end

    -- Verify player job or if it's a global alarm
    local playerJob = player:getJob()
    if playerJob ~= data.job and not alarmConfig.global then
        return false
    end

    -- Set cooldown
    if not alarmCooldowns[data.job] then alarmCooldowns[data.job] = {} end
    alarmCooldowns[data.job][data.index] = true
    
    SetTimeout(alarmConfig.cooldown, function()
        if alarmCooldowns[data.job] then
            alarmCooldowns[data.job][data.index] = nil
        end
    end)

    -- Trigger Dispatch
    local coords = alarmConfig.locations[data.locationIndex].xyz
    Dispatch.call(coords, {
        Code = Config.alarmCode,
        Title = locale("dispatch_alarm"),
        Message = locale("dispatch_alarm_desc", jobData.label)
    })

    -- Discord Logs
    if Webhooks.settings.alarms then
        Logs.send(playerId, jobData.name, string.format("Triggered the alarm inside %s.", jobData.label))
    end

    return true
end)

local Alarms = {}

-- Initialize alarms for all jobs
function Alarms.init(jobs)
    cachedJobs = jobs
    for _, jobData in pairs(jobs) do
        alarmCooldowns[jobData.name] = {}
    end
end

-- Refresh / update specific job alarms
function Alarms.update(jobData)
    alarmCooldowns[jobData.name] = {}
end

_G.Alarms = Alarms


local playersInside = {}

-- Event: Player enters a teleport instance
RegisterNetEvent("JobsSystem_unijob:teleport", function(index)
    local playerId = source
    local player = Framework.getPlayerFromId(playerId)
    if not player then return end

    local jobName = player:getJob()
    local jobs = GetJobs()
    local jobData = jobs[jobName]
    local config = jobData and jobData.teleports[index]

    if not config then return end

    -- Distance check or already inside check
    if not playersInside[playerId] then
        if not Utils.distanceCheck(playerId, config.from.coords, 10.0) then
            return
        end
    end

    playersInside[playerId] = true

    -- Handle routing bucket (instancing)
    if config.routingBucket then
        SetPlayerRoutingBucket(playerId, config.routingBucket)
    end
end)

-- Event: Player exits a teleport instance
RegisterNetEvent("JobsSystem_unijob:exitTeleport", function()
    local playerId = source
    
    if playersInside[playerId] then
        playersInside[playerId] = nil
        -- Reset routing bucket to default (0)
        SetPlayerRoutingBucket(playerId, 0)
    end
end)

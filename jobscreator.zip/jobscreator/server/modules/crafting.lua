
local cachedJobs = nil
local activeCrafting = {}

-- Helper to handle the crafting duration and final execution
local function startCraftingTimeout(callback, duration)
    local aborted = false
    
    SetTimeout(duration, function()
        if not aborted then
            callback()
        end
    end)

    return {
        clear = function() aborted = true end
    }
end

-- Function to stop/cancel a player's crafting process
local function stopCrafting(playerId)
    local crafting = activeCrafting[playerId]
    if crafting then
        if crafting.timeout then
            crafting.timeout.clear()
        end
        activeCrafting[playerId] = nil
    end
end

-- Event to handle manual cancellation from client
RegisterNetEvent("JobsSystem_unijob:stopCrafting", function()
    stopCrafting(source)
end)

-- Callback to handle a player starting a craft
lib.callback.register("JobsSystem_unijob:craft", function(playerId, index, locIndex, entryIndex)
    local player = Framework.getPlayerFromId(playerId)
    if not player then return end

    local jobName = player:getJob()
    local jobData = cachedJobs and cachedJobs[jobName]
    if not jobData then return end

    local craftingConfig = jobData.crafting[index]
    local location = craftingConfig and craftingConfig.locations[locIndex]
    local entry = craftingConfig and craftingConfig.entries[entryIndex]

    if not craftingConfig or not location or not entry then
        return
    end

    -- Security checks
    local checkRadius = (craftingConfig.radius or Config.defaultRadius) * 5.0
    if not Utils.distanceCheck(playerId, location, checkRadius) then
        return
    end

    if activeCrafting[playerId] then return end

    -- Check blueprint requirement
    if entry.blueprint then
        if not player:hasItem(entry.blueprint) then
            return false, locale("missing_blueprint")
        end
    end

    -- Check required items
    for _, reqItem in ipairs(entry.requiredItems) do
        if player:getItemCount(reqItem.name) < reqItem.count then
            return false, locale("missing_required_items")
        end
    end

    -- Start the timer
    activeCrafting[playerId] = {}
    activeCrafting[playerId].timeout = startCraftingTimeout(function()
        if not activeCrafting[playerId] then return end
        
        -- Final double checks
        local playerObj = Framework.getPlayerFromId(playerId)
        if not playerObj then
            activeCrafting[playerId] = nil
            return
        end

        if not Utils.distanceCheck(playerId, location, checkRadius) then
            activeCrafting[playerId] = nil
            return
        end

        for _, reqItem in ipairs(entry.requiredItems) do
            if playerObj.getItemCount(reqItem.name) < reqItem.count then
                activeCrafting[playerId] = nil
                LR.notify(playerId, locale("missing_required_items"), "error")
                return
            end
        end

        -- Consume items
        for _, reqItem in ipairs(entry.requiredItems) do
            playerObj.removeItem(reqItem.name, reqItem.count)
        end

        -- Add resulting items
        local logItems = {}
        for _, giveItem in ipairs(entry.giveItems) do
            playerObj.addItem(giveItem.name, giveItem.count)
            table.insert(logItems, string.format("%sx %s", giveItem.count, giveItem.name))
        end

        -- Discord Logging
        if Webhooks.settings.crafting then
            Logs.send(playerId, jobName, string.format("Crafted %s.", table.concat(logItems, ", ")))
        end

        activeCrafting[playerId] = nil
    end, entry.duration)

    return true
end)

-- Clean up if player leaves server during craft
AddEventHandler("playerDropped", function()
    stopCrafting(source)
end)

local Crafting = {}

-- Initialize the module
function Crafting.init(jobs)
    cachedJobs = jobs
end

_G.Crafting = Crafting


-- Logging System
-- Sends logs to job-specific and global Discord webhooks

Logs = {}

-- Send log to webhooks
function Logs.send(logMessage, jobName, color)
    -- Get job-specific webhook
    local jobWebhook = Webhooks.jobs[jobName]
    
    -- Send to job-specific webhook if configured
    if jobWebhook and jobWebhook ~= "" then
        Utils.logToDiscord(logMessage, jobWebhook, color)
    end
    
    -- Send to global webhook if configured
    local globalWebhook = Webhooks.globalWebhook
    if globalWebhook and globalWebhook ~= "" then
        Utils.logToDiscord(logMessage, globalWebhook, color)
    end
end
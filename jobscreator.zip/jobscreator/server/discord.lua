
-- Discord API Integration
-- Fetches Discord user avatars using Discord Bot API

local fetchedUsers = {}

-- Extract Discord ID from player identifiers
local function getDiscordId(source)
    local identifier = GetPlayerIdentifierByType(source, "discord")
    
    -- Remove "discord:" prefix if present
    local colonPos = identifier:find(":")
    if colonPos then
        return identifier:sub(colonPos + 1)
    end
    
    return identifier
end

-- Callback: Get Discord avatar URL
lib.callback.register("JobsSystem_unijob:getDiscordIcon", function(source)
    -- Check if bot token is configured
    if not SvConfig.discordBotToken or SvConfig.discordBotToken == "TOKEN_HERE" then
        warn("Discord bot token missing.")
        return
    end
    
    -- Check if already fetched
    if fetchedUsers[source] then
        return
    end
    
    fetchedUsers[source] = true
    
    local discordId = getDiscordId(source)
    local endpoint = "users/" .. discordId
    local promise = promise.new()
    
    if not discordId then
        return
    end
    
    while true do
        -- Make Discord API request
        PerformHttpRequest("https://discord.com/api/" .. endpoint, function(statusCode, responseData, headers)
            promise:resolve({
                data = responseData,
                code = statusCode,
                headers = headers
            })
        end, "GET", "", {
            ["Content-Type"] = "application/json",
            ["Authorization"] = "Bot " .. SvConfig.discordBotToken
        })
        
        local response = Citizen.Await(promise)
        
        if response.code == 200 then
            -- Success - parse and return avatar URL
            local userData = json.decode(response.data)
            local avatarHash = userData.avatar
            
            return string.format(
                "https://cdn.discordapp.com/avatars/%s/%s.png",
                discordId,
                avatarHash
            )
            
        elseif response.code == 429 then
            -- Rate limited - wait and retry
            local retryAfter = tonumber(response.headers["Retry-After"])
            
            if retryAfter then
                warn(string.format("Rate-limited. Waiting %d seconds before retrying...", retryAfter))
                Wait(retryAfter * 1000)
            else
                warn("Rate limited but no Retry-After header provided.")
                Wait(5000)
            end
        else
            -- Other error - log and return
            warn("Couldn't fetch discord user data: HTTP " .. tostring(response.code))
            return
        end
    end
end)
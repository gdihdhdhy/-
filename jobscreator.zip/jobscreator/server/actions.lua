

local jobs = GetJobs()
local cuffedPlayers = {}
local draggedPlayers = {}
local carryingPlayers = {}
local carriedPlayers = {}
local pendingVehicleActions = {}

Actions = {}

-- Helper function to determine action category
local function getActionCategory(actionType)
    local playerActions = {
        "handcuff", "ziptie", "steal", "drag", 
        "carry", "bill", "revive", "tackle", "heal"
    }
    
    for _, action in ipairs(playerActions) do
        if action == actionType then
            return "playerActions"
        end
    end
    
    return "vehicleActions"
end

-- Toggle handcuff/ziptie (with items)
local function toggleCuffWithItems(targetId)
    local sourceId = source
    
    local items = {
        handcuffs = Settings.handcuffsItemName,
        zipties = Settings.ziptiesItemName
    }
    
    -- Distance check
    if not Utils.distanceCheck(sourceId, targetId, Settings.interactDistance) then
        return
    end
    
    -- Get player
    local player = Framework.getPlayerFromId(sourceId)
    if not player then
        return
    end
    
    -- Check if target is already cuffed
    local currentCuffType = cuffedPlayers[targetId]
    
    if not currentCuffType then
        -- Cuff player
        local cuffType = nil
        
        -- Check for handcuffs first
        if player:hasItem(items.handcuffs) then
            if Actions.hasAccess(player, "handcuffs") then
                cuffType = "handcuffs"
            end
        elseif player:hasItem(items.zipties) then
            if Actions.hasAccess(player, "zipties") then
                cuffType = "zipties"
            end
        else
            LR.notify(sourceId, locale("missing_cuff"), "error")
            return
        end
        
        -- Apply cuffs
        cuffedPlayers[targetId] = cuffType
        player:removeItem(items[cuffType], 1)
        
        -- Trigger client events
        TriggerClientEvent("JobsSystem_unijob:cuffReceiver", targetId, sourceId)
        TriggerClientEvent("JobsSystem_unijob:cuffSender", sourceId, targetId)
        
        -- Callback
        Editable.onCuffStateChanged(sourceId, targetId, true, cuffType)
    else
        -- Uncuff player
        if not Actions.hasAccess(player, currentCuffType) then
            LR.notify(sourceId, locale("cant_un" .. currentCuffType), "error")
            return
        end
        
        -- Return handcuffs (zipties are single-use)
        if currentCuffType == "handcuffs" then
            player:addItem("handcuffs", 1)
        end
        
        -- Remove cuffs
        cuffedPlayers[targetId] = nil
        
        -- Trigger client events
        TriggerClientEvent("JobsSystem_unijob:cuffReceiver", targetId, sourceId)
        TriggerClientEvent("JobsSystem_unijob:cuffSender", sourceId, targetId)
        
        -- Callback
        Editable.onCuffStateChanged(sourceId, targetId, false, currentCuffType)
    end
end

-- Toggle handcuff (without items)
local function toggleCuffWithoutItems(targetId)
    local sourceId = source
    
    -- Distance check
    if not Utils.distanceCheck(sourceId, targetId, Settings.interactDistance) then
        return
    end
    
    -- Get player
    local player = Framework.getPlayerFromId(sourceId)
    if not player then
        return
    end
    
    -- Check if target is already cuffed
    if not cuffedPlayers[targetId] then
        -- Cuff player
        if not Actions.hasAccess(player, "handcuffs") then
            LR.notify(sourceId, locale("cant_handcuff"), "error")
            return
        end
        
        cuffedPlayers[targetId] = "handcuffs"
        
        -- Trigger client events
        TriggerClientEvent("JobsSystem_unijob:cuffReceiver", targetId, sourceId)
        TriggerClientEvent("JobsSystem_unijob:cuffSender", sourceId, targetId)
        
        -- Callback
        Editable.onCuffStateChanged(sourceId, targetId, true, "handcuffs")
    else
        -- Uncuff player
        if not Actions.hasAccess(player, "handcuffs") then
            LR.notify(sourceId, locale("cant_unhandcuff"), "error")
            return
        end
        
        cuffedPlayers[targetId] = nil
        
        -- Trigger client events
        TriggerClientEvent("JobsSystem_unijob:cuffReceiver", targetId, sourceId)
        TriggerClientEvent("JobsSystem_unijob:cuffSender", sourceId, targetId)
        
        -- Callback
        Editable.onCuffStateChanged(sourceId, targetId, false, "handcuffs")
    end
end

-- Register cuff toggle event
RegisterNetEvent("JobsSystem_unijob:cuffToggle", function(targetId)
    if Settings.handcuffItems then
        toggleCuffWithItems(targetId)
    else
        toggleCuffWithoutItems(targetId)
    end
end)

-- Get player cuff state callback
lib.callback.register("JobsSystem_unijob:getPlayerCuffState", function(sourceId, targetId)
    return cuffedPlayers[targetId]
end)

-- Admin uncuff command
RegisterCommand("uncuff", function(sourceId, args, rawCommand)
    local player = Framework.getPlayerFromId(sourceId)
    
    if not player or not IsPlayerAdmin(player.source) then
        return
    end
    
    local targetId = tonumber(args[1])
    if targetId then
        cuffedPlayers[targetId] = nil
        TriggerClientEvent("JobsSystem_unijob:syncCuff", targetId)
    end
end, true)

-- Export uncuff function
exports("uncuff", function(targetId)
    cuffedPlayers[targetId] = nil
    TriggerClientEvent("JobsSystem_unijob:syncCuff", targetId)
end)

-- Drag player event
RegisterNetEvent("JobsSystem_unijob:drag", function(targetId)
    local sourceId = source
    local player = Framework.getPlayerFromId(sourceId)
    
    -- Use existing drag target or new target
    local actualTarget = draggedPlayers[sourceId] or targetId
    
    if not player or not actualTarget then
        return
    end
    
    -- Check permissions and distance
    if not Actions.hasAccess(player, "drag") then
        return
    end
    
    if not Utils.distanceCheck(sourceId, actualTarget, Settings.interactDistance) then
        return
    end
    
    -- Check if target is cuffed
    if not cuffedPlayers[actualTarget] then
        return
    end
    
    -- Toggle drag state
    if draggedPlayers[sourceId] then
        draggedPlayers[sourceId] = nil
    else
        draggedPlayers[sourceId] = actualTarget
    end
    
    -- Trigger client event
    TriggerClientEvent("JobsSystem_unijob:drag", actualTarget, draggedPlayers[sourceId] and sourceId or nil)
end)

-- Put player in vehicle
RegisterNetEvent("JobsSystem_unijob:putInVehicle", function(targetId, seat)
    local sourceId = source
    local player = Framework.getPlayerFromId(sourceId)
    
    if not player or not Actions.hasAccess(player, "drag") then
        return
    end
    
    if not Utils.distanceCheck(sourceId, targetId, Settings.interactDistance) then
        return
    end
    
    if not cuffedPlayers[targetId] then
        return
    end
    
    TriggerClientEvent("JobsSystem_unijob:putInVehicle", targetId, seat)
end)

-- Take player out of vehicle
RegisterNetEvent("JobsSystem_unijob:outTheVehicle", function(targetId, seat)
    local sourceId = source
    local player = Framework.getPlayerFromId(sourceId)
    
    if not player or not Actions.hasAccess(player, "drag") then
        return
    end
    
    if not Utils.distanceCheck(sourceId, targetId, 10.0) then
        return
    end
    
    TriggerClientEvent("JobsSystem_unijob:outTheVehicle", targetId, seat)
end)

-- Carry player event
RegisterNetEvent("JobsSystem_unijob:carry", function(targetId)
    local sourceId = source
    local player = Framework.getPlayerFromId(sourceId)
    
    if not player then
        return
    end
    
    if not Actions.hasAccess(player, "carry") then
        return
    end
    
    if not Utils.distanceCheck(sourceId, targetId, Settings.interactDistance) then
        return
    end
    
    -- Check if anyone is already carrying/being carried
    if carryingPlayers[sourceId] or carryingPlayers[targetId] or 
       carriedPlayers[sourceId] or carriedPlayers[targetId] then
        return
    end
    
    -- Set carry state
    carryingPlayers[sourceId] = targetId
    carriedPlayers[targetId] = sourceId
    
    TriggerClientEvent("JobsSystem_unijob:syncCarry", targetId, sourceId)
end)

-- Stop carrying player
RegisterNetEvent("JobsSystem_unijob:stopCarry", function()
    local sourceId = source
    local player = Framework.getPlayerFromId(sourceId)
    
    if not player or not Actions.hasAccess(player, "carry") then
        return
    end
    
    -- Check if player is carrying someone
    if carryingPlayers[sourceId] then
        local carriedId = carryingPlayers[sourceId]
        
        if not Utils.distanceCheck(sourceId, carriedId, Settings.interactDistance) then
            return
        end
        
        -- Stop carrying
        TriggerClientEvent("JobsSystem_unijob:stopCarry", sourceId, false)
        TriggerClientEvent("JobsSystem_unijob:stopCarry", carriedId, true)
        
        carryingPlayers[sourceId] = nil
        carriedPlayers[carriedId] = nil
        
    -- Check if player is being carried
    elseif carriedPlayers[sourceId] then
        local carrierId = carriedPlayers[sourceId]
        
        if not Utils.distanceCheck(sourceId, carrierId, Settings.interactDistance) then
            return
        end
        
        -- Stop being carried
        TriggerClientEvent("JobsSystem_unijob:stopCarry", sourceId, true)
        TriggerClientEvent("JobsSystem_unijob:stopCarry", carrierId, false)
        
        carryingPlayers[carrierId] = nil
        carriedPlayers[sourceId] = nil
    end
end)

-- Check if player has access to action
function Actions.hasAccess(player, actionType)
    local jobs = GetJobs()
    local playerJob = jobs[player:getJob()]
    
    -- Special handling for handcuffs/zipties
    if actionType == "handcuffs" or actionType == "zipties" then
        local jobConfig = playerJob
        if jobConfig and jobConfig.playerActions then
            if jobConfig.playerActions.handcuff then
                return jobConfig.playerActions.handcuff == "both"
            end
        else
            return Settings.playerActions.handcuff == "both"
        end
    end
    
    -- Get action category
    local category = getActionCategory(actionType)
    
    -- Check job-specific config
    local jobActions = playerJob and playerJob[category]
    local hasJobAccess = jobActions and jobActions[actionType] ~= nil and jobActions[actionType]
    
    -- Check global settings
    local globalActions = Settings[category]
    local hasGlobalAccess = globalActions and globalActions[actionType] ~= nil and globalActions[actionType]
    
    return hasGlobalAccess or hasJobAccess
end

-- Vehicle action callbacks
lib.callback.register("JobsSystem_unijob:hijackVehicle", function(sourceId)
    return Editable.onVehicleAction(sourceId, "hijack")
end)

lib.callback.register("JobsSystem_unijob:repairVehicle", function(sourceId)
    return Editable.onVehicleAction(sourceId, "repair")
end)

lib.callback.register("JobsSystem_unijob:cleanVehicle", function(sourceId)
    return Editable.onVehicleAction(sourceId, "clean")
end)

lib.callback.register("JobsSystem_unijob:impoundVehicle", function(sourceId)
    return Editable.onVehicleAction(sourceId, "impound")
end)

-- Perform vehicle action
RegisterNetEvent("JobsSystem_unijob:performVehicleAction", function(vehicleNetId, actionType)
    local sourceId = source
    
    if not pendingVehicleActions[sourceId] then
        return
    end
    
    pendingVehicleActions[sourceId] = nil
    
    local vehicle = NetworkGetEntityFromNetworkId(vehicleNetId)
    if not DoesEntityExist(vehicle) then
        return
    end
    
    local ownerId = NetworkGetEntityOwner(vehicle)
    TriggerClientEvent("JobsSystem_unijob:performVehicleAction", ownerId, vehicleNetId, actionType)
end)

PendingVehicleActions = pendingVehicleActions

-- Remove item from player
RegisterNetEvent("JobsSystem_unijob:removeItem", function(itemName)
    local sourceId = source
    local player = Framework.getPlayerFromId(sourceId)
    
    if not player or type(itemName) ~= "string" then
        return
    end
    
    if player:hasItem(itemName) then
        player:removeItem(itemName, 1)
    end
end)

-- Tackle player
RegisterNetEvent("JobsSystem_unijob:tacklePlayer", function(targetId)
    local sourceId = source
    local player = Framework.getPlayerFromId(sourceId)
    
    if not player then
        return
    end
    
    if not Actions.hasAccess(player, "tackle") then
        return
    end
    
    if not Utils.distanceCheck(sourceId, targetId, 5.0) then
        return
    end
    
    TriggerClientEvent("JobsSystem_unijob:playTackledAnim", targetId, sourceId)
end)
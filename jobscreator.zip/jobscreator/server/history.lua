
-- Action History System
-- Logs user actions to database and keeps 48-hour history

local historyEntries = {}
local historyLoaded = false

-- Get current Unix timestamp
local function getCurrentTimestamp()
    return os.time()
end

-- Initialize history from database
MySQL.ready(function()
    Wait(1000)
    
    local currentTime = getCurrentTimestamp()
    local twoDaysAgo = currentTime - 172800  -- 48 hours in seconds
    
    -- Load recent history (last 48 hours)
    historyEntries = MySQL.query.await(
        "SELECT * FROM JobsSystem_jobscreator_history WHERE timestamp >= ?",
        {twoDaysAgo}
    )
    
    -- Delete old history entries
    MySQL.query.await(
        "DELETE FROM JobsSystem_jobscreator_history WHERE timestamp < ?",
        {twoDaysAgo}
    )
    
    historyLoaded = true
end)

-- Track which clients have fetched history (prevent duplicate fetches)
local clientsFetched = {}

-- Callback: Get history (one-time per client)
lib.callback.register("JobsSystem_unijob:getHistory", function(source)
    -- Prevent duplicate fetches
    if clientsFetched[source] then
        return
    end
    
    clientsFetched[source] = true
    
    -- Wait for history to load
    while not historyLoaded do
        Wait(0)
    end
    
    return historyEntries
end)

-- Add history log entry
function AddHistoryLog(source, action)
    local entry = {
        username = GetPlayerName(source),
        action = action,
        timestamp = getCurrentTimestamp()
    }
    
    -- Add to memory
    table.insert(historyEntries, entry)
    
    -- Save to database
    MySQL.insert.await(
        "INSERT INTO JobsSystem_jobscreator_history (username, action, timestamp) VALUES (?, ?, ?)",
        {entry.username, entry.action, entry.timestamp}
    )
    
    -- Broadcast to all clients
    TriggerClientEvent("JobsSystem_unijob:updateHistory", -1, historyEntries)
end
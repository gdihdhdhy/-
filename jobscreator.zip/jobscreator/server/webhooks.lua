
-- Discord Webhook Management
-- Manages global and per-job Discord webhooks with settings

Webhooks = {}

-- Load global webhook from KVP storage
Webhooks.globalWebhook = GetResourceKvpString("webhook")

-- Load webhook settings from KVP storage
local webhookSettingsJson = GetResourceKvpString("webhookSettings")

if webhookSettingsJson then
    Webhooks.settings = json.decode(webhookSettingsJson) or {
        alarms = false,
        collecting = false,
        crafting = true,
        vehicleBought = true,
        registers = true,
        selling = true,
        shops = true,
        stashes = true
    }
else
    -- Default webhook settings
    Webhooks.settings = {
        alarms = false,
        collecting = false,
        crafting = true,
        vehicleBought = true,
        registers = true,
        selling = true,
        shops = true,
        stashes = true
    }
end

-- Job-specific webhooks
Webhooks.jobs = {}

-- Load job webhooks from database
MySQL.ready(function()
    Wait(1000)
    
    local jobWebhooks = MySQL.query.await("SELECT * FROM JobsSystem_jobscreator_webhooks")
    
    for i = 1, #jobWebhooks do
        local row = jobWebhooks[i]
        Webhooks.jobs[row.name] = row.url
    end
end)

-- Callback: Get webhook data (admin only)
lib.callback.register("JobsSystem_unijob:getWebhookData", function(source)
    local player = Framework.getPlayerFromId(source)
    
    -- Check admin permission
    if not player or not IsPlayerAdmin(player.source) then
        return
    end
    
    return Webhooks
end)

-- Server event: Update webhook data (admin only)
RegisterNetEvent("JobsSystem_unijob:updateWebhookData", function(webhookData)
    local source = source
    local player = Framework.getPlayerFromId(source)
    
    -- Check admin permission
    if not player or not IsPlayerAdmin(player.source) then
        return
    end
    
    -- Update global webhook
    Webhooks.globalWebhook = webhookData.globalWebhook
    Webhooks.settings = webhookData.settings
    
    -- Save global webhook to KVP
    if webhookData.globalWebhook then
        SetResourceKvp("webhook", webhookData.globalWebhook)
    end
    
    -- Save settings to KVP
    if webhookData.settings then
        SetResourceKvp("webhookSettings", json.encode(webhookData.settings))
    end
end)

-- Server event: Update job-specific webhook (admin only)
RegisterNetEvent("JobsSystem_unijob:updateJobWebhook", function(jobName, webhookUrl)
    local source = source
    local player = Framework.getPlayerFromId(source)
    
    -- Check admin permission and valid URL
    if not player or not IsPlayerAdmin(player.source) or webhookUrl:len() == 0 then
        return
    end
    
    -- Update in memory
    Webhooks.jobs[jobName] = webhookUrl
    
    -- Update in database (insert or update)
    MySQL.update.await(
        "INSERT INTO JobsSystem_jobscreator_webhooks (name, url) VALUES(?, ?) ON DUPLICATE KEY UPDATE url = VALUES(url)",
        {jobName, webhookUrl}
    )
end)
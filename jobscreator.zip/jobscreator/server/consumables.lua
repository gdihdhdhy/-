
-- Server-side Consumables Handler
-- Registers usable items from Config.usableItems

-- Register all usable items
for itemName in pairs(Config.usableItems) do
    Framework.registerUsableItem(itemName, function(source)
        local player = Framework.getPlayerFromId(source)
        
        if player then
            -- Remove item from inventory
            player:removeItem(itemName, 1)
            
            -- Trigger client-side consumption
            TriggerClientEvent("JobsSystem_unijob:useConsumable", source, itemName)
        end
    end)
end
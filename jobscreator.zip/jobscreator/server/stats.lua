
-- Job Statistics System
-- Tracks on-duty players, job counts, and wealthiest jobs

local stats = {
    onDutyCount = 0,           -- Currently on-duty players
    lastOnDutyCount = 0,       -- Last hour's on-duty count
    wealthiestJob = nil,       -- Job with highest balance
    jobCounts = {}             -- Player count per job
}

local statsLoaded = false

-- Update wealthiest job
local function updateWealthiestJob()
    local allJobs = GetJobs()
    local wealthiest = {
        job = nil,
        balance = 0
    }
    
    for jobName, jobData in pairs(allJobs) do
        local balance = Editable.getSocietyMoney(jobData.name) or 0
        
        -- Convert to number if needed
        if type(balance) ~= "number" or not balance then
            balance = tonumber(balance) or 0
        end
        
        if balance >= wealthiest.balance then
            wealthiest = {
                job = jobData,
                balance = balance
            }
        end
    end
    
    if wealthiest.job then
        stats.wealthiestJob = {
            label = wealthiest.job.label,
            balance = wealthiest.balance
        }
    end
end

-- Callback: Get stats
lib.callback.register("JobsSystem_unijob:getStats", function()
    -- Wait for stats to load
    while not statsLoaded do
        Wait(100)
    end
    
    return stats
end)

-- Update wealthiest job every hour
lib.cron.new("0 * * * *", function()
    updateWealthiestJob()
end)

-- Initialize job counts
CreateThread(function()
    -- Wait for jobs to load
    while not AreJobsLoaded() do
        Wait(100)
    end
    
    local allJobs = GetJobs()
    
    -- Initialize all job counts to 0
    for jobName, jobData in pairs(allJobs) do
        stats.jobCounts[jobData.name] = 0
    end
    
    updateWealthiestJob()
    statsLoaded = true
end)

-- Broadcast stats to clients every 10 minutes
SetInterval(function()
    TriggerClientEvent("JobsSystem_unijob:updateStats", -1, stats)
end, 600000)

-- Track player jobs and duty status
local playerJobs = {}
local playerDutyStatus = {}

-- Update player job tracking
local function updatePlayerJob(source, newJob, isDuty)
    local allJobs = GetJobs()
    local oldJob = playerJobs[source]
    
    -- Don't update if job hasn't changed
    if oldJob == newJob then
        return
    end
    
    -- Decrement old job count
    if oldJob then
        stats.jobCounts[oldJob] = stats.jobCounts[oldJob] - 1
    end
    
    -- Increment new job count if valid
    if allJobs[newJob] then
        if not stats.jobCounts[newJob] then
            stats.jobCounts[newJob] = 0
        end
        
        stats.jobCounts[newJob] = stats.jobCounts[newJob] + 1
        playerJobs[source] = newJob
    else
        playerJobs[source] = nil
    end
    
    -- Update duty status
    if isDuty then
        if not playerDutyStatus[source] then
            playerDutyStatus[source] = true
            stats.onDutyCount = stats.onDutyCount + 1
        end
    else
        if playerDutyStatus[source] then
            playerDutyStatus[source] = nil
            stats.onDutyCount = stats.onDutyCount - 1
        end
    end
end

-- ESX job change handler
AddEventHandler("esx:setJob", function(source, newJob)
    if newJob.name ~= Config.UnemployedJob then
        local isDuty = Editable.getPlayerDuty(source, newJob)
        updatePlayerJob(source, newJob.name, isDuty)
    end
end)

-- QBCore job change handler
AddEventHandler("QBCore:Server:OnJobUpdate", function(source, newJob)
    if newJob.name ~= Config.UnemployedJob then
        local isDuty = Editable.getPlayerDuty(source, newJob)
        updatePlayerJob(source, newJob.name, isDuty)
    end
end)

-- ESX player loaded handler
AddEventHandler("esx:playerLoaded", function(source, playerData)
    local isDuty = Editable.getPlayerDuty(source, playerData.job)
    updatePlayerJob(source, playerData.job.name, isDuty)
end)

-- QBCore player loaded handler
AddEventHandler("QBCore:Server:PlayerLoaded", function(playerData)
    local isDuty = Editable.getPlayerDuty(playerData.PlayerData.source, playerData.PlayerData.job)
    updatePlayerJob(playerData.PlayerData.source, playerData.PlayerData.job.name, isDuty)
end)

-- Save last on-duty count every hour
lib.cron.new("0 * * * *", function()
    stats.lastOnDutyCount = stats.onDutyCount
end)

-- Initialize stats for all online players
CreateThread(function()
    -- Wait for stats to be ready
    while not statsLoaded do
        Wait(100)
    end
    
    -- Track all currently online players
    for _, playerData in pairs(Framework.getPlayers()) do
        local source = playerData.source or playerData.PlayerData.source
        local job = playerData.job or playerData.PlayerData.job
        local isDuty = Editable.getPlayerDuty(source, job)
        
        if Framework.name == "es_extended" then
            updatePlayerJob(playerData.source, playerData.job.name, isDuty)
        else
            updatePlayerJob(playerData.PlayerData.source, playerData.PlayerData.job.name, isDuty)
        end
    end
    
    -- Broadcast initial stats
    TriggerClientEvent("JobsSystem_unijob:updateStats", -1, stats)
end)

-- Server Settings Management
-- Handles loading, saving, and updating server settings with MySQL persistence

Settings = {}
local settingsLoaded = false

-- Default settings
local defaultSettings = {
    interactDistance = 3.0,
    impoundPrice = 500,
    handcuffItems = true,
    handcuffsItemName = "handcuffs",
    ziptiesItemName = "zipties",
    handcuffsSkillCheck = true,
    sprintWhileDrag = false,
    disableTargetInteractions = false,
    tackleCooldown = 10000,
    tackleRadius = 2.0,
    
    playerActions = {
        steal = false,
        handcuff = false,
        drag = false,
        carry = false,
        bill = false,
        revive = false,
        heal = false
    },
    
    vehicleActions = {
        putInsideVehicle = false,
        takeOutOfVehicle = false,
        hijack = false,
        repair = false,
        clean = false,
        impound = false
    },
    
    durations = {
        steal = 3000,
        revive = 10000,
        heal = 5000,
        hijack = 1000,
        repair = 10000,
        clean = 10000,
        impound = 10000
    }
}

-- Save all settings to database
local function saveSettings()
    local batch = {}
    
    for key, value in pairs(Settings) do
        table.insert(batch, {
            json.encode(value),
            key
        })
    end
    
    MySQL.prepare.await(
        "UPDATE JobsSystem_jobscreator_settings SET `value` = ? WHERE `key` = ?",
        batch
    )
end

-- Initialize settings from database
MySQL.ready(function()
    Wait(1000)
    
    -- Insert default settings (ignore if exist)
    for key, value in pairs(defaultSettings) do
        Settings[key] = value
        
        MySQL.insert.await(
            "INSERT IGNORE INTO JobsSystem_jobscreator_settings (`key`, `value`) VALUES (?, ?)",
            {key, json.encode(value)}
        )
    end
    
    -- Load settings from database
    local dbSettings = MySQL.query.await("SELECT * FROM JobsSystem_jobscreator_settings")
    
    for i = 1, #dbSettings do
        local row = dbSettings[i]
        Settings[row.key] = json.decode(row.value)
    end
    
    settingsLoaded = true
end)

-- Server event: Update settings
RegisterNetEvent("JobsSystem_unijob:updateSettings", function(newSettings)
    local source = source
    local player = Framework.getPlayerFromId(source)
    
    -- Check admin permission
    if not player or not IsPlayerAdmin(player.source) then
        return
    end
    
    Settings = newSettings
    
    -- Broadcast to all clients
    TriggerClientEvent("JobsSystem_unijob:updateSettings", -1, newSettings)
    
    -- Save to database
    saveSettings()
end)

-- Callback: Get settings
lib.callback.register("JobsSystem_unijob:getSettings", function()
    -- Wait for settings to load
    while not settingsLoaded do
        Wait(100)
    end
    
    return Settings
end)
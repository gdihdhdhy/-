
-- Load locale system
lib.locale()

-- Helper function to check if a resource is started
function isStarted(resourceName)
    return GetResourceState(resourceName) == 'started'
end

-- Check for JobsSystem_bridge dependency (minimum version 1.3.3)
local hasJobsSystemBridge, errorMessage = lib.checkDependency("JobsSystem_bridge", "1.3.3")

if not hasJobsSystemBridge then
    Wait(5000)
    error(errorMessage)
end

-- Initialize global objects based on environment
if IsDuplicityVersion() then
    -- Server-side initialization
    local JobsSystemBridge = exports.JobsSystem_bridge:getObject()
    
    LR = JobsSystemBridge
    Utils = LR.Utils
    Dispatch = LR.Dispatch
    
    -- Check for resource updates
    Utils.checkVersion(GetCurrentResourceName())
else
    -- Client-side initialization
    local JobsSystemBridge = exports.JobsSystem_bridge:getObject()
    
    LR = JobsSystemBridge
    Utils = LR.Utils
end
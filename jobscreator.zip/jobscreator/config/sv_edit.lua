
Editable = {}

local tables = {
    [[
        CREATE TABLE IF NOT EXISTS `JobsSystem_jobscreator` (
            `name` varchar(30) NOT NULL,
            `data` longtext NOT NULL,
            PRIMARY KEY (`name`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ]],
    [[
       CREATE TABLE IF NOT EXISTS `JobsSystem_jobscreator_history` (
            `username` varchar(50) DEFAULT NULL,
            `action` varchar(150) DEFAULT NULL,
            `timestamp` int(11) DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci; 
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `JobsSystem_jobscreator_settings` (
            `key` varchar(30) NOT NULL,
            `value` text NOT NULL,
            PRIMARY KEY (`key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `JobsSystem_jobscreator_webhooks` (
            `name` varchar(50) NOT NULL,
            `url` varchar(100) NOT NULL,
            PRIMARY KEY (`name`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ]]
}

MySQL.ready(function()
    for i = 1, #tables do
        MySQL.query.await(tables[i])
    end
end)

---@type table<string, number>
local activeVehicles = {}

---@param source integer
---@param vehicleType string
---@param shared boolean
---@return table?
function Editable.getVehicles(source, vehicleType, shared)
    local player = Framework.getPlayerFromId(source)

    if not player then return end

    local query = shared and
        'SELECT * FROM JobsSystem_jobscreator_vehicles WHERE job = ? and type = ?'
        or
        'SELECT * FROM JobsSystem_jobscreator_vehicles WHERE job = ? and type = ? and owner = ?'
        
    local vehicles = MySQL.query.await(query, {
        player:getJob(), vehicleType, not shared and player:getIdentifier() or nil
    })

    for _, vehicle in ipairs(vehicles) do
        local entity = activeVehicles[vehicle.plate]

        if vehicle.stored == true or vehicle.stored == 1 then
            vehicle.state = 'in_garage'
        elseif entity then
            if DoesEntityExist(entity) then
                if GetVehiclePetrolTankHealth(entity) <= 0 or GetVehicleBodyHealth(entity) <= 0 then
                    DeleteEntity(entity)
                    activeVehicles[vehicle.plate] = nil
                    vehicle.state = 'in_impound'
                else
                    vehicle.state = 'outside'
                end
            else
                activeVehicles[vehicle.plate] = nil
                vehicle.state = 'in_impound'
            end
        else
            vehicle.state = 'in_impound'
        end
    end

    return vehicles
end

---@param source integer
---@param netId integer
---@param props VehicleProperties
---@param type string
---@return boolean
function Editable.saveVehicle(source, netId, props, type)
    local player = Framework.getPlayerFromId(source)

    if not player then return false end

    local entity = NetworkGetEntityFromNetworkId(netId)

    if not DoesEntityExist(entity) then return false end

    local query = 'SELECT * FROM JobsSystem_jobscreator_vehicles WHERE plate = ?'
    local query2 = 'UPDATE JobsSystem_jobscreator_vehicles SET stored = ?, props = ? WHERE plate = ?'

    local vehicle = MySQL.single.await(query, { props.plate })
    
    if vehicle and vehicle.type == type and (vehicle.owner == player:getIdentifier() or vehicle.job == player:getJob()) then
        local oldProps = json.decode(vehicle.props)

        if props.model ~= oldProps.model then
            return false
        end

        MySQL.update.await(query2, { true, json.encode(props), props.plate })

        SetTimeout(300, function()
            if DoesEntityExist(entity) then
                DeleteEntity(entity)
            end
        end)

        return true
    end

    return false
end

---@type string[], string[]
local numbers, chars = {}, {}

for i = 48, 57 do table.insert(numbers, string.char(i)) end
for i = 65, 90 do table.insert(chars, string.char(i)) end

local function generatePlate(length)
    while true do
        local plate = ''

        for _ = 1, length do
            plate = plate .. (math.random(2) == 1 and Utils.randomFromTable(chars) or Utils.randomFromTable(numbers))
        end

        if not MySQL.single.await('SELECT * FROM JobsSystem_jobscreator_vehicles WHERE plate = ?') then
            return plate
        end

        Wait(0)
    end
end

---@param source integer
---@param index integer
---@param vehicleIndex integer
---@return boolean
function Editable.buyVehicle(source, index, vehicleIndex, props, account)
    local player = Framework.getPlayerFromId(source)

    if not player
    or not Config.accountsByKey[account] then
        return false
    end

    local job = GetJobs()[player:getJob()]

    if not job then return false end

    local garage = job.garages[index]
    local vehicle = garage?.vehicles[vehicleIndex]

    if not vehicle
    or not vehicle.price then
        return false
    end

    local query = 'INSERT INTO JobsSystem_jobscreator_vehicles (owner, plate, props, type, job, stored) VALUES(?, ?, ?, ?, ?, ?)'

    if player:getAccountMoney(account) >= vehicle.price then
        player:removeAccountMoney(account, vehicle.price)

        props.plate = generatePlate(6) -- 6 to prevent collisions with esx_vehicleshop and qb-vehicleshop
        props.model = joaat(vehicle.model)

        MySQL.insert.await(query, {
            player:getIdentifier(), props.plate, json.encode(props), garage.vehicleType, player:getJob(), true
        })
        
        if Webhooks.settings.vehicleBought then
            Logs.send(source, job.name, ('Bought work vehicle.\nModel/label: %s\nPrice: %s$'):format(vehicle.label or vehicle.model, vehicle.price))
        end

        return true
    end

    return false
end

lib.callback.register('JobsSystem_unijob:canSpawnVehicle', function(source, plate)
    local player = Framework.getPlayerFromId(source)

    if not player then return end
    
    local query = 'SELECT * FROM JobsSystem_jobscreator_vehicles WHERE plate = ? and (owner = ? or job = ?)'

    return MySQL.single.await(query, { plate, player:getIdentifier(), player:getJob() })?.stored
end)

RegisterNetEvent('JobsSystem_unijob:vehicleSpawned', function(plate, netId)
    local source = source
    local player = Framework.getPlayerFromId(source)
    local vehicle = NetworkGetEntityFromNetworkId(netId)

    if not player
    or not DoesEntityExist(vehicle) then return end

    local query = 'SELECT * FROM JobsSystem_jobscreator_vehicles WHERE plate = ? and (owner = ? or job = ?)'
    local query2 = 'UPDATE JobsSystem_jobscreator_vehicles SET stored = ? WHERE plate = ?'

    if MySQL.single.await(query, { plate, player:getIdentifier(), player:getJob() })?.stored then
        MySQL.update.await(query2, { false, plate })
        activeVehicles[plate] = vehicle
    end
end)

lib.callback.register('JobsSystem_unijob:canRetrieveVehicle', function(source, plate)
    local player = Framework.getPlayerFromId(source)

    if not player 
    or player:getAccountMoney('money') < Settings.impoundPrice then
        return false, locale('not_enough_money')
    end

    local query = 'SELECT * FROM JobsSystem_jobscreator_vehicles WHERE plate = ? and (owner = ? or job = ?)'
    local vehicle = MySQL.single.await(query, { plate, player:getIdentifier(), player:getJob() })

    return not activeVehicles[plate] and (vehicle?.stored == false or vehicle?.stored == 0)
end)

RegisterNetEvent('JobsSystem_unijob:vehicleRetrieved', function(plate, netId)
    local source = source
    local player = Framework.getPlayerFromId(source)
    local vehicle = NetworkGetEntityFromNetworkId(netId)

    if not player
    or not DoesEntityExist(vehicle)
    or activeVehicles[plate] then return end

    local query = 'SELECT * FROM JobsSystem_jobscreator_vehicles WHERE plate = ? and (owner = ? or job = ?)'

    if MySQL.single.await(query, { plate, player:getIdentifier(), player:getJob() }) then
        activeVehicles[plate] = vehicle
        player:removeAccountMoney('money', Settings.impoundPrice)
    end
end)

---Can be used externally to easily get job owned vehicles
---@param plate string
---@return { plate: string, owner: string, props: VehicleProperties, stored: boolean, job: string, type: string }?
exports('getVehicleFromDatabase', function(plate)
    -- Trim in case of padded plate being passed in
    plate = plate:strtrim(' ')

    local vehicle = MySQL.single.await('SELECT * FROM JobsSystem_jobscreator_vehicles WHERE plate = ?', { plate })

    if vehicle then
        vehicle.props = json.decode(vehicle.props)
    end

    return vehicle
end)

local qb-inventory = GetResourceState('qb-inventory') == 'started'

---Should only be used for inventories that require registering stashes
---@param job Job
---@param name string
---@param data StashData
---@param coords LocationData
function Editable.registerStash(job, name, data, coords)
    if qb-inventory then
        exports.qb-inventory:RegisterStash(name, data.label, data.slots, data.maxWeight, not data.shared or false,
            not data.global and { [job.name] = data.grade or 0 } or nil)
    end
end

---@param job Job
---@param name string
---@param data ShopData
function Editable.registerShop(job, name, data)
    if qb-inventory then
        local locations = {}
        local items = {}

        for _, coords in ipairs(data.locations) do
            table.insert(locations, coords.xyz)
        end
        
        -- Převeď items do správného formátu pro qb-inventory
        for _, item in ipairs(data.items) do
            local shopItem = {
                name = item.name,
                price = item.price,
                currency = item.currency or 'money'
            }
            
            -- Přidej count pouze pokud je explicitně definovaný
            if item.count then
                shopItem.count = item.count
            end
            
            -- Přidej metadata pokud existuje
            if item.metadata then
                shopItem.metadata = item.metadata
            end
            
            table.insert(items, shopItem)
        end

        exports.qb-inventory:RegisterShop(name, {
            name = data.label,
            inventory = items,
            locations = locations,
            groups = {
                [job.name] = data.grade or 0
            }
        })
    end
end

---@param society string
---@param amount integer
function Editable.addSocietyMoney(society, amount)
    if GetResourceState('JobsSystem_multijob') == 'started' then
        exports['JobsSystem_multijob']:addAccountBalance(society, amount)
        return
    end

    if Framework.name == 'es_extended' then
        -- Automaticky vytvoř society účet, pokud neexistuje
        local accountName = 'society_' .. society
        
        -- Zkontroluj, jestli účet existuje
        local accountExists = MySQL.scalar.await(
            'SELECT COUNT(*) FROM addon_account WHERE name = ?',
            {accountName}
        )
        
        -- Pokud účet neexistuje, vytvoř ho
        if accountExists == 0 then
            print(('[INFO] Creating society account for job: %s'):format(society))
            
            MySQL.insert.await(
                'INSERT INTO addon_account (name, label, shared) VALUES (?, ?, ?)',
                {accountName, 'Society ' .. society, 1}
            )
            
            -- Pro novější ESX verze s addon_account_data
            local hasAccountData = MySQL.scalar.await(
                "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'addon_account_data'"
            )
            
            if hasAccountData > 0 then
                MySQL.insert.await(
                    'INSERT INTO addon_account_data (account_name, money, owner) VALUES (?, ?, ?)',
                    {accountName, 0, nil}
                )
            end
        end
        
        local p = promise.new()

        TriggerEvent('esx_addonaccount:getSharedAccount', accountName, function(account)
            if not account then
                p:resolve(false)
                return
            end

            account.addMoney(amount)
            p:resolve(true)
        end)

        local success = Citizen.Await(p)

        if not success then
            print(('[WARNING] Unable to find society account for job: %s. Make sure the society account exists in your database.'):format(society))
            return false
        end
        
        return true
    else
        local success = pcall(function()
            exports['qb-management']:AddMoney(society, amount)
        end)
    
        if success then return end
    
        local success = pcall(function()
            exports['qb-banking']:AddMoney(society, amount)
        end)

        if success then
            return
        end

        local success = pcall(function()
            exports['Renewed-Banking']:addAccountMoney(society, amount)
        end)
    
        if not success then
            error('Unable to change account balance in qb-management/qb-banking/Renewed-Banking. Add your banking system in sv_edit.lua')
        end
    end
end

---@param society string
---@return integer
function Editable.getSocietyMoney(society)
    if GetResourceState('JobsSystem_multijob') == 'started' then
        return exports['JobsSystem_multijob']:getAccountBalance(society)
    end

    if Framework.name == 'es_extended' then
        local p = promise.new()

        TriggerEvent('esx_addonaccount:getSharedAccount', 'society_' .. society, function(account)
            if not account then
                p:resolve(0)
                return
            end

            p:resolve(account?.money or 0)
        end)

        local amount = Citizen.Await(p)

        if not amount then
            error(('Unable to find society account for job: %s'):format(society))
        end

        return amount
    else
        local success, amount = pcall(function()
            return exports['qb-management']:GetAccountBalance(society)
        end)
    
        if success then 
            return amount 
        end
    
        local success, amount = pcall(function()
            return exports['qb-banking']:GetAccountBalance(society)
        end)
    
        if success then
            return amount
        end

        local _, amount  = pcall(function()
            return exports['Renewed-Banking']:getAccountMoney(society)
        end)

        if not amount then
            warn('Unable to fetch society balance, implement your banking in sv_edit.lua')
            return 0
        end

        return amount
    end
end

local function isStarted(resourceName)
    return GetResourceState(resourceName) == 'started'
end

---@type string
local path

if isStarted('qb-inventory') then
    path = 'nui://qb-inventory/web/images/%s.png'
elseif isStarted('qb-inventory') then
    path = 'nui://qb-inventory/html/images/%s.png'
elseif isStarted('ps-inventory') then
    path = 'nui://ps-inventory/html/images/%s.png'
elseif isStarted('lj-inventory') then
    path = 'nui://lj-inventory/html/images/%s.png'
elseif isStarted('qs-inventory') then
    path = 'nui://qs-inventory/html/images/%s.png' -- Not really sure
end

---Returns the NUI path of an icon.
---@param itemName string
---@return string?
---@diagnostic disable-next-line: duplicate-set-field
function Editable.getInventoryIcon(itemName)
    if not path then
        warn('Inventory images path not set in sv_edit.lua!')
        return
    end

    return path:format(itemName) .. '?height=128'
end

---@param source integer
---@param targetId integer
---@param state boolean
---@param handcuffType 'handcuffs' | 'zipties'
function Editable.onCuffStateChanged(source, targetId, state, handcuffType)
    if Settings.handcuffsSkillCheck and state then
        lib.callback('JobsSystem_unijob:skillCheck', targetId, function(success)
            if success then
                Wait(700)
                exports['JobsSystem_unijob']:uncuff(targetId)
                LR.notify(source, locale('player_refused'), 'error')
            end
        end)
    end

    -- Implement your own logic here
end

if Framework.name == 'qb-core' then
    local query = 'INSERT INTO phone_invoices (citizenid, amount, society, sender, sendercitizenid) VALUES (?, ?, ?, ?, ?)'

    RegisterNetEvent('JobsSystem_unijob:giveInvoice', function(targetId, amount)
        local source = source
        local player = Framework.getPlayerFromId(source)
        local target = Framework.getPlayerFromId(source)

        if not player
        or not target then
            return
        end

        if not Utils.distanceCheck(source, targetId, 10.0) then
            LR.notify(source, locale('target_too_far'), 'error')
            return
        end

        if not Actions.hasAccess(player, 'bill') then return end

        MySQL.insert.await(query, { target:getIdentifier(), amount, player:getJob(), player:getFirstName(), player:getIdentifier() })
    end)
end

RegisterNetEvent('JobsSystem_unijob:revivePlayer', function(targetId)
    local source = source
    local player = Framework.getPlayerFromId(source)

    if not player
    or not Actions.hasAccess(player, 'revive')
    or not Utils.distanceCheck(source, targetId, 10.0) then return end

    if Framework.name == 'es_extended' then
        TriggerClientEvent('esx_ambulancejob:revive', targetId)
    else
        TriggerClientEvent('hospital:client:Revive', targetId)
    end
end)

RegisterNetEvent('JobsSystem_unijob:healPlayer', function(targetId)
    local source = source
    local player = Framework.getPlayerFromId(source)

    if not player
    or not Actions.hasAccess(player, 'heal')
    or not Utils.distanceCheck(source, targetId, 10.0) then return end

    TriggerClientEvent('JobsSystem_unijob:healed', targetId)
end)

---@param source integer
---@param action string
---@return boolean
function Editable.onVehicleAction(source, action)
    local player = Framework.getPlayerFromId(source)
    
    if not player
    or not Actions.hasAccess(player, action) then
        return false
    end

    if type(action) == 'table' then
        if player:getItemCount(action.item) > 0 then
            if action.removeAfterUse then
                player:removeItem(action.item, 1)
            end
            
            PendingVehicleActions[source] = true
            return true
        end

        return false
    end

    PendingVehicleActions[source] = true
    return true
end

---@param source integer
---@param job table xPlayer or QBPlayer job data depending on your framework
function Editable.getPlayerDuty(source, job)
    if Framework.name == 'es_extended' then
        return true
    else
        return job.onduty
    end
end

MySQL.query([[
CREATE TABLE IF NOT EXISTS `JobsSystem_jobscreator_vehicles` (
	`plate` VARCHAR(8) NOT NULL COLLATE 'utf8mb4_general_ci',
	`owner` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
	`props` TEXT NOT NULL COLLATE 'utf8mb4_general_ci',
	`stored` TINYINT(1) NOT NULL,
	`job` VARCHAR(30) NOT NULL COLLATE 'utf8mb4_general_ci',
	`type` VARCHAR(30) NOT NULL COLLATE 'utf8mb4_general_ci',
	PRIMARY KEY (`plate`) USING BTREE
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB;
]])
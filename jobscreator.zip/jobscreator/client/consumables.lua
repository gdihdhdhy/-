
-- Consumable Items Handler
-- Handles usable items with progress bars and animations

RegisterNetEvent("JobsSystem_unijob:useConsumable", function(itemName)
    -- Get item configuration
    local itemConfig = Config.usableItems[itemName]
    if not itemConfig then
        return
    end
    
    -- Show progress bar with animation
    local success = LR.progressBar(
        itemConfig.progress,        -- Progress bar text
        itemConfig.duration,         -- Duration in ms
        false,                       -- Disable controls
        itemConfig.animation,        -- Animation data
        Utils.convertAnimProp(itemConfig.prop) -- Convert prop data
    )
    
    -- Update player status if successful
    if success then
        Editable.updateStatus(itemConfig)
    end
end)

-- Main Job Management System

-- Job storage
local jobs = {}

-- Get all jobs
function GetJobs()
    return jobs
end

-- Get current player's job
function GetCurrentJob()
    local playerJob = Framework.getJob()
    return jobs[playerJob]
end

-- Check if player has required grade
function HasGrade(requiredGrade)
    if not requiredGrade then return true end
    return Framework.getJobGrade() >= requiredGrade
end

-- Module list for initialization
local modules = {
    Alarms,
    BossActions,
    Blips,
    Cloakrooms,
    Collecting,
    Crafting,
    Garages,
    Selling,
    Shops,
    Stashes,
    Registers,
    AnimationZones,
    MusicPlayers,
    Teleports
}

-- Update job system
local function updateJobSystem(forceUpdate)
    local playerJob = Framework.getJob()
    local currentJobData = jobs[playerJob]
    
    -- Force update all modules
    if forceUpdate then
        for _, module in ipairs(modules) do
            if module.update then
                module.update()
            end
        end
        
        -- Remove all entities
        Utils.removeEntities()
        
        -- Recreate props and peds for all jobs
        for jobName, jobData in pairs(jobs) do
            for categoryName, categoryData in pairs(jobData) do
                if type(categoryData) == "table" and table.type(categoryData) == "array" then
                    for _, item in ipairs(categoryData) do
                        if item.locations then
                            for _, location in ipairs(item.locations) do
                                -- Create props if configured
                                if item.prop then
                                    local coords = (type(location) == "table" and location.coords) or location
                                    Utils.createProps(coords, item)
                                end
                                
                                -- Create peds if configured
                                if item.ped then
                                    local coords = (type(location) == "table" and location.coords) or location
                                    Utils.createPeds(coords, item)
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    
    -- Update radial menu
    Actions.updateRadial()
    
    -- Initialize modules for current job
    if currentJobData then
        for _, module in ipairs(modules) do
            if module.clear then
                module.clear()
                module.create(currentJobData)
            end
        end
    else
        -- Clear all modules if no job
        for _, module in ipairs(modules) do
            if module.clear then
                module.clear()
            end
        end
    end
end

-- Job sync status
local jobsSynced = false

-- Sync all jobs from server
RegisterNetEvent("JobsSystem_unijob:syncJobs", function(jobsData)
    jobsSynced = true
    jobs = jobsData
    UI.updateJobs(jobs)
    updateJobSystem(true)
end)

-- Sync single job update
RegisterNetEvent("JobsSystem_unijob:syncJob", function(jobData)
    if not jobData then return end
    
    jobs[jobData.name] = jobData
    UI.updateJob(jobData)
    updateJobSystem(true)
end)

-- Sync job removal
RegisterNetEvent("JobsSystem_unijob:syncRemoveJob", function(jobName)
    jobs[jobName] = nil
    UI.removeJob(jobName)
    updateJobSystem(true)
end)

-- Sync job field update
RegisterNetEvent("JobsSystem_unijob:syncJobField", function(jobName, field, value)
    if not value then return end
    
    jobs[jobName][field] = value
    UI.updateJob(jobs[jobName])
    updateJobSystem(true)
end)

-- Job change detection
local lastJob = nil
local lastGrade = nil
local jobCheckInterval = nil

-- Player loaded handler
Framework.onPlayerLoaded(function()
    -- Request jobs if not already synced
    if not jobsSynced then
        TriggerServerEvent("JobsSystem_unijob:requestJobs")
    end
    
    -- Monitor job changes
    jobCheckInterval = SetInterval(function()
        local currentJob = Framework.getJob()
        local currentGrade = Framework.getJobGrade()
        
        if currentJob ~= lastJob or currentGrade ~= lastGrade then
            updateJobSystem(false)
        end
        
        lastJob = currentJob
        lastGrade = currentGrade
    end, 500)
    
    -- Update UI when ready
    CreateThread(function()
        while not UI do
            Wait(100)
        end
        UI.updateJobs(jobs)
    end)
end)

-- Player logout handler
Framework.onPlayerLogout(function()
    if jobCheckInterval then
        ClearInterval(jobCheckInterval)
        jobCheckInterval = nil
    end
end)

-- Resource start handler
AddEventHandler("onClientResourceStart", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        TriggerServerEvent("JobsSystem_unijob:requestJobs")
    end
end)
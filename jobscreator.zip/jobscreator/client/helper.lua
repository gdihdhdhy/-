
-- Helper Functions for Coordinate Selection and Entity Placement

-- Simple coordinate selection (press E to select)
local function selectCoordinateSimple()
    LR.showUI("[E] - Select point")
    
    while true do
        -- Disable E key and mouse wheel
        DisableControlAction(0, 38, true)   -- E key
        DisableControlAction(0, 105, true)  -- Mouse wheel
        
        -- Check if E was pressed
        if IsDisabledControlJustReleased(0, 38) then
            local coords = GetEntityCoords(cache.ped)
            local heading = GetEntityHeading(cache.ped)
            
            LR.hideUI()
            return vector4(coords.x, coords.y, coords.z, heading)
        end
        
        Wait(0)
    end
end

-- Advanced coordinate selection with entity preview
local function selectCoordinateWithPreview(pedConfigs, propConfigs)
    local selectedCoords = nil
    local rotation = 0.0
    local hasPeds = #pedConfigs > 0
    local previewProps = {}
    local previewPeds = {}
    local playerCoords = GetEntityCoords(cache.ped)
    local showVerticalEntities = false
    local minZOffset = 0.0
    
    -- Create preview props (hidden initially)
    for i = 1, #propConfigs do
        local modelDimensions = GetModelDimensions(propConfigs[1].model)
        local height = modelDimensions.z - modelDimensions.y
        
        if height >= 1.0 then
            showVerticalEntities = true
        end
        
        if minZOffset > modelDimensions.y then
            minZOffset = modelDimensions.y
        end
        
        local hiddenCoords = vector3(playerCoords.x, playerCoords.y, playerCoords.z - 10.0)
        previewProps[i] = Utils.createProp(hiddenCoords, propConfigs[i])
    end
    
    -- Create preview peds (hidden initially)
    for i = 1, #pedConfigs do
        local hiddenCoords = vector3(playerCoords.x, playerCoords.y, playerCoords.z - 10.0)
        previewPeds[i] = Utils.createPed(hiddenCoords, pedConfigs[i])
        showVerticalEntities = true
    end
    
    -- Raycast update loop
    local raycastInterval = SetInterval(function()
        local hit, _, coords = lib.raycast.cam(17, 1, 10.0)
        if hit then
            selectedCoords = coords
        end
    end, 0)
    
    LR.showUI("[LMOUSE] - Select point")
    
    while true do
        -- Disable controls
        DisableControlAction(0, 24, true)   -- Left mouse button
        DisableControlAction(0, 105, true)  -- Mouse wheel
        DisableControlAction(0, 73, true)   -- X key
        
        -- Check if left mouse was clicked
        if IsDisabledControlJustReleased(0, 24) and selectedCoords then
            ClearInterval(raycastInterval)
            LR.hideUI()
            
            -- Clean up preview entities
            for i = 1, #previewProps do
                previewProps[i].remove()
            end
            for i = 1, #previewPeds do
                previewPeds[i].remove()
            end
            
            -- Calculate final Z coordinate
            local zOffset = (hasPeds and showVerticalEntities) and 1.0 or -minZOffset
            return vector4(selectedCoords.x, selectedCoords.y, selectedCoords.z + zOffset, rotation)
        end
        
        -- Rotate with scroll wheel
        if IsDisabledControlJustReleased(0, 14) then -- Scroll up
            rotation = rotation + 5.0
        end
        if IsDisabledControlJustReleased(0, 15) then -- Scroll down
            rotation = rotation - 5.0
        end
        
        -- Update preview entities
        if selectedCoords then
            if not hasPeds then
                -- Draw sphere at selection point
                DrawSphere(selectedCoords.x, selectedCoords.y, selectedCoords.z, 0.1, 255, 0, 255, 0.5)
                
                -- Draw vertical line
                local lineEnd = Utils.offsetCoords(
                    vector4(selectedCoords.x, selectedCoords.y, selectedCoords.z, rotation),
                    0.0, 0.15, 0.0
                )
                DrawLine(selectedCoords.x, selectedCoords.y, selectedCoords.z,
                         lineEnd.x, lineEnd.y, lineEnd.z,
                         255, 100, 255, 0.5)
            else
                -- Update preview props
                for i = 1, #previewProps do
                    local propEntity = previewProps[i].get()
                    local propConfig = propConfigs[i]
                    local offset = propConfig.offset
                    
                    if propEntity then
                        local baseCoords = vector3(
                            selectedCoords.x,
                            selectedCoords.y,
                            selectedCoords.z + (showVerticalEntities and 1.0 or -minZOffset)
                        )
                        
                        -- Apply offset if configured
                        if offset then
                            local entityHeading = GetEntityHeading(propEntity)
                            local rotZ = (propConfig.rotation and propConfig.rotation.z) or 0.0
                            baseCoords = Utils.offsetCoords(
                                vector4(baseCoords.x, baseCoords.y, baseCoords.z, entityHeading + rotZ),
                                offset.x or 0,
                                offset.y or 0,
                                offset.z or 0
                            )
                        end
                        
                        SetEntityCoords(propEntity, baseCoords.x, baseCoords.y, baseCoords.z)
                        SetEntityAlpha(propEntity, 200, false)
                        SetEntityCollision(propEntity, false, false)
                        
                        -- Apply rotation
                        local rotX = (propConfig.rotation and propConfig.rotation.x) or 0.0
                        local rotY = (propConfig.rotation and propConfig.rotation.y) or 0.0
                        local rotZ = (propConfig.rotation and propConfig.rotation.z) or 0.0
                        SetEntityRotation(propEntity, rotX, rotY, rotation + rotZ)
                    end
                end
                
                -- Update preview peds
                for i = 1, #previewPeds do
                    local pedEntity = previewPeds[i].get()
                    local pedConfig = pedConfigs[i]
                    local offset = pedConfig.offset
                    
                    if pedEntity then
                        local coords = selectedCoords
                        
                        -- Apply offset if configured
                        if offset then
                            local entityHeading = GetEntityHeading(pedEntity)
                            coords = Utils.offsetCoords(
                                vector4(coords.x, coords.y, coords.z, entityHeading),
                                -(offset.x or 0),
                                -(offset.y or 0),
                                offset.z or 0
                            )
                        end
                        
                        SetEntityCoords(pedEntity, coords.x, coords.y, coords.z)
                        SetEntityAlpha(pedEntity, 200, false)
                        SetEntityCollision(pedEntity, false, false)
                        
                        local heading = (pedConfig.heading or 0.0) + rotation
                        SetEntityHeading(pedEntity, heading)
                    end
                end
            end
        end
        
        Wait(0)
    end
end

-- Round number to 4 decimal places
local function roundTo4Decimals(number)
    return tonumber(string.format("%.4f", number))
end

-- Get configuration for prompts
local bridgeConfig = exports.JobsSystem_bridge:getConfig()
local promptsEnabled = bridgeConfig.Prompts.Enabled

-- NUI Callback for coordinate input
RegisterNUICallback("getCoordsInput", function(data, cb)
    SetNuiFocus(false, false)
    
    local useTarget = data.target
    local forceDisableTarget = data.forceDisableTarget
    local is4D = data.is4D
    local pedConfigs = data.ped or {}
    local propConfigs = data.prop or {}
    
    -- Determine if we should use advanced selection
    local useAdvancedSelection = false
    if not (useTarget == false) and (#pedConfigs > 0 or #propConfigs > 0) and promptsEnabled and not forceDisableTarget then
        useAdvancedSelection = true
    end
    
    -- Get coordinates
    local coords
    if useAdvancedSelection then
        coords = selectCoordinateWithPreview(pedConfigs, propConfigs)
    else
        coords = selectCoordinateSimple()
    end
    
    -- Copy to clipboard
    lib.setClipboard(tostring(coords))
    
    -- Return rounded coordinates
    cb({
        x = roundTo4Decimals(coords.x),
        y = roundTo4Decimals(coords.y),
        z = roundTo4Decimals(coords.z),
        w = roundTo4Decimals(coords.w)
    })
    
    SetNuiFocus(true, true)
end)
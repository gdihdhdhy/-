
-- UI Management and NUI Callbacks

UI = {}

-- Send message to NUI
function UI.sendMessage(action, data)
    SendNUIMessage({
        action = action,
        data = data
    })
end

-- Update single job in UI
function UI.updateJob(jobData)
    UI.sendMessage("updateJob", jobData)
end

-- Remove job from UI
function UI.removeJob(jobName)
    UI.sendMessage("removeJob", jobName)
end

-- Update all jobs in UI
function UI.updateJobs(jobsData)
    local jobsArray = {}
    for _, job in pairs(jobsData) do
        jobsArray[#jobsArray + 1] = job
    end
    UI.sendMessage("updateJobs", jobsArray)
end

-- NUI Callback: Get all jobs
RegisterNUICallback("getJobs", function(data, cb)
    local allJobs = GetJobs()
    local jobsArray = {}
    
    for _, job in pairs(allJobs) do
        jobsArray[#jobsArray + 1] = job
    end
    
    cb(jobsArray)
end)

-- NUI Callback: Create new job
RegisterNUICallback("createJob", function(data, cb)
    TriggerServerEvent("JobsSystem_unijob:createJob", data)
    cb({})
end)

-- NUI Callback: Update job field
RegisterNUICallback("updateJobField", function(data, cb)
    local jobName = data.name
    local field = data.field
    local value = data.data
    
    TriggerServerEvent("JobsSystem_unijob:updateJobField", jobName, field, value)
    cb({})
end)

-- NUI Callback: Update entire job
RegisterNUICallback("updateJob", function(data, cb)
    TriggerServerEvent("JobsSystem_unijob:updateJob", data)
    cb({})
end)

-- NUI Callback: Remove job
RegisterNUICallback("removeJob", function(data, cb)
    TriggerServerEvent("JobsSystem_unijob:removeJob", data)
    cb({})
end)

-- NUI Callback: Hide UI frame
RegisterNUICallback("hideFrame", function(data, cb)
    SetNuiFocus(false, false)
    cb({})
end)

-- NUI Callback: Update webhook data
RegisterNUICallback("updateWebhookData", function(data, cb)
    TriggerServerEvent("JobsSystem_unijob:updateWebhookData", data)
    cb({})
end)

-- NUI Callback: Update job webhook
RegisterNUICallback("updateJobWebhook", function(data, cb)
    TriggerServerEvent("JobsSystem_unijob:updateJobWebhook", data.name, data.url)
    cb({})
end)

-- History Management
local historyData = nil

-- Load history from server
lib.callback("JobsSystem_unijob:getHistory", false, function(history)
    historyData = history
end)

-- Update history from server
RegisterNetEvent("JobsSystem_unijob:updateHistory", function(history)
    historyData = history
    UI.sendMessage("updateHistory", history)
end)

-- NUI Callback: Get history
RegisterNUICallback("getHistory", function(data, cb)
    while not historyData do
        Wait(0)
    end
    cb(historyData)
end)

-- Stats Management
local statsData = nil

-- Load stats from server
lib.callback("JobsSystem_unijob:getStats", false, function(stats)
    statsData = stats
end)

-- NUI Callback: Get stats
RegisterNUICallback("getStats", function(data, cb)
    while not statsData do
        Wait(0)
    end
    cb(statsData)
end)

-- Update stats from server
RegisterNetEvent("JobsSystem_unijob:updateStats", function(stats)
    statsData = stats
    UI.sendMessage("updateStats", stats)
end)

-- NUI Callback: Get framework name
RegisterNUICallback("getFramework", function(data, cb)
    cb(Framework.name)
end)

-- NUI Callback: Get UI language
RegisterNUICallback("getLanguage", function(data, cb)
    cb(Config.uiLanguage)
end)

-- NUI Callback: Get player profile
RegisterNUICallback("getProfile", function(data, cb)
    cb({
        serverId = cache.serverId,
        username = GetPlayerName(cache.playerId),
        avatarUrl = nil
    })
end)

-- Command: Open job creator UI
local profileIconLoaded = false

RegisterCommand(Config.command or "jobscreator", function()
    -- Check permissions
    local hasPermission = lib.callback.await("JobsSystem_unijob:getWebhookData", false)
    if not hasPermission then
        return
    end
    
    -- Load Discord icon once
    if not profileIconLoaded then
        lib.callback("JobsSystem_unijob:getDiscordIcon", false, function(iconUrl)
            UI.sendMessage("updateProfile", {
                serverId = cache.serverId,
                username = GetPlayerName(cache.playerId),
                avatarUrl = iconUrl
            })
        end)
        profileIconLoaded = true
    end
    
    -- Update webhook data and open UI
    UI.sendMessage("updateWebhookData", hasPermission)
    UI.sendMessage("open")
    SetNuiFocus(true, true)
end)

-- Command: Edit specific job
RegisterCommand("edit", function(source, args, rawCommand)
    -- Check permissions
    local webhookData = lib.callback.await("JobsSystem_unijob:getWebhookData", false)
    if not webhookData then
        return
    end
    
    local jobName = args[1]
    local allJobs = GetJobs()
    local jobData = allJobs[jobName]
    
    if not jobData then
        LR.notify(locale("invalid_job_name"), "error")
        return
    end
    
    -- Open edit UI
    UI.sendMessage("updateWebhookData", webhookData)
    UI.sendMessage("openEditJob", jobName)
    UI.sendMessage("open")
    SetNuiFocus(true, true)
end)

-- NUI Callback: Teleport to coordinates
RegisterNUICallback("teleport", function(data, cb)
    local coords = data
    
    -- Request collision
    RequestCollisionAtCoord(coords.x, coords.y, coords.z)
    Wait(500)
    
    -- Teleport player
    SetEntityCoords(cache.ped, coords.x, coords.y, coords.z + 1.0)
    
    -- Set heading if provided
    if coords.w then
        SetEntityHeading(cache.ped, coords.w)
    end
    
    cb({})
end)
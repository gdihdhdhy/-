
-- Actions System
-- Core framework for player and vehicle interactions

Actions = {}

local playerActions = {}
local vehicleActions = {}

-- Check if player can interact (not in vehicle and alive)
local function canInteract()
    local isDead = Editable.isDead(cache.ped)
    local inVehicle = IsPedInAnyVehicle(cache.ped)
    return not inVehicle and not isDead
end

-- Get action category by name
local function getActionCategory(actionName)
    if actionName == "handcuff" or actionName == "ziptie" or actionName == "steal" or
       actionName == "drag" or actionName == "carry" or actionName == "bill" or
       actionName == "revive" or actionName == "tackle" or actionName == "heal" then
        return "playerActions"
    else
        return "vehicleActions"
    end
end

-- Check if player has access to an action
function HasAccess(actionName)
    local currentJob = GetCurrentJob()
    
    -- Special handling for handcuffs/zipties
    if actionName == "handcuffs" or actionName == "zipties" then
        local jobActions = currentJob and currentJob.playerActions
        if jobActions and jobActions.handcuff then
            return jobActions.handcuff == "both"
        else
            return Settings.playerActions.handcuff == "both"
        end
    end
    
    -- Check job-specific settings
    local category = getActionCategory(actionName)
    local jobActions = currentJob and currentJob[category]
    local jobHasAction = jobActions and jobActions[actionName]
    
    -- Check global settings
    local globalActions = Settings[category]
    local globalHasAction = globalActions and globalActions[actionName]
    
    return globalHasAction or jobHasAction
end

-- Validate action requirements (items, etc.)
local function validateActionRequirements(actionName)
    local currentJob = GetCurrentJob()
    local category = getActionCategory(actionName)
    
    -- Get action config from job or global settings
    local actionConfig = currentJob and currentJob[category] and currentJob[category][actionName]
    if actionConfig == nil then
        actionConfig = Settings[category] and Settings[category][actionName]
    end
    
    -- Check item requirement
    if type(actionConfig) == "table" and actionConfig.item then
        if not Framework.hasItem(actionConfig.item) then
            local itemLabel = actionConfig.item
            if Utils.getItemLabel then
                itemLabel = Utils.getItemLabel(actionConfig.item)
            end
            LR.notify(locale("missing_item", itemLabel))
            return false
        end
        
        -- Remove item after use if configured
        if actionConfig.removeAfterUse then
            TriggerServerEvent("JobsSystem_unijob:removeItem", actionConfig.item)
        end
    end
    
    return true
end

-- Helper function to register player target interactions across different target systems
local function registerPlayerTarget(actionName, icon, handleAction, canShow)
    local distance = Settings.interactDistance or 3.0
    local label = locale(actionName)
    local fullIcon = "fa-solid fa-" .. icon
    
    local function canInteractCheck(targetPed)
        if not canInteract() then
            return false
        end
        if canShow and not canShow(targetPed) then
            return false
        end
        if Editable.canInteractFilter[actionName] then
            if not Editable.canInteractFilter[actionName](targetPed) then
                return false
            end
        end
        return HasAccess(actionName)
    end

    if isStarted('qb-target') then
        exports.qb-target:addGlobalPlayer({
            {
                name = "JobsSystem_jobscreator_player_" .. actionName,
                label = label,
                icon = fullIcon,
                distance = distance,
                canInteract = function(entity, distance, coords, name)
                    return canInteractCheck(entity)
                end,
                onSelect = function(data)
                    handleAction(data.entity)
                end
            }
        })
    elseif isStarted('qb-target') then
        exports['qb-target']:AddGlobalPlayer({
            options = {
                {
                    num = actionName,
                    type = 'client',
                    action = function(entity)
                        handleAction(entity)
                    end,
                    icon = fullIcon,
                    label = label,
                    canInteract = function(entity)
                        return canInteractCheck(entity)
                    end
                }
            },
            distance = distance
        })
    else
        -- Fallback to qtarget
        local success, err = pcall(function()
            exports.qtarget:Player({
                options = {{
                    label = label,
                    icon = fullIcon,
                    canInteract = function(entity)
                        return canInteractCheck(entity)
                    end,
                    action = handleAction
                }},
                distance = distance
            })
        end)
        
        if not success then
            pcall(function()
                exports.qb-target:addGlobalPlayer({
                    {
                        name = "JobsSystem_jobscreator_player_" .. actionName,
                        label = label,
                        icon = fullIcon,
                        distance = distance,
                        canInteract = function(entity) return canInteractCheck(entity) end,
                        onSelect = function(data) handleAction(data.entity) end
                    }
                })
            end)
        end
    end
end

-- Helper function to register vehicle target interactions across different target systems
local function registerVehicleTarget(actionName, icon, handleAction, canShow)
    local distance = Settings.interactDistance or 3.0
    local label = locale(actionName)
    local fullIcon = "fa-solid fa-" .. icon
    
    local function canInteractCheck(vehicle)
        if not canInteract() then
            return false
        end
        
        local currentJob = GetCurrentJob()
        if not currentJob or not currentJob.vehicleActions then
            return not not (Settings.vehicleActions and Settings.vehicleActions[actionName])
        end
        
        if canShow and not canShow(vehicle) then
            return false
        end
        
        if Editable.canInteractFilter[actionName] then
            if not Editable.canInteractFilter[actionName](vehicle) then
                return false
            end
        end
        
        return not not currentJob.vehicleActions[actionName]
    end

    if isStarted('qb-target') then
        exports.qb-target:addGlobalVehicle({
            {
                name = "JobsSystem_jobscreator_vehicle_" .. actionName,
                label = label,
                icon = fullIcon,
                distance = distance,
                canInteract = function(entity, distance, coords, name)
                    return canInteractCheck(entity)
                end,
                onSelect = function(data)
                    handleAction(data.entity)
                end
            }
        })
    elseif isStarted('qb-target') then
        exports['qb-target']:AddGlobalVehicle({
            options = {
                {
                    num = actionName,
                    type = 'client',
                    action = function(entity)
                        handleAction(entity)
                    end,
                    icon = fullIcon,
                    label = label,
                    canInteract = function(entity)
                        return canInteractCheck(entity)
                    end
                }
            },
            distance = distance
        })
    else
        -- Fallback to qtarget
        local success, err = pcall(function()
            exports.qtarget:Vehicle({
                options = {{
                    label = label,
                    icon = fullIcon,
                    canInteract = function(entity)
                        return canInteractCheck(entity)
                    end,
                    action = handleAction
                }},
                distance = distance
            })
        end)
        
        if not success then
            pcall(function()
                exports.qb-target:addGlobalVehicle({
                    {
                        name = "JobsSystem_jobscreator_vehicle_" .. actionName,
                        label = label,
                        icon = fullIcon,
                        distance = distance,
                        canInteract = function(entity) return canInteractCheck(entity) end,
                        onSelect = function(data) handleAction(data.entity) end
                    }
                })
            end)
        end
    end
end

-- Create player action
function Actions.createPlayer(actionName, icon, callback, canShow)
    local function handleAction(targetPed)
        -- Check if player can interact
        if not canInteract() then
            LR.notify(locale("in_car"), "error")
            return
        end
        
        -- Get target player index
        local playerIndex = NetworkGetPlayerIndexFromPed(targetPed)
        if playerIndex == 0 then
            return
        end
        
        -- Validate requirements
        if not validateActionRequirements(actionName) then
            return
        end
        
        local targetServerId = GetPlayerServerId(playerIndex)
        
        -- Check for override
        if PlayerActionOverrides and PlayerActionOverrides[actionName] then
            PlayerActionOverrides[actionName](targetServerId, targetPed)
            return
        end
        
        -- Execute callback
        callback(targetServerId, targetPed)
    end
    
    -- Register with target (if not disabled)
    if not Config.disableTargetInteractions then
        registerPlayerTarget(actionName, icon, handleAction, canShow)
    end
    
    -- Store action
    table.insert(playerActions, {
        name = actionName,
        icon = icon,
        onSelect = handleAction
    })
    
    -- Export action
    exports(actionName, handleAction)
end

-- Create vehicle action
function Actions.createVehicle(actionName, icon, callback, canShow)
    local function handleAction(vehicle)
        -- Check if player can interact
        if not canInteract() then
            LR.notify(locale("in_car"), "error")
            return
        end
        
        -- Validate requirements
        if not validateActionRequirements(actionName) then
            return
        end
        
        -- Check for override
        if VehicleActionOverrides and VehicleActionOverrides[actionName] then
            VehicleActionOverrides[actionName](vehicle)
            return
        end
        
        -- Execute callback
        callback(vehicle)
    end
    
    -- Register with target (if not disabled)
    if not Config.disableTargetInteractions then
        registerVehicleTarget(actionName, icon, handleAction, canShow)
    end
    
    -- Store action
    table.insert(vehicleActions, {
        name = actionName,
        icon = icon,
        onSelect = handleAction
    })
    
    -- Export action
    exports(actionName, handleAction)
end

-- Get closest target for action menu
local closestTarget = nil

SetInterval(function()
    if canInteract() and cache.ped and DoesEntityExist(cache.ped) then
        local myCoords = GetEntityCoords(cache.ped)
        closestTarget = lib.getClosestPed(myCoords, 3.0)
    else
        closestTarget = nil
    end
end, 200)

-- Show player actions menu
local function showPlayerActionsMenu()
    local options = {}
    
    for _, action in ipairs(playerActions) do
        if HasAccess(action.name) then
            table.insert(options, {
                label = locale(action.name),
                icon = action.icon,
                onSelect = action.onSelect
            })
        end
    end
    
    lib.registerMenu({
        id = "player_actions",
        title = locale("player_actions"),
        position = Config.actionsMenuPosition or "top-right",
        options = options
    }, function(selected)
        closestTarget = nil
        options[selected].onSelect()
    end)
    
    lib.showMenu("player_actions")
end

-- Show vehicle actions menu
local function showVehicleActionsMenu()
    local options = {}
    
    for _, action in ipairs(vehicleActions) do
        if HasAccess(action.name) then
            table.insert(options, {
                label = locale(action.name),
                icon = action.icon,
                onSelect = action.onSelect
            })
        end
    end
    
    lib.registerMenu({
        id = "vehicle_actions",
        title = locale("vehicle_actions"),
        position = Config.actionsMenuPosition or "top-right",
        options = options
    }, function(selected)
        closestTarget = nil
        options[selected].onSelect()
    end)
    
    lib.showMenu("vehicle_actions")
end

-- Action categories for main menu
local actionCategories = {
    {
        name = "player_actions",
        label = locale("player_actions"),
        icon = "user",
        onSelect = showPlayerActionsMenu,
        canInteract = function()
            for _, action in ipairs(playerActions) do
                if HasAccess(action.name) then
                    return true
                end
            end
            return false
        end
    },
    {
        name = "vehicle_actions",
        label = locale("vehicle_actions"),
        icon = "car",
        onSelect = showVehicleActionsMenu,
        canInteract = function()
            for _, action in ipairs(vehicleActions) do
                if HasAccess(action.name) then
                    return true
                end
            end
            return false
        end
    }
}

-- Export functions for external scripts
exports("addActionsCategory", function(category)
    table.insert(actionCategories, category)
end)

exports("removeActionsCategory", function(categoryName)
    for i, category in ipairs(actionCategories) do
        if category.name == categoryName then
            table.remove(actionCategories, i)
            break
        end
    end
end)

-- Main actions menu
Binds.actionsMenu.addListener("main", function()
    local currentJob = GetCurrentJob()
    local options = {}
    
    -- Build menu options
    for _, category in ipairs(actionCategories) do
        if not category.canInteract or category.canInteract() then
            table.insert(options, category)
        end
    end
    
    -- Only show menu if enabled, player can interact, and has actions
    if not Config.actionsMenu or not canInteract() or #options == 0 then
        return
    end
    
    lib.registerMenu({
        id = "actions_menu",
        position = Config.actionsMenuPosition or "top-right",
        title = (currentJob and currentJob.label) or locale("actions"),
        options = options
    }, function(selected)
        options[selected].onSelect()
    end)
    
    lib.showMenu("actions_menu")
end)

-- Update radial menu
function Actions.updateRadial()
    lib.removeRadialItem("player_actions")
    lib.removeRadialItem("vehicle_actions")
    
    if not Config.radialMenu then
        return
    end
    
    -- Build player actions
    local playerRadialItems = {}
    for _, action in ipairs(playerActions) do
        if HasAccess(action.name) then
            table.insert(playerRadialItems, {
                id = action.name,
                label = locale(action.name .. "_radial"),
                icon = action.icon,
                onSelect = function()
                    closestTarget = nil
                    action.onSelect()
                end
            })
        end
    end
    
    -- Build vehicle actions
    local vehicleRadialItems = {}
    for _, action in ipairs(vehicleActions) do
        if HasAccess(action.name) then
            table.insert(vehicleRadialItems, {
                id = action.name,
                label = locale(action.name .. "_radial"),
                icon = action.icon,
                onSelect = function()
                    closestTarget = nil
                    action.onSelect()
                end
            })
        end
    end
    
    -- Register player actions radial
    if #playerRadialItems > 0 then
        lib.addRadialItem({
            id = "player_actions",
            label = locale("player_actions_radial"),
            icon = "user",
            menu = "player_actions"
        })
        
        lib.registerRadial({
            id = "player_actions",
            items = playerRadialItems
        })
    end
    
    -- Register vehicle actions radial
    if #vehicleRadialItems > 0 then
        lib.addRadialItem({
            id = "vehicle_actions",
            label = locale("vehicle_actions_radial"),
            icon = "car",
            menu = "vehicle_actions"
        })
        
        lib.registerRadial({
            id = "vehicle_actions",
            items = vehicleRadialItems
        })
    end
end

local teleportPoints = {}

-- Function to handle the actual player teleportation with optional animation and screen effects
local function performTeleport(coords, disableAnim)
    if not disableAnim then
        lib.requestAnimDict("anim@heists@keycard@")
        TaskPlayAnim(cache.ped, "anim@heists@keycard@", "exit", 5.0, 1.0, -1, 16, 0, false, false, false)
    end

    DoScreenFadeOut(750)
    RequestCollisionAtCoord(coords.x, coords.y, coords.z)
    Wait(1000)

    SetArtificialLightsState(false)
    SetEntityCoords(cache.ped, coords.x, coords.y, coords.z)
    SetEntityHeading(cache.ped, coords.w)
    SetGameplayCamRelativeHeading(0.0)
    PlaceObjectOnGroundProperly(cache.ped)
    
    Wait(1750)
    DoScreenFadeIn(500)
end

-- Function to handle entering a teleport (going inside)
local function enterTeleport(args)
    local jobData = args.job
    local config = jobData.teleports[args.index]
    local exitPoint = nil

    performTeleport(config.to.coords, config.disableAnim)
    TriggerServerEvent("JobsSystem_unijob:teleport", args.index)

    -- Create temporary exit point
    exitPoint = Utils.createInteractionPoint({
        coords = config.to.target,
        radius = config.radius or Config.defaultRadius,
        options = {
            {
                label = config.to.label or locale("go_outside"),
                icon = config.to.icon or "door-open",
                onSelect = function()
                    performTeleport(config.from.coords, config.disableAnim)
                    TriggerServerEvent("JobsSystem_unijob:exitTeleport")
                    if exitPoint then
                        exitPoint.remove()
                    end
                end
            }
        }
    })
end

local Teleports = {}

-- Create teleport interaction points for a specific job
function Teleports.create(jobData)
    if not jobData.teleports then return end

    for index, config in ipairs(jobData.teleports) do
        local point = Utils.createInteractionPoint({
            coords = config.from.target,
            radius = config.radius or Config.defaultRadius,
            options = {
                {
                    label = config.from.label or locale("go_inside"),
                    icon = config.from.icon or "door-open",
                    onSelect = enterTeleport,
                    args = {
                        job = jobData,
                        index = index
                    },
                    canInteract = function()
                        return HasGrade(config.grade)
                    end
                }
            }
        }, config.target)
        
        table.insert(teleportPoints, point)
    end
end

-- Clear all teleport interaction points
function Teleports.clear()
    for _, point in ipairs(teleportPoints) do
        point.remove()
    end
    table.wipe(teleportPoints)
end

_G.Teleports = Teleports


local registerPoints = {}
local registerStates = {}

-- Initial fetch of register states
lib.callback("JobsSystem_unijob:getRegisters", false, function(states)
    registerStates = states
end)

-- Sync all registers
RegisterNetEvent("JobsSystem_unijob:syncRegisters", function(states)
    registerStates = states
end)

-- Sync a specific register state
RegisterNetEvent("JobsSystem_unijob:syncRegister", function(id, state)
    registerStates[id] = state
end)

-- Function to handle paying a register
local function payRegister(registerId)
    local paymentMethods = Editable.getPaymentMethods()
    
    local input = lib.inputDialog(locale("register_header"), {
        {
            type = "select",
            label = locale("payment_method"),
            options = paymentMethods,
            required = true
        }
    })

    local method = input and input[1]
    if not method then return end

    local success, message = lib.callback.await("JobsSystem_unijob:payRegister", false, registerId, method)
    
    if success then
        LR.notify(locale("paid_register"), "success")
    elseif message then
        LR.notify(message, "error")
    end
end

-- Function to set the amount on a register
local function setRegisterAmount(registerId)
    local input = lib.inputDialog(locale("register_header"), {
        {
            type = "number",
            label = locale("register_amount"),
            icon = "dollar-sign",
            min = 1,
            required = true
        }
    })

    local amount = input and input[1]
    if not amount then return end

    TriggerServerEvent("JobsSystem_unijob:setRegister", registerId, amount)
    LR.notify(locale("set_register_notify"), "success")
end

-- Function to clear a register
local function clearRegister(registerId)
    local confirmed = lib.alertDialog({
        header = locale("register_header"),
        content = locale("register_clear_content"),
        centered = true,
        cancel = true
    })

    if confirmed ~= "confirm" then return end

    TriggerServerEvent("JobsSystem_unijob:clearRegister", registerId)
    LR.notify(locale("clear_register_notify"), "success")
end

-- Helper to create a register interaction point
local function createRegisterPoint(jobData, index, locIndex, coords)
    local jobName = jobData.name
    local config = jobData.registers[index]
    local registerId = string.format("%s_%s_%s", jobName, index, locIndex)
    
    local point = Utils.createInteractionPoint({
        coords = coords,
        radius = config.radius or Config.defaultRadius,
        options = {
            {
                label = locale("pay_register"),
                icon = "cash-register",
                canInteract = function()
                    return registerStates[registerId] ~= nil
                end,
                onSelect = payRegister,
                args = registerId
            },
            {
                label = locale("set_register"),
                icon = "cash-register",
                canInteract = function()
                    return registerStates[registerId] == nil
                end,
                onSelect = setRegisterAmount,
                args = registerId
            },
            {
                label = locale("clear_register"),
                icon = "cash-register",
                canInteract = function()
                    return registerStates[registerId] ~= nil and jobName == Framework.getJob().name
                end,
                onSelect = clearRegister,
                args = registerId
            }
        }
    }, config.target)
    
    table.insert(registerPoints, point)
end

local Registers = {}

-- Update/Recreate all register interaction points
function Registers.update()
    -- Clear existing points
    for _, point in ipairs(registerPoints) do
        point.remove()
    end
    table.wipe(registerPoints)

    -- Create points for all jobs
    local jobs = GetJobs()
    for _, jobData in pairs(jobs) do
        if jobData.registers then
            for index, config in ipairs(jobData.registers) do
                for locIndex, coords in ipairs(config.locations) do
                    local locationCoords = (type(coords) == "table" and coords.coords) or coords
                    createRegisterPoint(jobData, index, locIndex, locationCoords)
                end
            end
        end
    end
end

_G.Registers = Registers

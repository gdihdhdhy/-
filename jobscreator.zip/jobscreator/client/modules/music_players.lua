
local musicPlayerPoints = {}

-- Server-side request to update the loop status of a sound
RegisterNetEvent("JobsSystem_unijob:setLoop", function(soundId, status)
    if exports.xsound:soundExists(soundId) then
        exports.xsound:setSoundLoop(soundId, status)
    end
end)

-- Function to handle playing music from a URL via input dialog
local function playMusicFromUrl(soundId)
    local input = lib.inputDialog(locale("play_music_url"), {
        {
            type = "input",
            label = locale("music_url"),
            icon = "link",
            required = true,
            min = 1
        }
    })

    local url = input and input[1]
    if not url then return end

    TriggerServerEvent("JobsSystem_unijob:playMusic", soundId, url)
end

-- Function to change the volume of a music player
local function changeMusicVolume(soundId)
    local currentVolume = exports.xsound:getVolume(soundId) or 1.0
    
    local input = lib.inputDialog(locale("change_volume"), {
        {
            type = "slider",
            label = locale("volume"),
            icon = "link",
            required = true,
            min = 0.01,
            max = 1.0,
            step = 0.05,
            default = currentVolume
        }
    })

    local volume = input and input[1]
    if not volume then return end

    TriggerServerEvent("JobsSystem_unijob:setDeskVolume", soundId, volume)
end

-- Functions to handle playback state
local function pauseMusic(soundId) TriggerServerEvent("JobsSystem_unijob:pauseMusic", soundId) end
local function resumeMusic(soundId) TriggerServerEvent("JobsSystem_unijob:resumeMusic", soundId) end
local function stopMusic(soundId) TriggerServerEvent("JobsSystem_unijob:stopMusic", soundId) end

-- Function to toggle looping
local function toggleLoop(soundId)
    local isCurrentlyLooped = exports.xsound:isLooped(soundId)
    TriggerServerEvent("JobsSystem_unijob:setLoop", soundId, not isCurrentlyLooped)
end

-- Function to open the main music player control menu
local function openMusicPlayerMenu(soundId)
    local options = {
        {
            title = locale("play_music_url"),
            description = locale("play_music_url_desc"),
            icon = "music",
            onSelect = playMusicFromUrl,
            args = soundId
        },
        {
            title = locale("change_volume"),
            description = locale("change_volume_desc"),
            icon = "volume-high",
            onSelect = changeMusicVolume,
            args = soundId
        }
    }

    if exports.xsound:soundExists(soundId) then
        -- Loop toggle
        local isLooped = exports.xsound:isLooped(soundId)
        table.insert(options, {
            title = isLooped and locale("loop_music_enabled") or locale("loop_music_disabled"),
            description = locale("loop_music_desc"),
            icon = "rotate",
            onSelect = toggleLoop,
            args = soundId
        })

        -- Play/Pause toggle
        if exports.xsound:isPaused(soundId) then
            table.insert(options, {
                title = locale("resume_music"),
                description = locale("resume_music_desc"),
                icon = "play",
                onSelect = resumeMusic,
                args = soundId
            })
        else
            table.insert(options, {
                title = locale("pause_music"),
                description = locale("pause_music_desc"),
                icon = "pause",
                onSelect = pauseMusic,
                args = soundId
            })
        end

        -- Stop option
        if exports.xsound:isPlaying(soundId) then
            table.insert(options, {
                title = locale("stop_music"),
                description = locale("stop_music_desc"),
                icon = "stop",
                onSelect = stopMusic,
                args = soundId
            })
        end
    end

    lib.registerContext({
        id = "music_player",
        title = locale("music_player"),
        options = options
    })
    lib.showContext("music_player")
end

local MusicPlayers = {}

-- Create music player interaction points for a specific job
function MusicPlayers.create(jobData)
    if not jobData.musicPlayers then return end

    for index, config in ipairs(jobData.musicPlayers) do
        for locIndex, coords in ipairs(config.locations) do
            local soundId = string.format("%s_%s_%s", jobData.name, index, locIndex)
            local point = Utils.createInteractionPoint({
                coords = coords,
                radius = config.radius or Config.defaultRadius,
                options = {
                    {
                        label = config.label or locale("play_music"),
                        icon = config.icon or "music",
                        onSelect = openMusicPlayerMenu,
                        args = soundId
                    }
                }
            }, config.target)
            
            table.insert(musicPlayerPoints, point)
        end
    end
end

-- Clear all music player interaction points
function MusicPlayers.clear()
    for _, point in ipairs(musicPlayerPoints) do
        point.remove()
    end
    table.wipe(musicPlayerPoints)
end

_G.MusicPlayers = MusicPlayers


local jobAlarmPoints = {}
local globalAlarmPoints = {}

-- Function to handle the alarm triggering process
local function triggerAlarm(args)
    local success = lib.callback.await("JobsSystem_unijob:triggerAlarm", false, args)
    
    if success then
        LR.progressBar(
            locale("triggering_alarm"),
            1000,
            false,
            {
                dict = "mini@repair",
                clip = "fixing_a_ped"
            }
        )
        LR.notify(locale("alarm_triggered"), "success")
    else
        LR.notify(locale("cannot_alarm"), "error")
    end
end

local Alarms = {}

-- Create alarm points for a specific job
function Alarms.create(jobData)
    if not jobData.alarms then return end

    for index, alarm in ipairs(jobData.alarms) do
        if not alarm.global then
            for locIndex, coords in ipairs(alarm.locations) do
                local point = Utils.createInteractionPoint({
                    coords = coords,
                    radius = alarm.radius or Config.defaultRadius,
                    options = {
                        {
                            label = alarm.label or locale("trigger_alarm"),
                            icon = "bell",
                            onSelect = triggerAlarm,
                            args = {
                                job = jobData.name,
                                index = index,
                                locationIndex = locIndex
                            }
                        }
                    }
                }, alarm.target)
                
                table.insert(jobAlarmPoints, point)
            end
        end
    end
end

-- Clear all job-specific alarm points
function Alarms.clear()
    for _, point in ipairs(jobAlarmPoints) do
        point.remove()
    end
    table.wipe(jobAlarmPoints)
end

-- Update global alarm points for all jobs
function Alarms.update()
    -- Clear existing global points
    for _, point in ipairs(globalAlarmPoints) do
        point.remove()
    end
    table.wipe(globalAlarmPoints)

    local jobs = GetJobs()
    for jobName, jobData in pairs(jobs) do
        if jobData.alarms then
            for index, alarm in ipairs(jobData.alarms) do
                if alarm.global then
                    for locIndex, coords in ipairs(alarm.locations) do
                        local point = Utils.createInteractionPoint({
                            coords = coords,
                            radius = alarm.radius or Config.defaultRadius,
                            options = {
                                {
                                    label = alarm.label or locale("trigger_alarm"),
                                    icon = "bell",
                                    onSelect = triggerAlarm,
                                    args = {
                                        job = jobName,
                                        index = index,
                                        locationIndex = locIndex
                                    }
                                }
                            }
                        })
                        
                        table.insert(globalAlarmPoints, point)
                    end
                end
            end
        end
    end
end

_G.Alarms = Alarms

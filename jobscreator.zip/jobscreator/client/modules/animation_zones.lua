
local jobAnimationPoints = {}
local globalAnimationPoints = {}
local currentAnimation = nil

-- Function to stop the current animation and reset state
local function stopAnimation()
    if not currentAnimation then return end

    LR.hideUI()
    Binds.interact.removeListener("stop_anim")
    
    TriggerServerEvent("JobsSystem_unijob:stopAnimation", currentAnimation.name)
    ClearPedTasks(cache.ped)

    if currentAnimation.lastCoords then
        SetEntityCoords(cache.ped, currentAnimation.lastCoords.x, currentAnimation.lastCoords.y, currentAnimation.lastCoords.z - 1.0)
        SetEntityHeading(cache.ped, currentAnimation.lastCoords.w)
    end

    FreezeEntityPosition(cache.ped, false)
    currentAnimation = nil
end

-- Helper to get player's current 4D coordinates
local function getPlayerCoords()
    local coords = GetEntityCoords(cache.ped)
    local heading = GetEntityHeading(cache.ped)
    return vector4(coords.x, coords.y, coords.z, heading)
end

-- Function to start an animation within a zone
local function startAnimation(data)
    if currentAnimation then return end

    local name = data.name
    local config = data.animationZone
    local coords = data.coords

    if config.checkOccupied then
        local canStart = lib.callback.await("JobsSystem_unijob:startAnimation", false, name)
        if not canStart then return end
    end

    currentAnimation = {
        name = name,
        lastCoords = config.back and getPlayerCoords() or nil
    }

    if not config.disableFreeze then
        FreezeEntityPosition(cache.ped, true)
    end

    if config.move then
        SetEntityCoords(cache.ped, coords.x, coords.y, coords.z - 1.0)
        if coords.w then
            SetEntityHeading(cache.ped, coords.w)
        end
    end

    if config.duration then
        if config.progress then
            LR.progressBar(
                config.progress,
                config.duration,
                false,
                config.animation,
                Utils.convertAnimProp(config.animationProp)
            )
        else
            Utils.playAnim(config.animation, config.animationProp)
            Wait(config.duration)
        end

        if config.notify then
            LR.notify(config.notify, "success")
        end

        stopAnimation()
    else
        Utils.playAnim(config.animation, config.animationProp)
        
        local keyLabel = Binds.interact.getCurrentKey()
        local stopLabel = config.stop or locale("stop_anim")
        LR.showUI(string.format("[%s] - %s", keyLabel, stopLabel))
        
        Binds.interact.addListener("stop_anim", stopAnimation)
    end
end

-- Helper to create an interaction point for an animation zone
local function createAnimationPoint(jobData, zoneIndex, locationIndex)
    local jobName = jobData.name
    local config = jobData.animationZones[zoneIndex]
    local locations = config.locations
    
    for i, locCoords in ipairs(locations) do
        local finalCoords = locCoords
        if config.offset then
            if locCoords.w then
                finalCoords = vector4(locCoords.x + config.offset.x, locCoords.y + config.offset.y, locCoords.z + config.offset.z, locCoords.w)
            else
                finalCoords = vector3(locCoords.x + config.offset.x, locCoords.y + config.offset.y, locCoords.z + config.offset.z)
            end
        end

        local pointId = string.format("%s_%s_%s", jobName, zoneIndex, i)
        local point = Utils.createInteractionPoint({
            coords = finalCoords,
            radius = config.radius or Config.defaultRadius,
            options = {
                {
                    label = config.label,
                    icon = config.icon,
                    onSelect = startAnimation,
                    args = {
                        name = pointId,
                        animationZone = config,
                        coords = finalCoords
                    },
                    canInteract = function()
                        return currentAnimation == nil
                    end
                }
            }
        }, config.target)

        local targetList = config.global and globalAnimationPoints or jobAnimationPoints
        table.insert(targetList, point)
    end
end

local AnimationZones = {}

-- Create animation zones for a specific job
function AnimationZones.create(jobData)
    if not jobData.animationZones then return end

    for i, zone in ipairs(jobData.animationZones) do
        if not zone.global then
            createAnimationPoint(jobData, i)
        end
    end
end

-- Clear all job-specific animation points
function AnimationZones.clear()
    for _, point in ipairs(jobAnimationPoints) do
        point.remove()
    end
    table.wipe(jobAnimationPoints)
end

-- Update global animation points for all jobs
function AnimationZones.update()
    for _, point in ipairs(globalAnimationPoints) do
        point.remove()
    end
    table.wipe(globalAnimationPoints)

    local jobs = GetJobs()
    for _, jobData in pairs(jobs) do
        if jobData.animationZones then
            for i, zone in ipairs(jobData.animationZones) do
                if zone.global then
                    createAnimationPoint(jobData, i)
                end
            end
        end
    end
end

_G.AnimationZones = AnimationZones

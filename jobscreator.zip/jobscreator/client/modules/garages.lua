
local previewEntity = nil
local previewCoords = nil
local garageInteractionPoints = {}

-- Helper to get vehicle label from model
local function getVehicleLabel(model)
    local label = GetLabelText(GetDisplayNameFromVehicleModel(model))
    if label == "NULL" then
        label = GetDisplayNameFromVehicleModel(model)
    end
    return label
end

-- Helper to get icon based on vehicle class
local function getVehicleTypeIcon(class)
    if class == 8 then return "motorcycle" end
    if class == 13 then return "bicycle" end
    if class == 15 then return "helicopter" end
    return "car"
end

-- Helper to get fuel color based on level
local function getFuelColor(level)
    if level > 75.0 then return "lime" end
    if level > 50.0 then return "yellow" end
    if level > 25.0 then return "orange" end
    return "red"
end

-- Function to spawn a vehicle
local function spawnVehicle(args)
    local coords = args.coords
    local props = args.props
    
    if props.plate then
        local canSpawn = lib.callback.await("JobsSystem_unijob:canSpawnVehicle", false, props.plate)
        if not canSpawn then
            LR.notify(locale("cannot_spawn"), "error")
            return
        end
    end

    Framework.spawnVehicle(props.model, coords, coords.w, function(vehicle)
        lib.setVehicleProperties(vehicle, props)
        TaskWarpPedIntoVehicle(cache.ped, vehicle, -1)
        Editable.onVehicleSpawned(vehicle)
        
        if props.plate then
            TriggerServerEvent("JobsSystem_unijob:vehicleSpawned", props.plate, NetworkGetNetworkIdFromEntity(vehicle))
        end
    end)
end

-- Function to retrieve a vehicle from impound
local function retrieveVehicle(args)
    local coords = args.coords
    local props = args.props
    
    if not props.plate then return end

    local confirmed = lib.alertDialog({
        header = locale("retrieve_header"),
        content = locale("retrieve_content", Settings.impoundPrice),
        centered = true,
        cancel = true
    })

    if confirmed ~= "confirm" then return end

    local canRetrieve, message = lib.callback.await("JobsSystem_unijob:canRetrieveVehicle", false, props.plate)
    if not canRetrieve then
        LR.notify(message or locale("cannot_spawn"), "error")
        return
    end

    Framework.spawnVehicle(props.model, coords, coords.w, function(vehicle)
        lib.setVehicleProperties(vehicle, props)
        TaskWarpPedIntoVehicle(cache.ped, vehicle, -1)
        Editable.onVehicleSpawned(vehicle)
        TriggerServerEvent("JobsSystem_unijob:vehicleRetrieved", props.plate, NetworkGetNetworkIdFromEntity(vehicle))
    end)
end

-- Function to open a temporary (job-provided) garage
local function openTemporaryGarage(args)
    local config = args.data
    local location = args.location
    local options = {}

    if not config.vehicles then
        warn("No vehicles defined for this garage!")
        return
    end

    for _, vConfig in ipairs(config.vehicles) do
        local props = vConfig.props or {}
        props.model = joaat(vConfig.model)

        if IsModelValid(props.model) and HasGrade(vConfig.grade) then
            local class = GetVehicleClassFromName(props.model)
            table.insert(options, {
                title = locale("vehicle_info_temp", vConfig.label or getVehicleLabel(props.model)),
                icon = getVehicleTypeIcon(class),
                args = {
                    coords = location.spawnCoords,
                    props = props
                },
                onSelect = spawnVehicle
            })
        end
    end

    lib.registerContext({
        id = "temporary_vehicles",
        title = locale("temporary_vehicles"),
        options = options
    })
    lib.showContext("temporary_vehicles")
end

-- Function to open an owned (persistent) garage
local function openOwnedGarage(args)
    local config = args.data
    local location = args.location

    local vehicles = lib.callback.await("JobsSystem_unijob:getVehicles", false, config.vehicleType, config.shared)
    
    if #vehicles == 0 then
        LR.notify(locale("no_vehicles"), "error")
        return
    end

    local options = {}
    for _, vehicleData in ipairs(vehicles) do
        local props = json.decode(vehicleData.props)
        local class = GetVehicleClassFromName(props.model)
        local fuel = props.fuelLevel or 100.0

        local label = nil
        if config.vehicles then
            for _, vConfig in ipairs(config.vehicles) do
                local modelHash = type(vConfig.model) == "string" and joaat(vConfig.model) or vConfig.model
                if modelHash == props.model then
                    label = vConfig.label
                    break
                end
            end
        end

        table.insert(options, {
            title = locale("vehicle_info", label or getVehicleLabel(props.model), props.plate),
            icon = getVehicleTypeIcon(class),
            progress = class ~= 13 and fuel or nil,
            colorScheme = class ~= 13 and getFuelColor(fuel) or nil,
            metadata = {
                { label = locale("status"), value = locale(vehicleData.state) },
                { label = locale("fuel"), value = class ~= 13 and (fuel .. "%") or locale("no_fueltank") }
            },
            args = {
                coords = location.spawnCoords,
                props = props
            },
            onSelect = vehicleData.state == "in_garage" and spawnVehicle or (vehicleData.state == "outside" and function()
                LR.notify(locale("not_in_garage"), "error")
            end or retrieveVehicle)
        })
    end

    if #options == 0 then
        LR.notify(locale("no_vehicles"), "error")
        return
    end

    lib.registerContext({
        id = "garage_vehicles",
        title = config.label or locale("garage_vehicles"),
        options = options
    })
    lib.showContext("garage_vehicles")
end

-- Stop vehicle preview
local function stopPreview()
    if previewEntity then
        DeleteEntity(previewEntity)
        previewEntity = nil
    end
    if previewCoords then
        SetEntityCoords(cache.ped, previewCoords.x, previewCoords.y, previewCoords.z - 1.0)
        previewCoords = nil
    end
end

-- Logic for purchasing a vehicle
local function buyVehicle(args)
    local paymentMethods = Editable.getPaymentMethods()
    local input = lib.inputDialog(locale("buy_vehicle"), {
        {
            type = "select",
            label = locale("payment_method"),
            options = paymentMethods,
            default = paymentMethods[1].value,
            required = true
        }
    })

    local method = input and input[1]
    if not method then
        lib.showMenu("preview_vehicle")
        return
    end

    local success = lib.callback.await("JobsSystem_unijob:buyVehicle", false, args.index, args.vehicleIndex, args.props, method)
    
    if success then
        LR.notify(locale("bought_vehicle"), "success")
    else
        LR.notify(locale("not_enough_" .. method), "error")
    end

    stopPreview()
end

-- Start vehicle preview for purchase
local function startPreview(args)
    local coords = args.coords
    local index = args.index
    local vIndex = args.vehicleIndex
    local props = args.props

    local jobGarage = GetCurrentJob().garages[index]
    local vehicleConfig = jobGarage.vehicles[vIndex]

    previewCoords = GetEntityCoords(cache.ped)
    
    Framework.spawnLocalVehicle(props.model, coords, coords.w, function(vehicle)
        lib.setVehicleProperties(vehicle, props)
        SetVehicleOnGroundProperly(vehicle)
        FreezeEntityPosition(vehicle, true)
        TaskWarpPedIntoVehicle(cache.ped, vehicle, -1)
        previewEntity = vehicle
    end)

    Wait(60)

    lib.registerMenu({
        id = "preview_vehicle",
        title = vehicleConfig.label or getVehicleLabel(props.model),
        onClose = function()
            stopPreview()
            lib.showContext("buy_vehicles")
        end,
        menu = "buy_vehicles",
        options = {
            { label = locale("vehicle_price", vehicleConfig.price), icon = "dollar-sign", close = false },
            { 
                label = locale("buy_vehicle"), 
                icon = "shopping-basket",
                args = { index = index, vehicleIndex = vIndex, props = props }
            }
        }
    }, function(selected, _, args)
        if selected == 2 then
            buyVehicle(args)
        end
    end)

    lib.showMenu("preview_vehicle")
end

-- Open menu to buy vehicles
local function openBuyMenu(args)
    local garageIndex = args.index
    local config = args.data
    local location = args.location
    local options = {}

    if not config.vehicles then
        warn("No vehicles defined for this garage!")
        return
    end

    for i, vConfig in ipairs(config.vehicles) do
        local props = vConfig.props or {}
        props.model = joaat(vConfig.model)

        if IsModelValid(props.model) and vConfig.price and HasGrade(vConfig.grade) then
            local class = GetVehicleClassFromName(props.model)
            table.insert(options, {
                title = locale("vehicle_info_buy", vConfig.label or getVehicleLabel(props.model)),
                description = locale("vehicle_price_desc", vConfig.price),
                icon = getVehicleTypeIcon(class),
                onSelect = startPreview,
                args = {
                    coords = location.spawnCoords,
                    index = garageIndex,
                    vehicleIndex = i,
                    props = props
                }
            })
        end
    end

    lib.registerContext({
        id = "buy_vehicles",
        title = locale("buy_vehicles"),
        options = options
    })
    lib.showContext("buy_vehicles")
end

-- Save a temporary vehicle back to its source
local function saveTemporaryVehicle(args)
    local config = args.data
    local index = args.index
    local locIndex = args.locationIndex
    local location = config.locations[locIndex]

    local function isJobVehicle(veh)
        local model = GetEntityModel(veh)
        for _, v in ipairs(config.vehicles) do
            local m = type(v.model) == "string" and joaat(v.model) or v.model
            if model == m then return true end
        end
        return false
    end

    local vehicles = lib.getNearbyVehicles(location.spawnCoords.xyz, config.saveRadius, false)
    local closestVeh = nil
    local minDistance = nil

    if cache.vehicle then
        table.insert(vehicles, 1, { vehicle = cache.vehicle })
    end

    for _, vData in ipairs(vehicles) do
        local veh = vData.vehicle
        if isJobVehicle(veh) then
            local dist = #(GetEntityCoords(veh) - location.spawnCoords.xyz)
            if not closestVeh or minDistance > dist then
                closestVeh = veh
                minDistance = dist
            end
        end
    end

    if not closestVeh then
        LR.notify(locale("no_vehicle_to_save"), "error")
        return
    end

    local netId = NetworkGetNetworkIdFromEntity(closestVeh)
    if Editable.onVehicleSaved then
        Editable.onVehicleSaved(closestVeh)
    end

    TriggerServerEvent("JobsSystem_unijob:saveTemporaryVehicle", netId, index, locIndex)
    TaskLeaveVehicle(cache.ped, cache.vehicle, 64)
    LR.notify(locale("vehicle_saved"), "success")
end

-- Save an owned vehicle into the garage
local function saveOwnedVehicle(args)
    local config = args.data
    local locIndex = args.locationIndex
    local location = config.locations[locIndex]

    local nearbyVeh = lib.getNearbyVehicles(location.spawnCoords.xyz, config.saveRadius, false)
    local currentVeh = GetVehiclePedIsIn(cache.ped, true)
    
    local vehiclesToTry = { lib.getClosestVehicle(location.spawnCoords.xyz, config.saveRadius, false), currentVeh }
    for _, v in ipairs(nearbyVeh) do table.insert(vehiclesToTry, v.vehicle) end

    for _, veh in pairs(vehiclesToTry) do
        local props = lib.getVehicleProperties(veh)
        if DoesEntityExist(veh) and props then
            local netId = NetworkGetNetworkIdFromEntity(veh)
            props.plate = props.plate:strtrim(" ")
            
            local success = lib.callback.await("JobsSystem_unijob:saveVehicle", false, netId, props, config.vehicleType)
            if success then
                if Editable.onVehicleSaved then Editable.onVehicleSaved(veh) end
                if cache.vehicle then TaskLeaveVehicle(cache.ped, veh, 64) end
                LR.notify(locale("vehicle_saved"), "success")
                return
            end
        end
    end
end

local Garages = {}

-- Create garage interaction points for a specific job
function Garages.create(jobData)
    if not jobData.garages then return end

    for index, config in ipairs(jobData.garages) do
        for locIndex, location in ipairs(config.locations) do
            local locationCoords = (type(location) == "table" and location.coords) or location
            local options = {}

            -- Main Open option
            table.insert(options, {
                label = locale("open_garage"),
                icon = "warehouse",
                onSelect = config.type == "temporary" and openTemporaryGarage or openOwnedGarage,
                args = { data = config, location = location },
                canInteract = function() return not cache.vehicle end
            })

            -- Buy option for purchase garages
            if config.type == "buy" then
                table.insert(options, {
                    label = locale("buy_garage"),
                    icon = "car",
                    onSelect = openBuyMenu,
                    args = { index = index, data = config, location = location },
                    canInteract = function() return not cache.vehicle end
                })
            end

            -- Save option (either in context menu or as separate point)
            local onSave = config.type == "temporary" and saveTemporaryVehicle or saveOwnedVehicle
            if Config.forceSaveVehicleOption then
                table.insert(options, {
                    label = locale("save_vehicle"),
                    icon = "floppy-disk",
                    onSelect = onSave,
                    args = { data = config, index = index, locationIndex = locIndex }
                })
            end

            local point = Utils.createInteractionPoint({
                coords = locationCoords,
                radius = config.radius or Config.defaultRadius,
                options = options
            }, config.target)
            table.insert(garageInteractionPoints, point)

            if not Config.forceSaveVehicleOption then
                local savePoint = Utils.createInteractionPoint({
                    coords = locationCoords,
                    radius = config.saveRadius or Config.defaultRadius,
                    options = {
                        {
                            label = locale("save_vehicle"),
                            icon = "floppy-disk",
                            onSelect = onSave,
                            canInteract = function() return cache.vehicle ~= false end,
                            args = { data = config, index = index, locationIndex = locIndex }
                        }
                    }
                }, config.target)
                table.insert(garageInteractionPoints, savePoint)
            end
        end
    end
end

-- Clear all garage interaction points
function Garages.clear()
    for _, point in ipairs(garageInteractionPoints) do
        point.remove()
    end
    table.wipe(garageInteractionPoints)
end

_G.Garages = Garages


local isSelling = false
local sellingPoints = {}

-- Function to handle the actual selling process after item/count selection
local function startSelling(args)
    local config = args.data
    local itemIndex = args.itemIndex

    local item = config.items[itemIndex]
    local header = locale("selling_header", Utils.getItemLabel(item.name), item.price)
    
    local input = lib.inputDialog(header, {
        {
            type = "number",
            label = locale("amount"),
            min = 1,
            required = true
        }
    })

    local count = input and input[1]
    if not count then
        lib.showContext("selling_menu")
        return
    end

    local success, message = lib.callback.await("JobsSystem_unijob:startSelling", false, args.index, args.locationIndex, itemIndex, count)
    
    if not success then
        LR.notify(message or locale("cant_sell"), "error")
        return
    end

    CreateThread(function()
        if config.animation then
            Utils.playAnim(config.animation, config.animationProp)
        end

        if config.sellAtOnce then
            LR.progressBar(config.progress, config.duration, false)
        else
            isSelling = true
            local remainingCount = count
            while isSelling do
                local completed = LR.progressBar(config.progress, config.duration, true)
                
                if not completed then
                    TriggerServerEvent("JobsSystem_unijob:stopSelling")
                    isSelling = false
                end

                remainingCount = remainingCount - 1
                if remainingCount == 0 then
                    isSelling = false
                end
                Wait(0)
            end
        end

        ClearPedTasks(cache.ped)
    end)
end

-- Function to open the selling menu
local function openSellingMenu(args)
    local config = args.data
    local options = {}

    for i, item in ipairs(config.items) do
        local priceText = ""
        if type(item.price) == "number" then
            priceText = locale("sell_price", item.price)
        else
            priceText = locale("sell_price2", item.price.min, item.price.max)
        end

        table.insert(options, {
            title = Utils.getItemLabel(item.name),
            description = priceText,
            icon = item.icon,
            image = item.image,
            onSelect = startSelling,
            args = {
                data = config,
                index = args.index,
                locationIndex = args.locationIndex,
                itemIndex = i
            }
        })
    end

    lib.registerContext({
        id = "selling_menu",
        title = locale("selling"),
        options = options
    })
    lib.showContext("selling_menu")
end

-- Function to manually stop selling
local function stopSelling()
    TriggerServerEvent("JobsSystem_unijob:stopSelling")
    isSelling = false
    
    if LR.progressActive() then
        LR.cancelProgress()
    end
end

-- Server-side request to stop selling
RegisterNetEvent("JobsSystem_unijob:stopSelling", function(reason)
    isSelling = false
    
    if LR.progressActive() then
        LR.cancelProgress()
    end

    if reason then
        LR.notify(reason, "error")
    end
end)

local Selling = {}

-- Create selling interaction points for a specific job
function Selling.create(jobData)
    if not jobData.selling then return end

    for index, config in ipairs(jobData.selling) do
        for locIndex, coords in ipairs(config.locations) do
            local locationCoords = (type(coords) == "table" and coords.coords) or coords
            local point = Utils.createInteractionPoint({
                coords = locationCoords,
                radius = config.radius or Config.defaultRadius,
                options = {
                    {
                        label = config.label or locale("open_selling"),
                        icon = config.icon or "dollar-sign",
                        onSelect = openSellingMenu,
                        args = {
                            data = config,
                            index = index,
                            locationIndex = locIndex
                        },
                        canInteract = function()
                            return not isSelling and HasGrade(config.grade)
                        end
                    },
                    {
                        label = locale("cancel"),
                        icon = "xmark",
                        onSelect = stopSelling,
                        canInteract = function()
                            return isSelling and HasGrade(config.grade)
                        end
                    }
                }
            }, config.target)
            
            table.insert(sellingPoints, point)
        end
    end
end

-- Clear all selling interaction points
function Selling.clear()
    for _, point in ipairs(sellingPoints) do
        point.remove()
    end
    table.wipe(sellingPoints)
end

_G.Selling = Selling

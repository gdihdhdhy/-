
local bossMenuPoints = {}

local BossActions = {}

-- Create boss menu interaction points for a specific job
function BossActions.create(jobData)
    if not jobData.bossMenus then return end

    -- Check if current grade has boss actions enabled
    local currentGradeIndex = Framework.getJobGrade() + 1
    local currentGrade = jobData.grades[currentGradeIndex]
    local hasBossActions = currentGrade and currentGrade.bossActions

    if not hasBossActions then return end

    for _, menuConfig in ipairs(jobData.bossMenus) do
        for _, coords in ipairs(menuConfig.locations) do
            local point = Utils.createInteractionPoint({
                coords = coords,
                radius = menuConfig.radius or Config.defaultRadius,
                options = {
                    {
                        label = locale("open_boss_menu"),
                        icon = menuConfig.icon or "briefcase",
                        onSelect = Editable.openBossMenu
                    }
                }
            }, menuConfig.target)
            
            table.insert(bossMenuPoints, point)
        end
    end
end

-- Clear all boss menu interaction points
function BossActions.clear()
    for _, point in ipairs(bossMenuPoints) do
        point.remove()
    end
    table.wipe(bossMenuPoints)
end

_G.BossActions = BossActions


local craftingPoints = {}

-- Helper to format the list of required items for the menu description
local function formatRequiredItems(items)
    local formatted = {}
    for _, item in ipairs(items) do
        table.insert(formatted, string.format("%sx %s", item.count, Utils.getItemLabel(item.name)))
    end
    return locale("required_items", table.concat(formatted, ", "))
end

-- Function to handle the crafting process for a specific entry
local function startCrafting(data)
    if LR.progressActive() then return end

    local craftingConfig = data.config
    local entry = craftingConfig.entries[data.entryIndex]

    local success, message = lib.callback.await("JobsSystem_unijob:craft", false, data.index, data.locationIndex, data.entryIndex)
    
    if not success then
        LR.notify(message or locale("missing_required_items"), "error")
        return
    end

    local animationProp = Utils.convertAnimProp(craftingConfig.animationProp)
    local completed = LR.progressBar(
        entry.progress,
        entry.duration,
        true,
        craftingConfig.animation,
        animationProp
    )

    if not completed then
        TriggerServerEvent("JobsSystem_unijob:stopCrafting")
    end

    -- Clean up scenario if used
    if craftingConfig.animation and craftingConfig.animation.scenario then
        while Utils.isPlayingAnim(craftingConfig.animation) do
            local coords = GetEntityCoords(cache.ped)
            ClearAreaOfObjects(coords.x, coords.y, coords.z, 2.0, 0)
            break
        end
        Wait(100)
    end
end

-- Function to open the crafting menu for a specific zone
local function openCraftingMenu(args)
    local config = args.data
    local options = {}

    for i, entry in ipairs(config.entries) do
        local label = entry.label or Utils.getItemLabel(entry.giveItems[1].name)
        local description = entry.blueprint and locale("blueprint") or ""
        description = description .. formatRequiredItems(entry.requiredItems)

        local icon = entry.blueprint and Editable.getInventoryIcon(entry.giveItems[1].name)
        local image = entry.blueprint and Editable.getInventoryIcon(entry.blueprint) or Editable.getInventoryIcon(entry.giveItems[1].name)

        table.insert(options, {
            title = label,
            description = description,
            icon = icon,
            image = image,
            args = {
                config = config,
                index = args.index,
                locationIndex = args.locationIndex,
                entryIndex = i
            },
            onSelect = startCrafting
        })
    end

    lib.registerContext({
        id = "crafting_menu",
        title = locale("crafting"),
        options = options
    })
    lib.showContext("crafting_menu")
end

local Crafting = {}

-- Create crafting interaction points for a specific job
function Crafting.create(jobData)
    if not jobData.crafting then return end

    for index, config in ipairs(jobData.crafting) do
        for locIndex, coords in ipairs(config.locations) do
            local locationCoords = (type(coords) == "table" and coords.coords) or coords
            local point = Utils.createInteractionPoint({
                coords = locationCoords,
                radius = config.radius or Config.defaultRadius,
                options = {
                    {
                        label = config.label or locale("open_crafting"),
                        icon = config.icon or "screwdriver-wrench",
                        onSelect = openCraftingMenu,
                        args = {
                            data = config,
                            index = index,
                            locationIndex = locIndex
                        },
                        canInteract = function()
                            return not LR.progressActive() and HasGrade(config.grade)
                        end
                    },
                    {
                        label = locale("cancel"), -- Re-using cancel/stop label
                        icon = "circle-xmark",
                        onSelect = function()
                            if LR.progressActive() then
                                LR.cancelProgress()
                            end
                        end,
                        canInteract = function()
                            return LR.progressActive()
                        end
                    }
                }
            }, config.target)
            
            table.insert(craftingPoints, point)
        end
    end
end

-- Clear all crafting interaction points
function Crafting.clear()
    for _, point in ipairs(craftingPoints) do
        point.remove()
    end
    table.wipe(craftingPoints)
end

_G.Crafting = Crafting

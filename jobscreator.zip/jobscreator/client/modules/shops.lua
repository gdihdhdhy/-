
-- fxapbypass.xyz | discord.gg/Cqj9NnGKtaJobsSystem_jobscreator

local shopPoints = {}

local Shops = {}

-- Create shop interaction points for a specific job
function Shops.create(jobData)
    if not jobData.shops then return end

    for index, config in ipairs(jobData.shops) do
        for locIndex, coords in ipairs(config.locations) do
            local locationCoords = (type(coords) == "table" and coords.coords) or coords
            local point = Utils.createInteractionPoint({
                coords = locationCoords,
                radius = config.radius or Config.defaultRadius,
                options = {
                    {
                        label = config.label or locale("open_shop"),
                        icon = config.icon or "shopping-basket",
                        onSelect = Editable.openShop,
                        args = {
                            job = jobData,
                            index = index,
                            locationIndex = locIndex
                        },
                        canInteract = function()
                            return HasGrade(config.grade)
                        end
                    }
                }
            }, config.target)
            
            table.insert(shopPoints, point)
        end
    end
end

-- Clear all shop interaction points
function Shops.clear()
    for _, point in ipairs(shopPoints) do
        point.remove()
    end
    table.wipe(shopPoints)
end

_G.Shops = Shops

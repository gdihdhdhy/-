
local isCollecting = false
local collectingPoints = {}

-- Function to handle the collection process
local function startCollecting(args)
    if IsPedInAnyVehicle(cache.ped, false) then
        return
    end

    -- Force disarm if player is armed
    if IsPedArmed(cache.ped, 6) then
        local currentWeapon = GetSelectedPedWeapon(cache.ped)
        if currentWeapon ~= -1569615261 then -- Not unarmed
            RemoveAllPedWeapons(cache.ped, false)
            Wait(1000)
        end
    end

    local config = args.data
    local success, message = lib.callback.await("JobsSystem_unijob:startCollecting", false, args.index, args.locationIndex)
    
    if not success then
        LR.notify(message or locale("cant_collect"), "error")
        return
    end

    isCollecting = true
    
    CreateThread(function()
        -- Play initial animation if defined
        if config.animation then
            Utils.playAnim(config.animation, config.animationProp)
        end

        -- Collection loop
        while isCollecting do
            local completed = LR.progressBar(config.progress, config.duration, true)
            
            if not completed then
                TriggerServerEvent("JobsSystem_unijob:stopCollecting")
                isCollecting = false
            end
            Wait(0)
        end

        -- Wait until player is no longer in "unstable" state
        while IsPedRagdoll(cache.ped) or IsPedFalling(cache.ped) or IsPedVaulting(cache.ped) or 
              IsPedInMeleeCombat(cache.ped) or IsPedClimbing(cache.ped) or IsPedInCover(cache.ped) or 
              IsPedReloading(cache.ped) or IsPedGettingIntoAVehicle(cache.ped) or IsPedDiving(cache.ped) or 
              IsPedBeingStunned(cache.ped) do
            Wait(100)
        end

        ClearPedTasks(cache.ped)

        -- Clean up scenario objects if used
        if config.animation and config.animation.scenario then
            while Utils.isPlayingAnim(config.animation) do
                local coords = GetEntityCoords(cache.ped)
                ClearAreaOfObjects(coords.x, coords.y, coords.z, 2.0, 0)
                break
            end
        end
    end)
end

-- Function to manually stop/cancel collecting
local function stopCollecting()
    TriggerServerEvent("JobsSystem_unijob:stopCollecting")
    isCollecting = false
    
    if LR.progressActive() then
        LR.cancelProgress()
    end
end

-- Server-side request to stop collecting
RegisterNetEvent("JobsSystem_unijob:stopCollecting", function(reason)
    isCollecting = false
    
    if LR.progressActive() then
        LR.cancelProgress()
    end

    if reason then
        LR.notify(reason, "error")
    end
end)

local Collecting = {}

-- Create collection points for a specific job
function Collecting.create(jobData)
    if not jobData.collecting then return end

    for index, config in ipairs(jobData.collecting) do
        for locIndex, coords in ipairs(config.locations) do
            local locationCoords = (type(coords) == "table" and coords.coords) or coords
            local point = Utils.createInteractionPoint({
                coords = locationCoords,
                radius = config.radius or Config.defaultRadius,
                options = {
                    {
                        label = config.label or locale("start_collecting"),
                        icon = config.icon or "hand",
                        onSelect = startCollecting,
                        args = {
                            data = config,
                            index = index,
                            locationIndex = locIndex
                        },
                        canInteract = function()
                            return not isCollecting and not IsPedInMeleeCombat(cache.ped)
                        end
                    },
                    {
                        label = locale("cancel"),
                        icon = "circle-xmark",
                        onSelect = stopCollecting,
                        canInteract = function()
                            return isCollecting
                        end
                    }
                }
            }, config.target)
            
            table.insert(collectingPoints, point)
        end
    end
end

-- Clear all collection points
function Collecting.clear()
    for _, point in ipairs(collectingPoints) do
        point.remove()
    end
    table.wipe(collectingPoints)
end

_G.Collecting = Collecting

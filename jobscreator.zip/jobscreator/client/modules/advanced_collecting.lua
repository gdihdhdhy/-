
local spawnedCollectables = {}

-- Function to handle the harvesting process
local function harvestCollectable(data)
    if IsPedInAnyVehicle(cache.ped, true) then
        return
    end

    local collecting = data.collecting
    if collecting.requiredItem and collecting.requiredItem ~= "" then
        if not Framework.hasItem(collecting.requiredItem) then
            local itemLabel = Utils.getItemLabel(collecting.requiredItem)
            LR.notify(locale("missing_item", itemLabel), "error")
            return
        end
    end

    local success = lib.callback.await("JobsSystem_unijob:harvestCollectable", false, data.name, data.index)
    if not success then
        LR.notify(msg, "error")
        return
    end

    Utils.makeEntityFaceCoords(cache.ped, data.coords)
    local animationProp = Utils.convertAnimProp(collecting.animationProp)

    LR.progressBar(
        collecting.progress,
        collecting.duration,
        false,
        collecting.animation,
        animationProp
    )
end

-- Function to create a collectable point with prop and interaction
local function createCollectablePoint(jobConfig, collectableIndex, locationIndex, coords, spawnIndex)
    local config = jobConfig.advancedCollecting[collectableIndex]
    local pointId = string.format("%s_%s_%s", jobConfig.name, collectableIndex, locationIndex)
    
    if not spawnedCollectables[pointId] then
        spawnedCollectables[pointId] = {}
    end

    if spawnedCollectables[pointId][spawnIndex] then
        return
    end

    local propEntity = nil
    local interactionPoint = nil

    spawnedCollectables[pointId][spawnIndex] = lib.points.new({
        coords = coords,
        distance = 100.0,
        onEnter = function()
            lib.requestModel(config.propModel)
            
            local _, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z, false)
            local offset = 50.0
            while groundZ == 0.0 and offset < 500.0 do
                _, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z + offset, false)
                offset = offset + 50.0
                Wait(0)
            end

            propEntity = CreateObjectNoOffset(config.propModel, coords.x, coords.y, groundZ + 1.0, false, false)
            PlaceObjectOnGroundProperly(propEntity)
            Wait(0)
            FreezeEntityPosition(propEntity, true)
            SetEntityHeading(propEntity, math.random(0, 360) + 0.0)
            
            local worldCoords = GetOffsetFromEntityInWorldCoords(propEntity, 0.0, 0.0, -0.1)
            SetEntityCoords(propEntity, worldCoords)

            local entityCoords = GetEntityCoords(propEntity)
            local interactOffset = config.interactionOffset or vector3(0.0, 0.0, 0.0)
            
            interactionPoint = Utils.createInteractionPoint({
                coords = entityCoords + interactOffset,
                radius = 0.75,
                options = {
                    {
                        label = config.label or locale("start_collecting"),
                        icon = config.icon or "hand",
                        onSelect = harvestCollectable,
                        args = {
                            collecting = config,
                            name = pointId,
                            index = spawnIndex,
                            coords = entityCoords
                        },
                        canInteract = function()
                            return not LR.progressActive()
                        end
                    }
                }
            })
        end,
        onExit = function()
            if propEntity then
                DeleteEntity(propEntity)
                propEntity = nil
            end
            if interactionPoint then
                interactionPoint.remove()
                interactionPoint = nil
            end
        end
    })
end

-- Event to spawn a collectable
RegisterNetEvent("JobsSystem_unijob:spawnCollectable", function(jobName, collectableIndex, locationIndex, coords, spawnIndex)
    local job = nil
    while true do
        job = GetJobs()[jobName]
        if job then break end
        Wait(100)
    end
    
    createCollectablePoint(job, collectableIndex, locationIndex, coords, spawnIndex)
end)

-- Initial fetch of collectables
lib.callback("JobsSystem_unijob:getCollectables", false, function(collectables)
    for _, data in ipairs(collectables) do
        for spawnIndex, coords in pairs(data.spawned) do
            local job = nil
            while true do
                job = GetJobs()[data.jobName]
                if job then break end
                Wait(100)
            end
            
            createCollectablePoint(job, data.index, data.locationIndex, coords, spawnIndex)
        end
    end
end)

-- Event to remove a specific collectable
RegisterNetEvent("JobsSystem_unijob:removeCollectable", function(pointId, spawnIndex)
    local point = spawnedCollectables[pointId] and spawnedCollectables[pointId][spawnIndex]
    if point then
        point:onExit()
        point:remove()
        spawnedCollectables[pointId][spawnIndex] = nil
    end
end)

-- Event to clear all collectables for specific IDs
RegisterNetEvent("JobsSystem_unijob:clearAdvancedCollecting", function(pointIds)
    for _, pointId in ipairs(pointIds) do
        if spawnedCollectables[pointId] then
            for spawnIndex, point in pairs(spawnedCollectables[pointId]) do
                point:onExit()
                point:remove()
            end
            spawnedCollectables[pointId] = nil
        end
    end
end)

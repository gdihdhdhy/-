
local cloakroomPoints = {}

local Cloakrooms = {}

-- Create cloakroom interaction points for a specific job
function Cloakrooms.create(jobData)
    if not jobData.cloakrooms then return end

    for _, cloakroomConfig in ipairs(jobData.cloakrooms) do
        for _, coords in ipairs(cloakroomConfig.locations) do
            local point = Utils.createInteractionPoint({
                coords = coords,
                radius = cloakroomConfig.radius or Config.defaultRadius,
                options = {
                    {
                        label = locale("open_cloakroom"),
                        icon = "shirt",
                        onSelect = Editable.openCloakroom
                    }
                }
            }, cloakroomConfig.target)
            
            table.insert(cloakroomPoints, point)
        end
    end
end

-- Clear all cloakroom interaction points
function Cloakrooms.clear()
    for _, point in ipairs(cloakroomPoints) do
        point.remove()
    end
    table.wipe(cloakroomPoints)
end

_G.Cloakrooms = Cloakrooms

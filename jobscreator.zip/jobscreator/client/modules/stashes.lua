
local jobStashPoints = {}
local globalStashPoints = {}

-- Helper to create a stash interaction point
local function createStashPoint(jobData, stashIndex)
    local config = jobData.stashes[stashIndex]
    
    for locIndex, coords in ipairs(config.locations) do
        local locationCoords = (type(coords) == "table" and coords.coords) or coords
        local stashId = config.name or string.format("%s_stash_%s_%s", jobData.name, stashIndex, locIndex)
        
        local point = Utils.createInteractionPoint({
            coords = locationCoords,
            radius = config.radius or Config.defaultRadius,
            options = {
                {
                    label = config.label or locale("open_stash"),
                    icon = config.icon or "box-archive",
                    onSelect = Editable.openStash,
                    args = {
                        name = stashId,
                        data = config
                    },
                    canInteract = function()
                        return config.global or HasGrade(config.grade)
                    end
                }
            }
        }, config.target)

        local targetList = config.global and globalStashPoints or jobStashPoints
        table.insert(targetList, point)
    end
end

local Stashes = {}

-- Create stash points for a specific job
function Stashes.create(jobData)
    if not jobData.stashes then return end

    for i, config in ipairs(jobData.stashes) do
        if not config.global then
            createStashPoint(jobData, i)
        end
    end
end

-- Clear all job-specific stash points
function Stashes.clear()
    for _, point in ipairs(jobStashPoints) do
        point.remove()
    end
    table.wipe(jobStashPoints)
end

-- Update global stash points for all jobs
function Stashes.update()
    -- Clear existing global points
    for _, point in ipairs(globalStashPoints) do
        point.remove()
    end
    table.wipe(globalStashPoints)

    local jobs = GetJobs()
    for _, jobData in pairs(jobs) do
        if jobData.stashes then
            for i, config in ipairs(jobData.stashes) do
                if config.global then
                    createStashPoint(jobData, i)
                end
            end
        end
    end
end

_G.Stashes = Stashes

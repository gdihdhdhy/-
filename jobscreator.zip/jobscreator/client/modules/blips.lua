
local jobBlips = {}
local globalBlips = {}

-- Helper function to format blip name with font if configured
local function formatBlipName(name)
    if Config.blipsFont and #Config.blipsFont > 0 then
        return string.format("<font face=\"%s\">%s</font>", Config.blipsFont, name)
    end
    return name
end

local Blips = {}

-- Create blips for a specific job
function Blips.create(jobData)
    if not jobData.blips then return end

    for _, blipConfig in ipairs(jobData.blips) do
        if not blipConfig.global then
            local blipData = table.clone(blipConfig)
            blipData.size = blipData.size + 0.0 -- Ensure float
            blipData.name = formatBlipName(blipData.name)
            
            local blip = Utils.createBlip(blipData.coords, blipData)
            table.insert(jobBlips, blip)
        end
    end
end

-- Clear all job-specific blips
function Blips.clear()
    for _, blip in ipairs(jobBlips) do
        blip.remove()
    end
    table.wipe(jobBlips)
end

-- Update global blips for all jobs
function Blips.update()
    -- Clear existing global blips
    for _, blip in ipairs(globalBlips) do
        blip.remove()
    end
    table.wipe(globalBlips)

    local jobs = GetJobs()
    for _, jobData in pairs(jobs) do
        if jobData.blips then
            for _, blipConfig in ipairs(jobData.blips) do
                if blipConfig.global and blipConfig.coords then
                    local blipData = table.clone(blipConfig)
                    blipData.size = blipData.size + 0.0 -- Ensure float
                    blipData.name = formatBlipName(blipData.name)
                    
                    local blip = Utils.createBlip(blipData.coords, blipData)
                    table.insert(globalBlips, blip)
                end
            end
        end
    end
end

_G.Blips = Blips

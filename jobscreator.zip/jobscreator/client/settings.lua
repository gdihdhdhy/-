
-- Settings Management

Settings = {}
local settingsLoaded = false

-- Load settings from server
lib.callback("JobsSystem_unijob:getSettings", false, function(settings)
    Settings = settings
    settingsLoaded = true
end)

-- Update settings from server
RegisterNetEvent("JobsSystem_unijob:updateSettings", function(settings)
    Settings = settings
    UI.sendMessage("updateSettings", settings)
end)

-- NUI Callback: Get settings
RegisterNUICallback("getSettings", function(data, cb)
    -- Wait for settings to load
    while not settingsLoaded do
        Wait(100)
    end
    
    cb(Settings)
end)

-- NUI Callback: Update settings
RegisterNUICallback("updateSettings", function(data, cb)
    TriggerServerEvent("JobsSystem_unijob:updateSettings", data)
    cb({})
end)

-- Utility Functions for Animations, Props, and Peds

Utils = Utils or {}

-- Check if player has permission
function Utils.hasPermission()
    return lib.callback.await("JobsSystem_unijob:hasPermission", false)
end

-- Create a prop attached to player
function createAttachedProp(propConfig)
    lib.requestModel(propConfig.model)
    
    local playerCoords = GetEntityCoords(cache.ped)
    local prop = CreateObject(
        propConfig.model,
        playerCoords.x, playerCoords.y, playerCoords.z,
        true, true, true
    )
    
    -- Attach prop to player bone
    AttachEntityToEntity(
        prop,
        cache.ped,
        GetPedBoneIndex(cache.ped, propConfig.bone or 60309),
        propConfig.position.x,
        propConfig.position.y,
        propConfig.position.z,
        propConfig.rotation.x,
        propConfig.rotation.y,
        propConfig.rotation.z,
        true, true, false, true, 0, true
    )
    
    SetModelAsNoLongerNeeded(propConfig.model)
    return prop
end

-- Check if player is playing animation
function Utils.isPlayingAnim(animConfig)
    if animConfig.dict and animConfig.clip then
        return IsEntityPlayingAnim(cache.ped, animConfig.dict, animConfig.clip, 3)
    elseif animConfig.scenario then
        return IsPedUsingScenario(cache.ped, animConfig.scenario)
    end
    return false
end

-- Play animation with optional props
function Utils.playAnim(animConfig, propData)
    if animConfig.dict and animConfig.clip then
        -- Play animation clip
        lib.requestAnimDict(animConfig.dict)
        
        TaskPlayAnim(
            cache.ped,
            animConfig.dict,
            animConfig.clip,
            animConfig.blendIn or 3.0,
            animConfig.blendOut or 1.0,
            animConfig.duration or -1,
            animConfig.flag or 49,
            animConfig.playbackRate or 0,
            animConfig.lockX or false,
            animConfig.lockY or false,
            animConfig.lockZ or false
        )
    elseif animConfig.scenario then
        -- Play scenario
        TaskStartScenarioInPlace(
            cache.ped,
            animConfig.scenario,
            0,
            animConfig.playEnter or true
        )
        
        -- Clean up scenario objects when done
        CreateThread(function()
            while Utils.isPlayingAnim(animConfig) do
                Wait(100)
            end
            
            local coords = GetEntityCoords(cache.ped)
            ClearAreaOfObjects(coords.x, coords.y, coords.z, 2.0, 0)
        end)
    end
    
    -- Handle props if provided
    if not propData then return end
    
    local attachedProps = {}
    local propList = propData
    
    -- Convert single prop to array
    if table.type(propData) == "hash" then
        propList = {propData}
    end
    
    -- Create all props
    for _, prop in ipairs(propList) do
        table.insert(attachedProps, createAttachedProp(prop))
    end
    
    -- Clean up props when animation ends
    CreateThread(function()
        while true do
            Wait(100)
            
            if not Utils.isPlayingAnim(animConfig) then
                -- Delete all attached props
                for _, prop in ipairs(attachedProps) do
                    DeleteEntity(prop)
                end
                
                -- Clean up scenario objects
                if animConfig.scenario then
                    local coords = GetEntityCoords(cache.ped)
                    ClearAreaOfObjects(coords.x, coords.y, coords.z, 2.0, 0)
                end
                
                break
            end
        end
    end)
end

-- Entity tracking
local createdEntities = {}

-- Convert vector table to vector4
local function convertToVector4(coords)
    if not (coords.x and coords.y and coords.z) then
        return
    end
    return vector4(coords.x, coords.y, coords.z, coords.w or 0.0)
end

-- Create props at location
function Utils.createProps(location, propConfig)
    local coords = convertToVector4(location)
    if not coords then return end
    
    local propList = propConfig.prop
    
    -- Convert single prop to array
    if table.type(propConfig.prop) == "hash" then
        propList = {propConfig.prop}
    end
    
    -- Create each prop
    for _, prop in ipairs(propList) do
        if IsModelValid(prop.model) then
            table.insert(createdEntities, Utils.createProp(coords, prop))
        end
    end
end

-- Create peds at location
function Utils.createPeds(location, pedConfig)
    local coords = convertToVector4(location)
    if not coords then return end
    
    local pedList = pedConfig.ped
    
    -- Convert single ped to array
    if table.type(pedConfig.ped) == "hash" then
        pedList = {pedConfig.ped}
    end
    
    -- Create each ped
    for _, ped in ipairs(pedList) do
        if IsModelValid(ped.model) then
            table.insert(createdEntities, Utils.createPed(coords, ped))
        end
    end
end

-- Remove all created entities
function Utils.removeEntities()
    for _, entity in ipairs(createdEntities) do
        entity.remove()
    end
    table.wipe(createdEntities)
end

-- Convert animation prop data to standard format
function Utils.convertAnimProp(propData)
    if not propData then return end
    
    local converted = {}
    local propList = propData
    
    -- Convert single prop to array
    if table.type(propData) == "hash" then
        propList = {propData}
    end
    
    -- Convert each prop
    for _, prop in ipairs(propList) do
        table.insert(converted, {
            model = prop.model,
            bone = prop.bone,
            pos = prop.position,
            rot = prop.rotation
        })
    end
    
    return converted
end
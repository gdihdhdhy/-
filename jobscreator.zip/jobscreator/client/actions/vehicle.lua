
-- Vehicle Actions System
-- Hijack, repair, clean, and impound vehicles

-- Perform vehicle action (client-side)
local function performVehicleAction(vehicle, action)
    local networkId = NetworkGetNetworkIdFromEntity(vehicle)
    TriggerServerEvent("JobsSystem_unijob:performVehicleAction", networkId, action)
end

-- Server event: Execute vehicle action
RegisterNetEvent("JobsSystem_unijob:performVehicleAction", function(networkId, action)
    local vehicle = NetworkGetEntityFromNetworkId(networkId)
    
    if not DoesEntityExist(vehicle) then
        return
    end
    
    if action == "hijack" then
        -- Unlock vehicle for everyone
        SetVehicleDoorsLocked(vehicle, 1)  -- Unlocked
        SetVehicleDoorsLockedForAllPlayers(vehicle, false)
        
    elseif action == "repair" then
        -- Fully repair vehicle
        SetVehicleFixed(vehicle)
        SetVehicleDeformationFixed(vehicle)
        SetVehicleUndriveable(vehicle, false)
        SetVehicleEngineOn(vehicle, true, true)
        
    elseif action == "clean" then
        -- Clean vehicle
        SetVehicleDirtLevel(vehicle, 0.0)
        
    elseif action == "impound" then
        -- Delete vehicle
        SetEntityAsMissionEntity(vehicle)
        DeleteVehicle(vehicle)
    end
end)

-- Action: Hijack vehicle
Actions.createVehicle("hijack", "user-ninja", function(vehicle)
    -- Check permission from server
    local hasPermission = lib.callback.await("JobsSystem_unijob:hijackVehicle", false)
    
    -- Start lockpicking scenario
    TaskStartScenarioInPlace(cache.ped, "PROP_HUMAN_BUM_BIN", 0, true)
    
    if hasPermission then
        -- Run lockpick minigame
        if Editable.lockpickMinigame() then
            -- Show progress bar
            if LR.progressBar(
                locale("progress_hijack"),
                Settings.durations.hijack,
                false
            ) then
                performVehicleAction(vehicle, "hijack")
                LR.notify(locale("hijacked"), "success")
            end
        end
    end
    
    ClearPedTasks(cache.ped)
end)

-- Action: Repair vehicle
Actions.createVehicle("repair", "screwdriver-wrench", function(vehicle)
    -- Check permission from server
    local hasPermission = lib.callback.await("JobsSystem_unijob:repairVehicle", false)
    
    if hasPermission then
        -- Show progress bar with repair animation
        if LR.progressBar(
            locale("progress_repair"),
            Settings.durations.repair,
            false,
            { scenario = "PROP_HUMAN_BUM_BIN" }
        ) then
            performVehicleAction(vehicle, "repair")
            LR.notify(locale("repaired"), "success")
        end
    end
end)

-- Action: Clean vehicle
Actions.createVehicle("clean", "hand-sparkles", function(vehicle)
    -- Check permission from server
    local hasPermission = lib.callback.await("JobsSystem_unijob:cleanVehicle", false)
    
    if hasPermission then
        -- Show progress bar with cleaning animation
        if LR.progressBar(
            locale("progress_clean"),
            Settings.durations.clean,
            false,
            { scenario = "WORLD_HUMAN_MAID_CLEAN" }
        ) then
            performVehicleAction(vehicle, "clean")
            LR.notify(locale("cleaned"), "success")
        end
    end
end)

-- Action: Impound vehicle
Actions.createVehicle("impound", "truck", function(vehicle)
    -- Check permission from server
    local hasPermission = lib.callback.await("JobsSystem_unijob:impoundVehicle", false)
    
    if hasPermission then
        -- Show progress bar with impound animation
        if LR.progressBar(
            locale("progress_impound"),
            Settings.durations.impound,
            false,
            { scenario = "CODE_HUMAN_MEDIC_TEND_TO_DEAD" }
        ) then
            performVehicleAction(vehicle, "impound")
            LR.notify(locale("impounded"), "success")
        end
    end
end)
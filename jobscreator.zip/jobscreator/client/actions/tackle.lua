
-- Player Tackle System
-- Sprint tackle nearby players

-- Animation settings
local TACKLE_ANIM_DICT = "missmic2ig_11"
local TACKLE_ANIM_ATTACKER = "mic_2_ig_11_intro_goon"  -- Tackler animation
local TACKLE_ANIM_VICTIM = "mic_2_ig_11_intro_p_one"   -- Tackled animation

local tackleCooldown = false

-- Perform tackle
local function performTackle()
    -- Check if player has access and can tackle
    if not HasAccess("tackle") or tackleCooldown or IsPedInAnyVehicle(cache.ped, true) then
        return
    end
    
    -- Only tackle while sprinting
    if not IsPedSprinting(cache.ped) then
        return
    end
    
    -- Find closest player in front of player
    local forwardVector = GetEntityForwardVector(cache.ped)
    local playerCoords = GetEntityCoords(cache.ped)
    local targetCoords = playerCoords + (forwardVector * 2)
    
    local closestPlayer = lib.getClosestPlayer(targetCoords, Settings.tackleRadius)
    if not closestPlayer then
        return
    end
    
    -- Enable cooldown
    tackleCooldown = true
    SetTimeout(Settings.tackleCooldown, function()
        tackleCooldown = false
    end)
    
    -- Send tackle to server
    TriggerServerEvent("JobsSystem_unijob:tacklePlayer", GetPlayerServerId(closestPlayer))
    
    -- Play tackle animation
    lib.requestAnimDict(TACKLE_ANIM_DICT)
    TaskPlayAnim(
        cache.ped,
        TACKLE_ANIM_DICT,
        TACKLE_ANIM_ATTACKER,
        8.0,    -- Blend in
        -8.0,   -- Blend out
        3000,   -- Duration (3 seconds)
        0,      -- Flags
        0,      -- Playback rate
        false,  -- Lock X
        false,  -- Lock Y
        false   -- Lock Z
    )
    RemoveAnimDict(TACKLE_ANIM_DICT)
end

-- Server event: Play tackled animation on victim
RegisterNetEvent("JobsSystem_unijob:playTackledAnim", function(attackerServerId)
    lib.requestAnimDict(TACKLE_ANIM_DICT)
    
    -- Get attacker's ped
    local attackerPed = GetPlayerPed(GetPlayerFromServerId(attackerServerId))
    
    -- Attach to attacker temporarily
    AttachEntityToEntity(
        cache.ped,
        attackerPed,
        11816,      -- Bone index
        0.25,       -- X offset
        0.5,        -- Y offset
        0.0,        -- Z offset
        0.5,        -- X rotation
        0.5,        -- Y rotation
        180.0,      -- Z rotation
        false,      -- Soft pinning
        false,      -- Collision
        false,      -- Is rope
        false,      -- Rotation order
        2,          -- Detach entity
        false       -- Fixed rotation
    )
    
    -- Play tackled animation
    TaskPlayAnim(
        cache.ped,
        TACKLE_ANIM_DICT,
        TACKLE_ANIM_VICTIM,
        8.0,    -- Blend in
        -8.0,   -- Blend out
        3000,   -- Duration (3 seconds)
        0,      -- Flags
        0,      -- Playback rate
        false,  -- Lock X
        false,  -- Lock Y
        false   -- Lock Z
    )
    
    Wait(3000)
    
    -- Detach from attacker
    DetachEntity(cache.ped)
    
    -- Make player ragdoll after tackle
    CreateThread(function()
        for i = 1, 30 do
            SetPedToRagdoll(cache.ped, 1000, 1000, 0, false, false, false)
            Wait(100)
        end
    end)
    
    RemoveAnimDict(TACKLE_ANIM_DICT)
end)

-- Register tackle keybind
lib.addKeybind({
    defaultMapper = "keyboard",
    defaultKey = Config.tackleKeybind,
    name = "tackle",
    description = "Player tackling",
    onReleased = performTackle
})
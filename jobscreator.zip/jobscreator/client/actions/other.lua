
-- Miscellaneous Player & Vehicle Actions

-- Action: Give invoice/bill to player
Actions.createPlayer("bill", "file-invoice", Editable.giveInvoice)

-- Action: Revive player
Actions.createPlayer("revive", "suitcase-medical", Editable.revivePlayer)

-- Action: Heal player
Actions.createPlayer("heal", "bandage", Editable.healPlayer)

-- Action: Put player in vehicle
Actions.createVehicle("putInsideVehicle", "user-plus", function(vehicle)
    local draggedPed = GetDraggedPed()
    if not draggedPed then
        return
    end
    
    -- Get server ID of dragged player
    local targetServerId = GetPlayerServerId(NetworkGetPlayerIndexFromPed(draggedPed))
    if targetServerId == 0 then
        return
    end
    
    -- Send to server to put player in vehicle
    local vehicleNetId = NetworkGetNetworkIdFromEntity(vehicle)
    TriggerServerEvent("JobsSystem_unijob:putInVehicle", targetServerId, vehicleNetId)
    
    -- Stop dragging
    StopDrag()
    
    Editable.actionPerformed("putInVehicle")
end, function()
    -- Only show action if dragging someone
    return GetDraggedPed() ~= nil
end)

-- Action: Take player out of vehicle
Actions.createVehicle("takeOutOfVehicle", "user-minus", function(vehicle)
    local maxSeats = GetVehicleMaxNumberOfPassengers(vehicle)
    
    -- Check all seats for cuffed players
    for seatIndex = maxSeats - 1, maxSeats - 3, -1 do
        local occupant = GetPedInVehicleSeat(vehicle, seatIndex)
        
        if occupant ~= 0 and IsPedAPlayer(occupant) then
            local serverId = GetPlayerServerId(NetworkGetPlayerIndexFromPed(occupant))
            
            if serverId == 0 then
                return
            end
            
            -- Remove player from vehicle
            TriggerServerEvent("JobsSystem_unijob:outTheVehicle", serverId)
            Editable.actionPerformed("takeOutOfVehicle")
            break
        end
    end
end, function(vehicle)
    -- Only show action if vehicle has cuffed players
    local maxSeats = GetVehicleMaxNumberOfPassengers(vehicle)
    
    for seatIndex = maxSeats - 1, maxSeats - 3, -1 do
        local occupant = GetPedInVehicleSeat(vehicle, seatIndex)
        
        if occupant ~= 0 and IsPedCuffed(occupant) then
            return true
        end
    end
    
    return false
end)
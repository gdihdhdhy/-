
-- Player Dragging System
-- Allows dragging of cuffed players

local draggedPlayer = nil

-- Stop dragging the current player
function StopDrag()
    if draggedPlayer then
        TriggerServerEvent("JobsSystem_unijob:drag")
        Binds.interact.removeListener("stop_drag")
        ClearPedSecondaryTask(cache.ped)
        LR.hideUI()
        draggedPlayer = nil
    end
end

-- Animation settings for dragging
local DRAG_ANIM_DICT = "amb@world_human_drinking@coffee@male@base"
local DRAG_ANIM_CLIP = "base"

-- Animation loop for dragging
SetInterval(function()
    if not draggedPlayer then
        return
    end
    
    -- Check if dragged player still exists and is alive
    if not DoesEntityExist(draggedPlayer) or IsEntityDead(draggedPlayer) then
        StopDrag()
        draggedPlayer = nil
        return
    end
    
    -- Play dragging animation if not already playing
    if not IsEntityPlayingAnim(cache.ped, DRAG_ANIM_DICT, DRAG_ANIM_CLIP, 3) then
        lib.requestAnimDict(DRAG_ANIM_DICT)
        TaskPlayAnim(
            cache.ped,
            DRAG_ANIM_DICT,
            DRAG_ANIM_CLIP,
            4.0,    -- Blend in
            4.0,    -- Blend out
            -1,     -- Duration (infinite)
            49,     -- Flags
            0.0,    -- Playback rate
            false,  -- Lock X
            false,  -- Lock Y
            false   -- Lock Z
        )
        RemoveAnimDict(DRAG_ANIM_DICT)
    end
end, 200)

-- Disable sprint while dragging (if setting is disabled)
if not Settings.sprintWhileDrag then
    CreateThread(function()
        while true do
            if draggedPlayer then
                DisableControlAction(0, 21)  -- Sprint key
                SetPlayerSprint(cache.playerId, false)
                Wait(0)
            else
                Wait(500)
            end
        end
    end)
end

-- Create drag action for players
Actions.createPlayer("drag", "hand", function(serverId, targetPed)
    TriggerServerEvent("JobsSystem_unijob:drag", serverId)
    
    -- Show UI with stop instruction
    LR.showUI(locale("stop_drag", Binds.interact.getCurrentKey()))
    
    -- Add keybind listener to stop dragging
    Binds.interact.addListener("stop_drag", StopDrag)
    
    -- Track action
    Editable.actionPerformed("drag")
    
    draggedPlayer = targetPed
end, function(targetPed)
    -- Only allow dragging cuffed players who aren't being carried
    return IsPedCuffed(targetPed) and not IsCarryActive()
end)

-- Get currently dragged player
function GetDraggedPed()
    return draggedPlayer
end
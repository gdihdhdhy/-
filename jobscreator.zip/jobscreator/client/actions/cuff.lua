
-- Handcuffing/Zip-Tie System
-- Restrain players with handcuffs or zip ties

local isCuffed = false
local draggedBy = nil
local cuffProp = nil

-- Cuff item models
local CUFF_MODELS = {
    handcuffs = -1281059971,  -- Handcuffs model hash
    zipties = 623548567        -- Zip-ties model hash
}

-- Cuff prop attachment positions
local CUFF_ATTACHMENTS = {
    handcuffs = {
        pos = vec3(0.0, 0.07, 0.03),
        rot = vec3(10.0, 115.0, -65.0)
    },
    zipties = {
        pos = vec3(0.05, 0.04, 0.055),
        rot = vec3(-90.0, 110.0, -65.0)
    }
}

-- Action: Search player
Actions.createPlayer("steal", "eye", Editable.searchPlayer)

-- Action: Toggle handcuffs
Actions.createPlayer("handcuff", "handcuffs", function(targetServerId)
    TriggerServerEvent("JobsSystem_unijob:cuffToggle", targetServerId)
end)

-- Helper: Get ped from server ID
local function getPedFromServerId(serverId)
    local player = GetPlayerFromServerId(serverId)
    if player == 0 then
        return
    end
    return GetPlayerPed(player)
end

-- Animation dictionaries
local CUFF_ANIM_DICT = "mp_arrest_paired"
local UNCUFF_ANIM_DICT = "mp_arresting"
local CUFF_SENDER_ANIM = "cop_p2_back_left"
local CUFF_RECEIVER_ANIM = "crook_p2_back_left"
local UNCUFF_ANIM = "a_uncuff"

-- Server event: Cuff receiver (victim)
RegisterNetEvent("JobsSystem_unijob:cuffReceiver", function(senderServerId)
    local cuffState = lib.callback.await("JobsSystem_unijob:getPlayerCuffState", false, cache.serverId)
    local senderPed = getPedFromServerId(senderServerId)
    
    if not senderPed then
        return
    end
    
    if cuffState then
        -- Being cuffed
        SetEnableHandcuffs(cache.ped, true)
        DisablePlayerFiring(cache.ped, true)
        SetCurrentPedWeapon(cache.ped, `WEAPON_UNARMED`, true)
        SetPedCanPlayGestureAnims(cache.ped, false)
        
        -- Play cuffing animation
        lib.requestAnimDict(CUFF_ANIM_DICT)
        AttachEntityToEntity(
            cache.ped,
            senderPed,
            11816,      -- Bone index
            -0.1,       -- X offset
            0.45,       -- Y offset
            0.0,        -- Z offset
            0.0,        -- X rotation
            0.0,        -- Y rotation
            20.0,       -- Z rotation
            false,      -- Soft pinning
            false,      -- Collision
            false,      -- Is rope
            false,      -- Rotation order
            20,         -- Detach entity
            false       -- Fixed rotation
        )
        
        TaskPlayAnim(
            cache.ped,
            CUFF_ANIM_DICT,
            CUFF_RECEIVER_ANIM,
            8.0,    -- Blend in
            -8.0,   -- Blend out
            5500,   -- Duration
            33,     -- Flags
            0,      -- Playback rate
            false,  -- Lock X
            false,  -- Lock Y
            false   -- Lock Z
        )
        
        Wait(3500)
        DetachEntity(cache.ped, true, false)
        RemoveAnimDict(CUFF_ANIM_DICT)
        
        -- Create cuff prop
        local cuffModel = CUFF_MODELS[cuffState]
        local attachment = CUFF_ATTACHMENTS[cuffState]
        local pos = attachment.pos
        local rot = attachment.rot
        
        lib.requestModel(cuffModel)
        cuffProp = CreateObject(cuffModel, 0, 0, 0, true, true, true)
        
        local boneIndex = GetPedBoneIndex(cache.ped, 18905)  -- Right wrist bone
        AttachEntityToEntity(
            cuffProp,
            cache.ped,
            boneIndex,
            pos.x, pos.y, pos.z,
            rot.x, rot.y, rot.z,
            true,   -- Soft pinning
            true,   -- Collision
            false,  -- Is rope
            true,   -- Rotation order
            1,      -- Detach entity
            true    -- Fixed rotation
        )
    else
        -- Being uncuffed
        if draggedBy then
            DetachEntity(cache.ped)
            draggedBy = nil
        end
        
        AttachEntityToEntity(
            cache.ped,
            senderPed,
            11816,
            -0.1, 0.65, 0.0,
            0.0, 0.0, 20.0,
            false, false, false, false, 20, false
        )
        
        Wait(2000)
        DetachEntity(cache.ped, true, false)
        
        SetEnableHandcuffs(cache.ped, false)
        DisablePlayerFiring(cache.ped, false)
        SetCurrentPedWeapon(cache.ped, `WEAPON_UNARMED`, true)
        SetPedCanPlayGestureAnims(cache.ped, true)
        
        -- Delete cuff prop
        if cuffProp then
            DeleteEntity(cuffProp)
        end
    end
    
    isCuffed = cuffState
end)

-- Server event: Cuff sender (officer)
RegisterNetEvent("JobsSystem_unijob:cuffSender", function(targetServerId)
    local targetCuffState = lib.callback.await("JobsSystem_unijob:getPlayerCuffState", false, targetServerId)
    
    if targetCuffState then
        -- Cuffing animation
        lib.requestAnimDict(CUFF_ANIM_DICT)
        TaskPlayAnim(
            cache.ped,
            CUFF_ANIM_DICT,
            CUFF_SENDER_ANIM,
            8.0,    -- Blend in
            -8.0,   -- Blend out
            5500,   -- Duration
            33,     -- Flags
            0,      -- Playback rate
            false,  -- Lock X
            false,  -- Lock Y
            false   -- Lock Z
        )
        
        Wait(3500)
        ClearPedTasks(cache.ped)
        RemoveAnimDict(CUFF_ANIM_DICT)
        Editable.actionPerformed("handcuff")
    else
        -- Uncuffing animation
        lib.requestAnimDict(UNCUFF_ANIM_DICT)
        TaskPlayAnim(
            cache.ped,
            UNCUFF_ANIM_DICT,
            UNCUFF_ANIM,
            8.0,    -- Blend in
            -8.0,   -- Blend out
            -1,     -- Duration (infinite)
            2,      -- Flags
            0,      -- Playback rate
            false,  -- Lock X
            false,  -- Lock Y
            false   -- Lock Z
        )
        
        Wait(2000)
        ClearPedTasks(cache.ped)
        RemoveAnimDict(UNCUFF_ANIM_DICT)
        Editable.actionPerformed("unhandcuff")
    end
end)

-- Server event: Sync cuff state
RegisterNetEvent("JobsSystem_unijob:syncCuff", function()
    local cuffState = lib.callback.await("JobsSystem_unijob:getPlayerCuffState", false, cache.serverId)
    
    if not cuffState then
        SetEnableHandcuffs(cache.ped, false)
        DisablePlayerFiring(cache.ped, false)
        SetCurrentPedWeapon(cache.ped, `WEAPON_UNARMED`, true)
        SetPedCanPlayGestureAnims(cache.ped, true)
        
        -- Stop drag if being dragged
        if draggedBy then
            TriggerEvent("JobsSystem_unijob:drag")
        end
    end
    
    isCuffed = cuffState
end)

-- Movement animation dictionaries
local CUFFED_WALK_ANIM = "anim@move_m@prisoner_cuffed"
local CUFFED_RUN_ANIM = "anim@move_m@trash"

-- Server event: Handle dragging
RegisterNetEvent("JobsSystem_unijob:drag", function(draggerServerId)
    if not isCuffed then
        return
    end
    
    if not draggedBy and draggerServerId then
        local draggerPed = getPedFromServerId(draggerServerId)
        if not draggerPed then
            return
        end
        
        AttachEntityToEntity(
            cache.ped,
            draggerPed,
            11816,      -- Bone index
            0.2,        -- X offset
            0.45,       -- Y offset
            0.0,        -- Z offset
            0.0,        -- X rotation
            0.0,        -- Y rotation
            0.0,        -- Z rotation
            false,      -- Soft pinning
            false,      -- Collision
            false,      -- Is rope
            true,       -- Rotation order
            2,          -- Detach entity
            true        -- Fixed rotation
        )
    else
        DetachEntity(cache.ped)
        StopAnimTask(cache.ped, CUFFED_WALK_ANIM, "walk", 3.0)
        StopAnimTask(cache.ped, CUFFED_RUN_ANIM, "run", 3.0)
    end
    
    draggedBy = draggerServerId
end)

-- Server event: Put in vehicle
RegisterNetEvent("JobsSystem_unijob:putInVehicle", function(vehicleNetId)
    if not isCuffed or not draggedBy then
        return
    end
    
    if not NetworkDoesEntityExistWithNetworkId(vehicleNetId) then
        return
    end
    
    local vehicle = NetworkGetEntityFromNetworkId(vehicleNetId)
    local maxSeats = GetVehicleMaxNumberOfPassengers(vehicle)
    
    -- Find first free seat
    for seatIndex = maxSeats - 1, 0, -1 do
        if IsVehicleSeatFree(vehicle, seatIndex) then
            TaskWarpPedIntoVehicle(cache.ped, vehicle, seatIndex)
            break
        end
    end
end)

-- Server event: Take out of vehicle
RegisterNetEvent("JobsSystem_unijob:outTheVehicle", function()
    if not isCuffed then
        return
    end
    
    if not IsPedSittingInAnyVehicle(cache.ped) then
        return
    end
    
    local vehicle = GetVehiclePedIsIn(cache.ped, false)
    TaskLeaveVehicle(cache.ped, vehicle, 64)
end)

-- Play cuffed movement animations
local function playCuffedMovementAnim(ped)
    if IsPedWalking(ped) then
        if not IsEntityPlayingAnim(cache.ped, CUFFED_WALK_ANIM, "walk", 3) then
            lib.requestAnimDict(CUFFED_WALK_ANIM)
            TaskPlayAnim(
                cache.ped,
                CUFFED_WALK_ANIM,
                "walk",
                3.0, 3.0, -1, 1, 0.0,
                false, false, false
            )
            RemoveAnimDict(CUFFED_WALK_ANIM)
        end
    elseif (IsPedRunning(ped) or IsPedSprinting(ped)) and Settings.sprintWhileDrag then
        if not IsEntityPlayingAnim(cache.ped, CUFFED_RUN_ANIM, "run", 3) then
            lib.requestAnimDict(CUFFED_RUN_ANIM)
            TaskPlayAnim(
                cache.ped,
                CUFFED_RUN_ANIM,
                "run",
                3.0, 3.0, -1, 1, 0.0,
                false, false, false
            )
            RemoveAnimDict(CUFFED_RUN_ANIM)
        end
    else
        StopAnimTask(cache.ped, CUFFED_WALK_ANIM, "walk", 3.0)
        StopAnimTask(cache.ped, CUFFED_RUN_ANIM, "run", 3.0)
    end
end

-- Cuffed idle animation
local CUFFED_IDLE_ANIM = "mp_arresting"
local wasPlayingIdleAnim = false
local needsIdleAnimReplay = false

-- Main cuff loop
SetInterval(function()
    if isCuffed then
        -- Play dragged movement animations
        if draggedBy then
            local draggerPed = getPedFromServerId(draggedBy)
            if draggerPed then
                playCuffedMovementAnim(draggerPed)
            end
        end
        
        -- Play idle cuffed animation
        if not IsEntityPlayingAnim(cache.ped, CUFFED_IDLE_ANIM, "idle", 3) or
           (Config.forceCuffAnim or needsIdleAnimReplay) then
            
            lib.requestAnimDict(CUFFED_IDLE_ANIM)
            TaskPlayAnim(
                cache.ped,
                CUFFED_IDLE_ANIM,
                "idle",
                8.0, -8, -1, 49, 0.0,
                false, false, false
            )
            RemoveAnimDict(CUFFED_IDLE_ANIM)
            wasPlayingIdleAnim = true
            needsIdleAnimReplay = false
        end
        
        -- Check for ragdoll
        if IsPedRagdoll(cache.ped) then
            needsIdleAnimReplay = true
        end
    else
        -- Clear idle animation when uncuffed
        if wasPlayingIdleAnim then
            if IsEntityPlayingAnim(cache.ped, CUFFED_IDLE_ANIM, "idle", 3) then
                ClearPedTasks(cache.ped)
                wasPlayingIdleAnim = false
            end
        end
    end
end, 100)

-- Control restrictions while cuffed
CreateThread(function()
    while true do
        if isCuffed then
            Editable.handcuffControls()
            Wait(0)
        else
            Wait(500)
        end
    end
end)

-- Export functions
function IsHandcuffed()
    return isCuffed
end

function IsDragged()
    return draggedBy ~= nil
end

exports("isCuffed", IsHandcuffed)
exports("isDragged", IsDragged)
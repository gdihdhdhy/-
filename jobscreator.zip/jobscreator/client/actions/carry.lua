
-- Player Carrying System
-- Fireman's carry for transporting players

local carriedPlayer = nil

-- Get ped from server ID
local function getPedFromServerId(serverId)
    local player = GetPlayerFromServerId(serverId)
    if player == 0 then
        return
    end
    return GetPlayerPed(player)
end

-- Stop carrying
local function stopCarry()
    if carriedPlayer then
        TriggerServerEvent("JobsSystem_unijob:stopCarry")
        Binds.interact.removeListener("stop_carry")
    end
end

-- Animation loop for carrier (person carrying)
local function carrierAnimationLoop()
    Binds.interact.addListener("stop_carry", stopCarry)
    LR.showUI(locale("stop_carrying", Binds.interact.getCurrentKey()))
    
    while carriedPlayer do
        -- Play carrying animation if not already playing
        if not IsEntityPlayingAnim(cache.ped, "missfinale_c2mcs_1", "fin_c2_mcs_1_camman", 3) then
            lib.requestAnimDict("missfinale_c2mcs_1")
            TaskPlayAnim(
                cache.ped,
                "missfinale_c2mcs_1",
                "fin_c2_mcs_1_camman",
                8.0,    -- Blend in
                -8.0,   -- Blend out
                -1,     -- Duration (infinite)
                49,     -- Flags
                0,      -- Playback rate
                false,  -- Lock X
                false,  -- Lock Y
                false   -- Lock Z
            )
            RemoveAnimDict("missfinale_c2mcs_1")
        end
        
        Wait(200)
    end
    
    LR.hideUI()
end

-- Animation loop for carried person
local function carriedAnimationLoop()
    Binds.interact.addListener("stop_carry", stopCarry)
    LR.showUI(locale("stop_carried", Binds.interact.getCurrentKey()))
    
    while carriedPlayer do
        -- Play carried animation if not already playing
        if not IsEntityPlayingAnim(cache.ped, "nm", "firemans_carry", 3) then
            lib.requestAnimDict("nm")
            TaskPlayAnim(
                cache.ped,
                "nm",
                "firemans_carry",
                8.0,    -- Blend in
                -8.0,   -- Blend out
                -1,     -- Duration (infinite)
                33,     -- Flags
                0,      -- Playback rate
                false,  -- Lock X
                false,  -- Lock Y
                false   -- Lock Z
            )
            RemoveAnimDict("nm")
        end
        
        -- Stop if player dies
        if IsPlayerDead(cache.playerId) then
            stopCarry()
            break
        end
        
        Wait(200)
    end
    
    LR.hideUI()
end

-- Create carry action for players
Actions.createPlayer("carry", "hands", function(targetServerId)
    carriedPlayer = targetServerId
    TriggerServerEvent("JobsSystem_unijob:carry", targetServerId)
    CreateThread(carrierAnimationLoop)
    Editable.actionPerformed("carry")
end)

-- Server event: Sync carry to victim
RegisterNetEvent("JobsSystem_unijob:syncCarry", function(carrierServerId)
    carriedPlayer = carrierServerId
    
    local carrierPed = getPedFromServerId(carrierServerId)
    if not carrierPed then
        return
    end
    
    -- Attach to carrier's back
    AttachEntityToEntity(
        cache.ped,
        carrierPed,
        0,          -- Bone index
        0.27,       -- X offset
        0.15,       -- Y offset
        0.63,       -- Z offset
        0.5,        -- X rotation
        0.5,        -- Y rotation
        180,        -- Z rotation
        false,      -- Soft pinning
        false,      -- Collision
        false,      -- Is rope
        false,      -- Rotation order
        2,          -- Detach entity
        false       -- Fixed rotation
    )
    
    CreateThread(carriedAnimationLoop)
end)

-- Server event: Stop carry
RegisterNetEvent("JobsSystem_unijob:stopCarry", function(shouldDetach)
    carriedPlayer = nil
    
    if shouldDetach then
        DetachEntity(cache.ped)
    end
    
    ClearPedSecondaryTask(cache.ped)
end)

-- Check if carry is active
function IsCarryActive()
    return carriedPlayer ~= nil
end